Nuxt
```
pnpm dev
```

Laravel
```
pnpm serve
```

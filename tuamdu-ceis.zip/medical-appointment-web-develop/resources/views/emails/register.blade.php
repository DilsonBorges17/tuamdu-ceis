<x-mail::message>
	<p>Thank you for registering TUA-MDU.</p>
	<p>This is your temporary password: <span style="font-weight: bold"> {{ $data['password'] }}</span></p>
	<br/>
	<p>Please change it after logging in.</p>
</x-mail::message>
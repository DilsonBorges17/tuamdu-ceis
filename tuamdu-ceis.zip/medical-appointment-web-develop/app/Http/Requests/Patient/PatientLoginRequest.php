<?php

namespace App\Http\Requests\Patient;

use Illuminate\Validation\Validator;
use App\Models\Patient;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Hash;
use Closure;

class PatientLoginRequest extends FormRequest
{
	/**
	 * Determine if the user is authorized to make this request.
	 */


	protected $authenticatedPatient = null;
	public function authorize(): bool
	{
		return true;
	}

	/**
	 * Get the validation rules that apply to the request.
	 *
	 * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
	 */
	public function rules(): array
	{
		return [
			'email' => [
				'required',
				'email',
				'exists:patients,email',
				function (string $attribute, mixed $value, Closure $fail) {
					if (strpos($value, '@tua.edu.ph') === false) {
						$fail('The email cannot be found in the domain.');
					}
				},
			],
			'password' => 'required|min:3',
		];
	}

	public function messages(): array
	{
		return [
			'email.exists' => 'The username cannot be found.',
		];
	}

	public function after(): array
	{
		return [
			function (Validator $validator) {
				$patient = Patient::with('roles', 'department')->where('email', $this->email)->first();

				if (!$patient || !Hash::check($this->password, $patient->password)) {
					$validator->errors()->add(
						'password',
						'The password is incorrect'
					);
				}

				$this->authenticatedPatient = $patient;
			},
		];
	}

	protected function passedValidation(): void
	{
		$validated = $this->validated();
		$validated['patient'] = $this->authenticatedPatient;

		$this->replace($validated);
	}
}

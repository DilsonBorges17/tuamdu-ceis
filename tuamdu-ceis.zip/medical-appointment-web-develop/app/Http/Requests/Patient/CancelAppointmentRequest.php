<?php

namespace App\Http\Requests\Patient;

use App\Models\Appointment;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Hash;
use Closure;


class CancelAppointmentRequest extends FormRequest
{
	/**
	 * Determine if the user is authorized to make this request.
	 */
	public function authorize(): bool
	{
		return true;
	}

	/**
	 * Get the validation rules that apply to the request.
	 *
	 * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
	 */
	public function rules(): array
	{
		return [
			'reason' => 'required|string',
			'reschedule' => 'required|boolean',
			'appointment_id' => [
				'required',
				function (string $attribute, mixed $value, Closure $fail) {
					$appointment = Appointment::where('patient_id', auth()->user()->id)->where('status', 'Pending')->first();

					if (!$appointment) {
						$fail('The appointment cannot be found.');
					}
				},
			]
		];
	}
}

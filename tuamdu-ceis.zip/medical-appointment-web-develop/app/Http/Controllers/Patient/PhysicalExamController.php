<?php

namespace App\Http\Controllers\Patient;

use App\Models\PhysicalExam;
use App\Http\Controllers\Controller;
use App\Http\Requests\Patient\StorePhysicalExamRequest;

class PhysicalExamController extends Controller
{

	public function index()
	{
		return response()->json(
			PhysicalExam::
				with(['patient.roles', 'patient.department'])
				->where('patient_id', auth()->user()->id)
				->orderBy('created_at', 'desc')
				->get()
		);
	}

	public function store(StorePhysicalExamRequest $request)
	{
		return response()->json(
			PhysicalExam::
				create($request->all() + [
					'patient_id' => auth()->user()->id
				])
		);
	}
}

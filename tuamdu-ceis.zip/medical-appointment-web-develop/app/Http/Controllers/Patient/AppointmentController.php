<?php

namespace App\Http\Controllers\Patient;

use App\Notifications\AppointmentQueued;
use Illuminate\Database\Eloquent\Builder;
use App\Http\Controllers\Controller;
use App\Http\Requests\Patient\CancelAppointmentRequest;
use App\Http\Requests\Patient\SearchAppointmentScheduleRequest;
use App\Http\Requests\Patient\StoreAppointmentRequest;
use App\Models\Appointment;
use App\Models\AppointmentSchedule;
use App\Models\Patient;
use App\Models\ServiceCategory;
use App\Models\ServiceType;
use App\Models\User;
use App\Notifications\PatientCancelledAppointment;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class AppointmentController extends Controller
{
	public function index()
	{
		return response()->json(
			Appointment::
				with(['schedule.doctor', 'schedule.service_type.category', 'patient.roles', 'patient.department'])
				->where('patient_id', auth()->user()->id)
				->orderBy('created_at', 'desc')
				->get()
		);
	}

	public function store(StoreAppointmentRequest $request)
	{
		$data = DB::transaction(function () use ($request) {
			$patient = Patient::find(auth()->user()->id);

			$appointment = Appointment::create([
				'queuing_number' => $request['queuing_number'],
				'appointment_schedule_id' => $request['appointment_schedule_id'],
				'patient_id' => auth()->user()->id,
				'scheduled_date' => $request['date'],
			]);
			$appointment->load(['schedule.doctor', 'schedule.service_type.category', 'patient.roles', 'patient.department']);

			$patient->notify(new AppointmentQueued($appointment));

			return $appointment;
		});

		return response()->json($data);
	}

	public function serviceCategories()
	{
		return response()->json(ServiceCategory::all());
	}

	public function serviceTypes(int $serviceCategoryID)
	{
		$rows = ServiceType::where('service_category_id', $serviceCategoryID)->get();
		return response()->json($rows);
	}

	public function schedules(SearchAppointmentScheduleRequest $request)
	{
		$dayOfWeek = Carbon::parse($request->query('date'))->format('l');

		$rows = AppointmentSchedule::
			whereDoesntHave('appointment', function (Builder $query) use ($request) {
				$query->where('scheduled_date', '=', $request['date']);
			})
			->where('day_of_week', $dayOfWeek)
			->where('service_type_id', $request->query('service_type_id'))
			->get();

		return response()->json($rows);
	}

	public function cancelAppointment(CancelAppointmentRequest $request)
	{
		$data = DB::transaction(function () use ($request) {
			$appointment = Appointment::with(['schedule.service_type', 'schedule.doctor'])->where('patient_id', auth()->user()->id)->where('status', 'Pending')->first();

			$patient = Patient::find(auth()->user()->id);

			$doctor = User::find($appointment['schedule']['doctor']['id']);
			$doctor->notify(new PatientCancelledAppointment([
				'reason' => $request->reason,
				'appointment' => $appointment,
				'reschedule' => $request->reschedule,
				'patient' => $patient
			]));

			$appointment->status = 'Cancelled';
			$appointment->save();

			return $appointment;
		});

		return response()->json($data);
	}
}

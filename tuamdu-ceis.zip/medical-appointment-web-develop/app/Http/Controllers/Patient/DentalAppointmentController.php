<?php

namespace App\Http\Controllers\Patient;

use App\Models\User;
use App\Models\ServiceType;
use App\Http\Controllers\Controller;

class DentalAppointmentController extends Controller
{
	public function index()
	{
		return response()->json(
			User::whereHas('roles', function ($query) {
				$query->where('name', 'Dental Doctor');
			})->get()
		);
	}

	public function serviceTypes(int $doctorID)
	{
		$rows = ServiceType::whereHas('appointment_schedules', function ($query) use ($doctorID) {
			$query->where('doctor_id', $doctorID);
		})->get();
		return response()->json($rows);
	}

}

<?php

namespace App\Http\Controllers\Patient;

use App\Http\Controllers\Controller;
use App\Models\Patient;

class AppointmentNotificationController extends Controller
{
	public function index()
	{
		$patient = Patient::find(auth()->user()->id);
		return response()->json($patient->unreadNotifications);
	}

	public function update($notificationID)
	{
		$patient = Patient::find(auth()->user()->id);

		$notification = $patient->unreadNotifications->where('type', 'appointment-queued')->findOrFail($notificationID);
		$notification->markAsRead();

		return response()->json($notification);
	}
}

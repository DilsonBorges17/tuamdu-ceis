<?php

namespace App\Http\Controllers\User;

use Illuminate\Support\Facades\Gate;
use App\Models\PhysicalExamRecord;
use App\Http\Controllers\Controller;
use App\Http\Requests\User\UpsertPhysicalExamRecordRequest;
use App\Models\Patient;
use Illuminate\Http\Request;

//use App\Http\Requests\StorePhysicalExamRecordRequest;
//use App\Http\Requests\UpdatePhysicalExamRecordRequest;

class PhysicalExamRecordController extends Controller
{
	/**
	 * Display a listing of the resource.
	 */
	public function index(Request $request)
	{
		Gate::authorize('view', PhysicalExamRecord::class);
		$patient = Patient::where('id_number', $request->query('patient_id_number'))->firstOrFail();
		return response()->json(PhysicalExamRecord::with('doctor')->where('doctor_id', auth()->user()->id)->where('patient_id', $patient->id)->get());
	}

	/**
	 * Store a newly created resource in storage.
	 */
	public function store(UpsertPhysicalExamRecordRequest $request)
	{
		Gate::authorize('upsert', PhysicalExamRecord::class);
		$patient = Patient::where('id_number', $request['patient_id_number'])->firstOrFail();
		return response()
			->json(
				PhysicalExamRecord::create(
					$request->all() +
					[
						'doctor_id' => auth()->user()->id,
						'patient_id' => $patient->id,
						'date' => date('Y-m-d')
					]
				)
			);
	}

	/**
	 * Display the specified resource.
	 */
	public function show(int $id)
	{
		Gate::authorize('viewAny', PhysicalExamRecord::class);
		return response()->json(PhysicalExamRecord::findOrFail($id));
	}


	/**
	 * Update the specified resource in storage.
	 */
	public function update(UpsertPhysicalExamRecordRequest $request, int $id)
	{
		Gate::authorize('upsert', PhysicalExamRecord::class);

		$row = PhysicalExamRecord::findOrFail($id);
		$row->update($request->all());

		return response()->json($row);
	}

	/**
	 * Remove the specified resource from storage.
	 */
	public function destroy(int $id)
	{
		Gate::authorize('delete', PhysicalExamRecord::class);
		$row = PhysicalExamRecord::findOrFail($id);
		return response()->json($row->delete());
	}
}

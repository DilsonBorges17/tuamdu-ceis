<?php

namespace App\Http\Controllers\User;

use App\Models\User;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class NotificationController extends Controller
{
	public function index()
	{
		$user = User::find(auth()->user()->id);
		return response()->json($user->unreadNotifications);
	}

	public function all()
	{
		$allNotifications = DB::table('notifications')
			->where('notifiable_type', 'App\Models\User')
			->get();

		$notificationsWithParsedData = $allNotifications->map(function ($notification) {
			if (isset($notification->data) && $notification->data !== null) {
				$notification->data = json_decode($notification->data, true);
			}
			return $notification;
		});

		return response()->json($notificationsWithParsedData);
	}
}

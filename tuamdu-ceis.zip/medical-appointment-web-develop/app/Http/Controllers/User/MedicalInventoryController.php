<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Http\Requests\User\UpsertMedicalInventoryRequest;
use App\Models\MedicalInventory;

class MedicalInventoryController extends Controller
{
	public function index()
	{
		return response()->json(MedicalInventory::all());
	}

	/**
	 * Store a newly created resource in storage.
	 */
	public function store(UpsertMedicalInventoryRequest $request)
	{
		return response()->json(MedicalInventory::create($request->all()));
	}

	/**
	 * Display the specified resource.
	 */
	public function show(int $id)
	{
		return response()->json(MedicalInventory::findOrFail($id));
	}

	/**
	 * Update the specified resource in storage.
	 */
	public function update(UpsertMedicalInventoryRequest $request, int $id)
	{
		$row = MedicalInventory::findOrFail($id);
		$row->update($request->all());

		return response()->json($row);
	}

	/**
	 * Remove the specified resource from storage.
	 */
	public function destroy(int $id)
	{
		$row = MedicalInventory::findOrFail($id);

		return response()->json($row->delete());
	}
}

<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Http\Requests\User\UpdatePatientProfileRequest;
use App\Models\Patient;

class PatientController extends Controller
{
	/**
	 * Display a listing of the resource.
	 */
	public function index()
	{
		return response()->json(Patient::with('department')->get());
	}

	public function show(string $idNumber)
	{
		return response()->json(Patient::with('department')->where('id_number', $idNumber)->firstOrFail());
	}

	public function update(UpdatePatientProfileRequest $request, int $id)
	{
		$row = Patient::findOrFail($id);
		$row->update($request->all());
		$row->load(['roles', 'department']);

		return response()->json($row);
	}

}

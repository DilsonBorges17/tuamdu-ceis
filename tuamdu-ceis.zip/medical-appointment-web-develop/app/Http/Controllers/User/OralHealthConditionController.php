<?php

namespace App\Http\Controllers\User;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\User\UpsertOralHealthConditionRequest;
use App\Models\OralHealthCondition;
use App\Models\OralHealthConditionHistory;
use Illuminate\Support\Facades\DB;
use App\Models\Patient;

class OralHealthConditionController extends Controller
{
	/**
	 * Display a listing of the resource.
	 */
	public function index(Request $request)
	{
		$patient = Patient::where('id_number', $request->query('patient_id_number'))->firstOrFail();
		$row = [];
		$row['oral_health_conditions'] = OralHealthCondition::where('patient_id', $patient->id)->get();
		$row['history'] = OralHealthConditionHistory::where('patient_id', $patient->id)->get();

		return response()->json($row);
	}

	/**
	 * Store a newly created resource in storage.
	 */
	public function store(UpsertOralHealthConditionRequest $request)
	{
		$data = DB::transaction(function () use ($request) {
			$patient = Patient::where('id_number', $request['patient_id_number'])->firstOrFail();

			$row = OralHealthCondition::create($request->all() + ['patient_id' => $patient->id,]);

			if (isset($request->history)) {
				$history = OralHealthConditionHistory::create($request->history + ['patient_id' => $patient->id]);
				$row['history'] = $history;
			}

			return $row;
		});

		return response()->json($data);
	}

	/**
	 * Display the specified resource.
	 */
	public function show(string $id)
	{
		return response()->json(OralHealthCondition::findOrFail($id));
	}

	/**
	 * Update the specified resource in storage.
	 */
	public function update(UpsertOralHealthConditionRequest $request, string $id)
	{
		$data = DB::transaction(function () use ($request, $id) {
			$row = OralHealthCondition::findOrFail($id);
			$row->update($request->all());

			$patient = Patient::where('id_number', $request['patient_id_number'])->firstOrFail();

			$oralHealthHistory = OralHealthConditionHistory::where('patient_id', $patient->id)->firstOrFail();

			if (isset($request->history)) {
				$oralHealthHistory->update($request->history);
				$row['history'] = $oralHealthHistory;
			}
			return $row;
		});

		return response()->json($data);
	}

	/**
	 * Remove the specified resource from storage.
	 */
	public function destroy(string $id)
	{
		$row = OralHealthCondition::findOrFail($id);
		return response()->json($row->delete());
	}

	public function deleteOralHealthHistory(string $id)
	{
		$row = OralHealthConditionHistory::findOrFail($id);
		return response()->json($row->delete());
	}
}

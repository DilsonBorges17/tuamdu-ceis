<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MedicalInventory extends Model
{
	protected $fillable = [
		'medicine_category',
		'tool_name',
		'volume',
		'quantity',
		'expiration_date'
	];
}

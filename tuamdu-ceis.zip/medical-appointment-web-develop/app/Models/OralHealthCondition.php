<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class OralHealthCondition extends Model
{
	use HasFactory, SoftDeletes;

	protected $fillable = [
		'date',
		'patient_id',
		'year',
		'debris_tooth_stain',
		'calculus_deposit',
		'gingivitis',
		'periodontal_pocket',
		'orthodontic_treatment',
		'other_diseases',
		'teeth_present_total',
		'teeth_present_permanent',
		'caries_free_teeth_total',
		'caries_free_teeth_permanent',
		'teeth_extraction_total',
		'teeth_extraction_permanent',
		'teeth_restoration_total',
		'teeth_restoration_permanent',
		'missing_teeth_total',
		'missing_teeth_permanent',
		'filled_teeth_total',
		'filled_teeth_permanent',
		'df_dmf_teeth_total',
		'df_dmf_teeth_permanent',
		'examiner',
	];

	protected $casts = [
		'debris_tooth_stain' => 'boolean',
		'calculus_deposit' => 'boolean',
		'gingivitis' => 'boolean',
		'periodontal_pocket' => 'boolean',
		'orthodontic_treatment' => 'boolean',
	];

	public function patient(): BelongsTo
	{
		return $this->belongsTo(Patient::class);
	}
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class OralHealthConditionHistory extends Model
{
	use HasFactory;

	protected $fillable = [
		'patient_id',
		'allergy',
		'diabetes',
		'blood_dyscrasia',
		'cns_disorder',
		'cardiovascular_disease',
		'other_histories',
		'dental_surgical_procedures',
	];

	public function patient(): BelongsTo
	{
		return $this->belongsTo(Patient::class);
	}
}

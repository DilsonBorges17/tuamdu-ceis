<?php

namespace App\Policies;

use App\Models\ConsultationRecord;
use App\Models\User;

class ConsultationRecordPolicy
{
	public function viewAny(User $user): bool
	{
		return $user->hasRole(['Medical Doctor', 'Dental Doctor']);
	}

	public function view(User $user): bool
	{
		return $user->hasRole(['Medical Doctor', 'Dental Doctor']);
	}

	public function upsert(User $user): bool
	{
		return $user->hasRole(['Medical Doctor', 'Dental Doctor']);
	}

	public function delete(User $user): bool
	{
		return $user->hasRole(['Medical Doctor', 'Dental Doctor']);
	}
}

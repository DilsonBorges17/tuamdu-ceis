<?php

namespace Database\Seeders;

use App\Models\Holiday;
use Illuminate\Database\Seeder;

class HolidaySeeder extends Seeder
{
	/**
	 * Run the database seeds.
	 */
	public function run(): void
	{
		$holidays = [
			//Regular Holidays
			['name' => "New Years's Day", 'date' => '2025-01-01', 'type' => 'Regular'],
			['name' => "Day of Valor", 'date' => '2025-04-09', 'type' => 'Regular'],
			['name' => "Maundy Thursday", 'date' => '2025-04-17', 'type' => 'Regular'],
			['name' => "Good Friday", 'date' => '2025-04-18', 'type' => 'Regular'],
			['name' => "Labor Day", 'date' => '2025-05-01', 'type' => 'Regular'],
			['name' => "Independence Day", 'date' => '2025-06-12', 'type' => 'Regular'],
			['name' => "National Heroes Day", 'date' => '2025-08-25', 'type' => 'Regular'],
			['name' => "Bonifacio Day", 'date' => '2025-09-30', 'type' => 'Regular'],
			['name' => "Christmas Day", 'date' => '2025-12-25', 'type' => 'Regular'],
			['name' => "Rizal Day", 'date' => '2025-12-30', 'type' => 'Regular'],
			//Special Holidays
			['name' => "Chinese New Year", 'date' => '2025-01-29', 'type' => 'Special'],
			['name' => "Black Saturday", 'date' => '2025-04-19', 'type' => 'Special'],
			['name' => "Ninoy Aquino Day", 'date' => '2025-08-21', 'type' => 'Special'],
			['name' => "All Saint's Day Eve", 'date' => '2025-10-31', 'type' => 'Special'],
			['name' => "All Saint's Day", 'date' => '2025-11-01', 'type' => 'Special'],
			['name' => "Immaculate Conception", 'date' => '2025-12-08', 'type' => 'Special'],
			['name' => "Christmas Eve", 'date' => '2025-12-24', 'type' => 'Special'],
			['name' => "New Year's Eve", 'date' => '2025-12-31', 'type' => 'Special'],
		];

		foreach ($holidays as $holiday)
			Holiday::create($holiday);
	}
}

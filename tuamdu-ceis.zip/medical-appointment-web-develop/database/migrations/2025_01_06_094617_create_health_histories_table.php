<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
	/**
	 * Run the migrations.
	 */
	public function up(): void
	{
		Schema::create('health_histories', function (Blueprint $table) {
			$table->id();
			$table->foreignId('patient_id')->unique()->constrained();
			$table->boolean('dpt_opv');
			$table->string('dpt_opv_classification')->nullable();
			$table->boolean('hib');
			$table->string('hib_classification')->nullable();
			$table->boolean('measles_vaccine');
			$table->boolean('mmr');
			$table->text('other_immunizations')->nullable();
			$table->boolean('hepa_a');
			$table->string('hepa_a_classification')->nullable();
			$table->boolean('hepa_b');
			$table->string('hepa_b_classification')->nullable();
			$table->boolean('typhoid_vaccine');
			$table->boolean('influenza');
			$table->text('father_health_history')->nullable();
			$table->text('mother_health_history')->nullable();
			$table->text('siblings_health_history')->nullable();
			$table->text('childhood_illnesses')->nullable();
			$table->text('adult_illnesses')->nullable();
			$table->text('allergies')->nullable();
			$table->string('preferred_hospital')->nullable();
			$table->timestamps();
			$table->softDeletes();
		});
	}

	/**
	 * Reverse the migrations.
	 */
	public function down(): void
	{
		Schema::dropIfExists('health_histories');
	}
};

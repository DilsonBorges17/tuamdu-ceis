<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
	/**
	 * Run the migrations.
	 */
	public function up(): void
	{
		Schema::create('oral_health_conditions', function (Blueprint $table) {
			$table->id();
			$table->date('date');
			$table->foreignId('patient_id')->constrained();
			$table->enum('year', ['1st', '2nd', '3rd', '4th']);
			$table->boolean('debris_tooth_stain');
			$table->boolean('calculus_deposit');
			$table->boolean('gingivitis');
			$table->boolean('periodontal_pocket');
			$table->boolean('orthodontic_treatment');
			$table->text('other_diseases')->nullable();

			// Tooth Count with T and P columns
			$table->integer('teeth_present_total')->nullable();
			$table->integer('teeth_present_permanent')->nullable();

			$table->integer('caries_free_teeth_total')->nullable();
			$table->integer('caries_free_teeth_permanent')->nullable();

			$table->integer('teeth_extraction_total')->nullable();
			$table->integer('teeth_extraction_permanent')->nullable();

			$table->integer('teeth_restoration_total')->nullable();
			$table->integer('teeth_restoration_permanent')->nullable();

			$table->integer('missing_teeth_total')->nullable();
			$table->integer('missing_teeth_permanent')->nullable();

			$table->integer('filled_teeth_total')->nullable();
			$table->integer('filled_teeth_permanent')->nullable();

			$table->integer('df_dmf_teeth_total')->nullable();
			$table->integer('df_dmf_teeth_permanent')->nullable();

			$table->string('examiner')->nullable();

			$table->timestamps();
			$table->softDeletes();
		});
	}

	/**
	 * Reverse the migrations.
	 */
	public function down(): void
	{
		Schema::dropIfExists('oral_health_conditions');
	}
};

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
	/**
	 * Run the migrations.
	 */
	public function up(): void
	{
		Schema::create('physical_exam_records', function (Blueprint $table) {
			$table->id();
			$table->foreignId('patient_id')->constrained('patients');
			$table->foreignId('doctor_id')->constrained('users');
			$table->date('date');
			$table->string('height_weight');
			$table->string('temperature_bp');
			$table->string('hr_pr_rr');
			$table->string('nutritional_status');
			$table->string('visual_activity');
			$table->string('hearing');
			$table->string('skin_scalp');
			$table->string('eyes_ears_nose');
			$table->string('mouth_throat_neck');
			$table->string('lungs_heart');
			$table->string('git_gut');
			$table->string('spine_extremities');
			$table->string('others')->nullable();
			$table->string('recommendations')->nullable();
			$table->enum('year', ['1st', '2nd', '3rd', '4th']);
			$table->timestamps();
			$table->softDeletes();
		});
	}

	/**
	 * Reverse the migrations.
	 */
	public function down(): void
	{
		Schema::dropIfExists('physical_exam_records');
	}
};

<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
	return view('welcome');
});

//Route::get('/mailable', function () {
//	return new App\Mail\PatientRegistered(['password' => 'asgJD03s']);
//});
<?php

use App\Http\Controllers\Patient\AppointmentNotificationController;
use App\Http\Controllers\User\MedicineLogSheetController;
use App\Http\Controllers\User\AuthController as UserAuthController;
use App\Http\Controllers\Patient\AuthController as PatientAuthController;
use App\Http\Controllers\Patient\AppointmentController as PatientAppointmentController;
use App\Http\Controllers\Patient\DentalAppointmentController;
use App\Http\Controllers\Patient\ProfileController as PatientProfileController;
use App\Http\Controllers\Patient\PhysicalExamController as PatientPhysicalExamController;
use App\Http\Controllers\User\PhysicalExamController as UserPhysicalExamController;
use App\Http\Controllers\User\ProfileController as UserProfileController;
use App\Http\Controllers\User\AppointmentController as UserAppointmentController;
use App\Http\Controllers\User\AppointmentScheduleController;
use App\Http\Controllers\User\DepartmentController;
use App\Http\Controllers\User\MedicineController;
use App\Http\Controllers\User\ServiceCategoryController;
use App\Http\Controllers\User\ServiceTypeController;
use App\Http\Controllers\User\ConsultationRecordController;
use App\Http\Controllers\User\DentalHealthStatusController;
use App\Http\Controllers\User\EmergencyCaseController;
use App\Http\Controllers\User\HealthHistoryController;
use App\Http\Controllers\User\MedicalInventoryController;
use App\Http\Controllers\User\NotificationController as AdminNotificationController;
use App\Http\Controllers\User\OralHealthConditionController;
use App\Http\Controllers\User\PatientController;
use App\Http\Controllers\User\PhysicalExamRecordController;
use App\Http\Controllers\User\RoleController;
use App\Http\Controllers\User\UserController;
use Illuminate\Support\Facades\Route;

Route::prefix('user')->group(function () {
	Route::post('/login', [UserAuthController::class, 'login']);

	Route::middleware(['auth:sanctum', 'token_name:user-token'])->group(function () {
		Route::post('/logout', [UserAuthController::class, 'logout']);
		Route::get('/me', [UserAuthController::class, 'me']);

		Route::prefix('profile')->controller(UserProfileController::class)->group(function () {
			Route::patch('/', 'update');
			Route::patch('/password', 'changePassword');
		});

		Route::apiResources([
			'users' => UserController::class,
			'roles' => RoleController::class,
			'departments' => DepartmentController::class,
			'service-types' => ServiceTypeController::class,
			'service-categories' => ServiceCategoryController::class,
			'medicines' => MedicineController::class,
			'appointment-schedules' => AppointmentScheduleController::class,
			'consultation-records' => ConsultationRecordController::class,
			'physical-exam-records' => PhysicalExamRecordController::class,
			'health-histories' => HealthHistoryController::class,
			'oral-health-conditions' => OralHealthConditionController::class,
			'dental-health-statuses' => DentalHealthStatusController::class,
			'medical-inventories' => MedicalInventoryController::class,
		]);

		Route::delete('/oral-health-histories/{oral_health_history_id}', [OralHealthConditionController::class, 'deleteOralHealthHistory']);

		Route::get('/user-roles', [RoleController::class, 'userRoles']);
		Route::get('/patient-roles', [RoleController::class, 'patientRoles']);

		Route::prefix('appointments')->controller(UserAppointmentController::class)->group(function () {
			Route::get('/{service_category_id}', 'appointments');
			Route::patch('status/{appointment_id}', 'updateStatus');
		});

		Route::prefix('physical-exams')->controller(UserPhysicalExamController::class)->group(function () {
			Route::get('/', 'index');
			Route::patch('status/{physical_exam_id}', 'updateStatus');
		});

		Route::apiResource('patients', PatientController::class)->except([
			'store',
			'update',
			'destroy'
		]);

		Route::apiResource('medicine-log-sheets', MedicineLogSheetController::class)->except([
			'update',
		]);

		Route::apiResource('emergency-cases', EmergencyCaseController::class)->except([
			'update',
		]);

		Route::prefix('notifications')->controller(AdminNotificationController::class)->group(function () {
			Route::get('/', 'index');
			Route::get('/all', 'all');
		});
	});
});

Route::prefix('patient')->group(function () {
	Route::get('/departments', [PatientAuthController::class, 'departments']);
	Route::post('/register', [PatientAuthController::class, 'register']);
	Route::post('/login', [PatientAuthController::class, 'login']);

	Route::middleware(['auth:sanctum', 'token_name:patient-token'])->group(function () {
		Route::post('/logout', [PatientAuthController::class, 'logout']);
		Route::get('/me', [PatientAuthController::class, 'me']);


		Route::prefix('profile')->controller(PatientProfileController::class)->group(function () {
			Route::patch('/', 'update');
			Route::patch('/password', 'changePassword');
		});

		Route::prefix('appointments')->controller(PatientAppointmentController::class)->group(function () {
			Route::get('/', 'index');
			Route::post('/', 'store');
			Route::get('/service-categories', 'serviceCategories');
			Route::get('/service-types/{service_category_id}', 'serviceTypes');
			Route::get('/schedules', 'schedules');
			Route::post('/cancel', 'cancelAppointment');
		});

		Route::prefix('dental-appointments')->controller(DentalAppointmentController::class)->group(function () {
			Route::get('/', 'index');
			Route::get('/service-types/{doctor_id}', 'serviceTypes');
		});
		Route::resource('physical-exams', PatientPhysicalExamController::class)->only([
			'index',
			'store',
		]);

		Route::prefix('appointment-notifications')->controller(AppointmentNotificationController::class)->group(function () {
			Route::get('/', 'index');
			Route::patch('/{notification_id}', 'update');
		});
	});
});

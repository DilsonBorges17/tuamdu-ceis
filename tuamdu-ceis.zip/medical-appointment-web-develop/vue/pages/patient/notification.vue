<template>
    <div>
        <div class="max-w-7xl mx-auto">
            <h1 class=" py-5 font-bold text-4xl">Notification</h1>
            <div class=" flex gap-2 divide-x-2 divide-black">
                <div class="p-1 basis-1/3">
                        <button v-for="notification of notifications" :key="notification.id"
                            @click="setCurrentNotification(notification)"
                            class="w-full mt-1 bg-[#D9D9D9] hover:bg-slate-300 rounded flex items-center gap-2">
                        <div
                            class="flex items-center justify-center rounded-full bg-[#d9d9d9] p-1 font-bold text-black">
                            <img src="/email.png" alt="tuaLogo" class="h-auto max-w-6" />
                        </div>
                        <p class="font-semibold">From: TUA-MDU</p>
                    </button>
                </div>
                <div class="basis-2/3 px-8 py-5">
                    <p v-if="Object.keys(current_notifications).length === 0" class="text-center italic">Select from the
                        notification list on the side to view more details</p>
                    <div v-if="Object.keys(current_notifications).length > 0">
                        <div class="flex items-center justify-between gap-2">
                            <h2 class="font-semibold">From: TUA-MDU</h2>
                            <button @click="markAsRead(current_notifications.data.id)"
                                class="text-sm bg-slate-200 hover:bg-slate-300 p-2">Mark as read</button>
                        </div>
                        <div v-if="current_notifications.data.type === 'appointment-queued'">
                            <p class="mt-5">
                                Hi, {{ current_notifications.data.data.patient.first_name }} {{
                                    current_notifications.data.data.patient.last_name }}
                            </p>
                            <p class="mt-5">
                                Thank you for making an appointment to TUA-MDU ({{
                                    current_notifications.data.data.schedule.service_type.category.name }}), Your current
                                appointment
                                time is "{{
                                    current_notifications.data.data.schedule.start_time }}" and your queuing number is "{{
                                    current_notifications.data.data.queuing_number }}"
                            </p>
                            <p class="mt-5">Please be on time, Thank you!</p>
                        </div>
                        <div v-if="current_notifications.data.type === 'user-cancelled-appointment'">
                            <p class="mt-5">
                                Good Day! Your appointment of  {{current_notifications.data.data.appointment.schedule.service_type.name}} with queuing no.  {{current_notifications.data.data.appointment.queuing_number}} has been cancelled due to {{current_notifications.data.data.reason}} by Dr. {{current_notifications.data.data.doctor.first_name}} {{current_notifications.data.data.doctor.last_name}}
                            </p>                           
                           
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup>
import { useAuthStore } from "~/stores/auth";
import axios from 'axios'
import { reactive } from 'vue';

definePageMeta({
    layout: "patient",
});

const authStore = useAuthStore();
const notifications = ref([]);
const current_notifications = reactive({});

const setCurrentNotification = (notification) => {
    current_notifications.data = notification;
};

const markAsRead = async (id) => {
    await axios.patch(
        `${useRuntimeConfig().public.laravelURL}patient/appointment-notifications/${id}`, {}, {
        headers: {
            Authorization: `Bearer ${authStore.token}`
        }
    }
    );
    window.location.reload();
};


const fetchNotifications = async () => {
    const { data } = await axios.get(
        `${useRuntimeConfig().public.laravelURL}patient/appointment-notifications`, {
        headers: {
            Authorization: `Bearer ${authStore.token}`
        }
    }
    );
    notifications.value = data;
};

onMounted(async () => {
    await fetchNotifications();
});

</script>
<template>
    <div class="mt-16 grid text-center">
        <h1 class="text-3xl font-bold">Update successfully!</h1>
        <NuxtLink
            to="/patient"
            class="mx-auto mt-10 rounded-md bg-[#347956] px-10 py-2 font-bold text-white hover:bg-emerald-900"
            >OK</NuxtLink
        >
    </div>
</template>

<script setup>
definePageMeta({
    layout: "selection",
});
</script>

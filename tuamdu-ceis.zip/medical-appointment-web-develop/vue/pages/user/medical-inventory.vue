<template>
    <div>
        <!-- TITLE AND SEARCH -->
        <div class="mt-7 flex items-center justify-between">
            <h1 class="text-xl font-bold sm:text-5xl">Medical Inventory</h1>
        </div>

        <!-- ADD INVENTORY -->
        <div class="ml-2 mt-5 flex gap-2">
            <NuxtLink
                class="bg-[#928f8f] px-4 py-2 font-bold text-white hover:bg-[#d9d9d9] hover:text-black"
                to="/user/medicine-inventory"
            >
                Medicine
            </NuxtLink>
            <NuxtLink
                class="bg-[#d9d9d9] px-4 py-2 font-bold text-black"
                to="#"
            >
                Tool
            </NuxtLink>
        </div>
        <form
            @submit.prevent="openModal"
            class="grid rounded-md border border-black bg-[#e0dcdc] p-8"
        >
            <div class="grid items-center gap-5 md:grid-cols-3 lg:grid-cols-5">
                <div class="w-full">
                    <label class="block text-lg font-bold" for="category"
                        >Category:</label
                    >
                    <select
                        class="mt-2 w-full rounded border-2 border-black focus:outline-emerald-800"
                        name="category"
                        id="category"
                        v-model="formData.medicine_category"
                    >
                        <option value="Disinfectants">Disinfectants</option>
                        <option value="Wound Care Supplies">
                            Wound Care Supplies
                        </option>
                        <option value="Lubricants">Lubricants</option>
                        <option value="Personal Protective Equipment (PPE)">
                            Personal Protective Equipment (PPE)
                        </option>
                        <option value="Medical Instruments">
                            Medical Instruments
                        </option>
                        <option value="Fluids / Irrigants">
                            Fluids / Irrigants
                        </option>
                        <option value="General Medical Supplies">
                            General Medical Supplies
                        </option>
                    </select>
                    <p
                        v-if="
                            submitErrorMessages &&
                            submitErrorMessages.medicine_category
                        "
                        class="text-red-500"
                    >
                        {{ submitErrorMessages.medicine_category[0] }}
                    </p>
                </div>
                <div class="w-full">
                    <label class="block text-lg font-bold" for="toolName"
                        >Tool Name:</label
                    >
                    <input
                        class="w-full rounded border-2 border-black focus:outline-emerald-800"
                        type="text"
                        name="toolName"
                        id="toolName"
                        v-model="formData.tool_name"
                    />
                    <p
                        v-if="
                            submitErrorMessages && submitErrorMessages.tool_name
                        "
                        class="text-red-500"
                    >
                        {{ submitErrorMessages.tool_name[0] }}
                    </p>
                </div>
                <div class="w-full">
                    <label class="block text-lg font-bold" for="volume"
                        >Volume:</label
                    >
                    <input
                        class="w-full rounded border-2 border-black focus:outline-emerald-800"
                        type="text"
                        name="volume"
                        id="volume"
                        v-model="formData.volume"
                    />
                    <p
                        v-if="submitErrorMessages && submitErrorMessages.volume"
                        class="text-red-500"
                    >
                        {{ submitErrorMessages.volume[0] }}
                    </p>
                </div>
                <div class="w-full">
                    <label class="block text-lg font-bold" for="quantity"
                        >Quantity:</label
                    >
                    <input
                        class="w-full rounded border-2 border-black focus:outline-emerald-800"
                        type="number"
                        name="quantity"
                        id="quantity"
                        v-model="formData.quantity"
                    />
                    <p
                        v-if="
                            submitErrorMessages && submitErrorMessages.quantity
                        "
                        class="text-red-500"
                    >
                        {{ submitErrorMessages.quantity[0] }}
                    </p>
                </div>
                <div class="w-full">
                    <label class="block text-lg font-bold" for="expirationDate"
                        >Expiration Date:</label
                    >
                    <input
                        class="w-full rounded border-2 border-black px-4 py-1 focus:outline-emerald-800"
                        type="date"
                        id="expirationDate"
                        name="expirationDate"
                        :min="currentDate"
                        v-model="formData.expiration_date"
                    />
                    <p
                        v-if="
                            submitErrorMessages &&
                            submitErrorMessages.expiration_date
                        "
                        class="text-red-500"
                    >
                        {{ submitErrorMessages.expiration_date[0] }}
                    </p>
                </div>
            </div>
            <button
                :disabled="isAdding"
                type="submit"
                class="mx-auto mt-5 rounded-md bg-[#1E3D2C] px-6 py-2 font-semibold text-white hover:bg-emerald-900 sm:px-12"
            >
                {{ isAdding ? "ADDING..." : "Add to Medicine Inventory " }}
            </button>
        </form>

        <div
            class="mb-2 mt-7 flex flex-wrap items-center justify-between gap-2"
        >
            <!-- SEARCH -->
            <div class="relative">
                <input
                    type="text"
                    v-model="searchTerm"
                    class="search-input rounded-md border border-gray-300 py-2 pl-10 pr-4 focus:outline-none focus:ring-2"
                    placeholder="Search Tool Name..."
                />
                <svg
                    class="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 transform text-gray-400"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke-width="2"
                    stroke="currentColor"
                    aria-hidden="true"
                >
                    <path
                        stroke-linecap="round"
                        stroke-linejoin="round"
                        d="M21 21l-4.35-4.35M17 10a7 7 0 10-14 0 7 7 0 0014 0z"
                    />
                </svg>
            </div>
            <div>
                <button
                    @click="print"
                    class="rounded-md bg-yellow-500 p-2 text-white hover:bg-yellow-700"
                >
                    Print Table
                </button>
            </div>
        </div>
        <!-- TABLE -->
        <div class="overflow-x-auto">
            <table id="myTable" class="w-full table-auto text-left">
                <thead class="text-white">
                    <tr class="bg-[#1e3d2c]">
                        <th class="whitespace-nowrap p-5">Category</th>
                        <th
                            class="flex cursor-pointer items-center gap-2 whitespace-nowrap p-5"
                            @click="sort('tool_name')"
                        >
                            Tool Name
                            <Icon
                                :class="isSort ? '' : 'rotate-180'"
                                class="transition-transform duration-200"
                                name="ep:arrow-down"
                                style="color: white"
                            />
                        </th>
                        <th class="whitespace-nowrap p-5">Volume</th>
                        <th class="whitespace-nowrap p-5">Quantity</th>
                        <th class="whitespace-nowrap p-5">Exp. Date</th>
                        <th class="whitespace-nowrap p-5">Action</th>
                    </tr>
                </thead>
                <tbody class="whitespace-nowrap">
                    <template v-if="isLoading">
                        <tr>
                            <td colspan="7" class="text-center"><Spinner /></td>
                        </tr>
                    </template>
                    <template v-if="!isLoading">
                        <template v-if="filteredRecords.length > 0">
                            <tr
                                class="odd:bg-[#D9D9D9] even:bg-white"
                                v-for="(item, index) in filteredRecords"
                                :key="index"
                            >
                                <td class="p-5 font-medium">
                                    {{ item.medicine_category }}
                                </td>
                                <td class="p-5 font-medium">
                                    {{ item.tool_name }}
                                </td>
                                <td class="p-5 font-medium">
                                    {{ item.volume }}
                                </td>
                                <td class="p-5 font-medium">
                                    {{ item.quantity }}
                                </td>
                                <td class="p-5 font-medium">
                                    {{ item.expiration_date }}
                                </td>
                                <td class="pl-7">
                                    <button @click="deleteTool(item.id)">
                                        <Icon
                                            class="text-red-500 hover:text-red-900"
                                            name="ep:delete"
                                            style="font-size: 2rem"
                                        />
                                    </button>
                                    <!-- <button @click="openDialog()">
                                        <Icon
                                            class="text-green-500 hover:text-red-900"
                                            name="i-material-symbols-light-edit-outline-sharp"
                                            style="font-size: 2rem"
                                        />
                                    </button> -->
                                </td>
                            </tr>
                        </template>
                        <template v-else>
                            <tr>
                                <td
                                    colspan="6"
                                    class="p-5 text-center text-gray-500"
                                >
                                    No Records Found
                                </td>
                            </tr>
                        </template>
                    </template>
                </tbody>
            </table>
        </div>

        <!-- Dialog element -->
        <dialog ref="myDialog">
            <form
                @submit.prevent="handleSubmit"
                class="mt-5 grid bg-[#e0dcdc] p-8"
            >
                <div class="w-full">
                    <label class="block text-lg font-bold" for="category"
                        >Category:</label
                    >
                    <select
                        class="mt-2 w-full rounded border-2 border-black focus:outline-emerald-800"
                        name="category"
                        id="category"
                        v-model="formData.medicine_category"
                    >
                        <option value="Diagnostic">Diagnostic</option>
                        <option value="Disinfectants">Disinfectants</option>
                        <option value="Surgical">Surgical</option>
                        <option value="Therapeutic">Therapeutic</option>
                        <option value="Laboratory">Laboratory</option>
                    </select>
                    <p
                        v-if="
                            submitErrorMessages &&
                            submitErrorMessages.medicine_category
                        "
                        class="text-red-500"
                    >
                        {{ submitErrorMessages.medicine_category[0] }}
                    </p>
                </div>
                <div class="w-full">
                    <label class="block text-lg font-bold" for="genericName"
                        >Generic Name:</label
                    >
                    <input
                        class="w-full rounded border-2 border-black focus:outline-emerald-800"
                        type="text"
                        name="genericName"
                        id="genericName"
                        v-model="formData.generic_name"
                    />
                    <p
                        v-if="
                            submitErrorMessages &&
                            submitErrorMessages.generic_name
                        "
                        class="text-red-500"
                    >
                        {{ submitErrorMessages.generic_name[0] }}
                    </p>
                </div>
                <div class="w-full">
                    <label class="block text-lg font-bold" for="brandName"
                        >Brand Name:</label
                    >
                    <input
                        class="w-full rounded border-2 border-black focus:outline-emerald-800"
                        type="text"
                        name="brandName"
                        id="brandName"
                        v-model="formData.brand_name"
                    />
                    <p
                        v-if="
                            submitErrorMessages &&
                            submitErrorMessages.brand_name
                        "
                        class="text-red-500"
                    >
                        {{ submitErrorMessages.brand_name[0] }}
                    </p>
                </div>

                <div class="w-full">
                    <label class="block text-lg font-bold" for="dosage"
                        >Dosage:</label
                    >
                    <select
                        class="w-full rounded border-2 border-black focus:outline-emerald-800"
                        name="dosage"
                        id="dosage"
                        v-model="formData.dosage"
                    >
                        <option value="1mg">1 mg</option>
                        <option value="5mg">5 mg</option>
                        <option value="10mg">10 mg</option>
                        <option value="25mg">25 mg</option>
                        <option value="50mg">50 mg</option>
                        <option value="100mg">100 mg</option>
                        <option value="200mg">200 mg</option>
                        <option value="500mg">500 mg</option>
                        <option value="1mL">1 mL</option>
                        <option value="5mL">5 mL</option>
                        <option value="10mL">10 mL</option>
                        <option value="1tablet">1 Tablet</option>
                        <option value="2tablets">2 Tablets</option>
                        <option value="1puff">1 Puff</option>
                    </select>
                    <p
                        v-if="submitErrorMessages && submitErrorMessages.dosage"
                        class="text-red-500"
                    >
                        {{ submitErrorMessages.dosage[0] }}
                    </p>
                </div>
                <div class="w-full">
                    <label class="block text-lg font-bold" for="quantity"
                        >Quantity:</label
                    >
                    <input
                        class="w-full rounded border-2 border-black focus:outline-emerald-800"
                        type="number"
                        name="quantity"
                        id="quantity"
                        v-model="formData.quantity"
                    />
                    <p
                        v-if="
                            submitErrorMessages && submitErrorMessages.quantity
                        "
                        class="text-red-500"
                    >
                        {{ submitErrorMessages.quantity[0] }}
                    </p>
                </div>
                <div class="w-full">
                    <label class="block text-lg font-bold" for="expirationDate"
                        >Expiration Date:</label
                    >
                    <input
                        class="w-full rounded border-2 border-black px-4 py-1 focus:outline-emerald-800"
                        type="date"
                        id="expirationDate"
                        name="expirationDate"
                        :min="currentDate"
                        v-model="formData.expiration_date"
                    />
                    <p
                        v-if="
                            submitErrorMessages &&
                            submitErrorMessages.expiration_date
                        "
                        class="text-red-500"
                    >
                        {{ submitErrorMessages.expiration_date[0] }}
                    </p>
                </div>

                <button
                    :disabled="isAdding"
                    type="submit"
                    class="mt-5 rounded-md bg-[#1E3D2C] px-6 py-2 font-semibold text-white hover:bg-emerald-900"
                >
                    {{ isAdding ? "EDITTING..." : "EDIT MEDICINE" }}
                </button>
                <button
                    type="button"
                    @click="() => closeDialog()"
                    class="mt-2 rounded-md bg-red-500 px-6 py-2 font-semibold text-white hover:bg-red-900"
                >
                    Cancel
                </button>
            </form>
        </dialog>
        <Modal
            v-if="isModalOpen"
            @cancel="closeModal"
            @confirm="handleSubmit"
            message="You want to add this in your Equipment Inventory?"
        />
    </div>
</template>

<script setup>
import axios from "axios";
import { useAuthStore } from "~/stores/auth";
import { toast } from "vue3-toastify";
import "vue3-toastify/dist/index.css";

definePageMeta({
    layout: "user",
    middleware: ["medical-nurse"],
});

const isModalOpen = ref(false);
const myDialog = ref(null);
const isLoading = ref(true);
const authStore = useAuthStore();
const searchTerm = ref("");
const currentDate = ref("");
const role = ref("");
const submitErrorMessages = ref("");
const isAdding = ref(false);
const medicalTools = ref([]);
const isSort = ref(false);

const initialFormData = ref({
    medicine_category: "",
    tool_name: "",
    volume: "",
    quantity: "",
    expiration_date: "",
});

const formData = ref({
    medicine_category: "",
    tool_name: "",
    volume: "",
    quantity: "",
    expiration_date: "",
});

const closeDialog = () => {
    if (myDialog.value) {
        myDialog.value.close();
    }
};
const openDialog = () => {
    if (myDialog.value) {
        myDialog.value.showModal();
    }
};

const openModal = () => {
    isModalOpen.value = true;
};

const closeModal = () => {
    isModalOpen.value = false;
};

const fetchMedicalTools = async () => {
    isLoading.value = true;
    try {
        const response = await axios.get(
            `${useRuntimeConfig().public.laravelURL}user/medical-inventories`,
            {
                headers: {
                    Authorization: `Bearer ${authStore.token}`,
                },
            },
        );

        medicalTools.value = response.data;
        submitErrorMessages.value = "";
        formData.value = { ...initialFormData.value };
    } catch (error) {
        console.log("error fetching Medicines");
    } finally {
        isLoading.value = false;
    }
};

const filteredRecords = computed(() => {
    if (!searchTerm.value) {
        return medicalTools.value;
    }
    return medicalTools.value.filter((item) => {
        return (
            item.brand_name
                .toLowerCase()
                .includes(searchTerm.value.toLowerCase()) ||
            item.generic_name
                .toLowerCase()
                .includes(searchTerm.value.toLowerCase())
        );
    });
});

const handleSubmit = async () => {
    isAdding.value = true;
    try {
        await axios.post(
            `${useRuntimeConfig().public.laravelURL}user/medical-inventories`,
            formData.value,
            {
                headers: {
                    Authorization: `Bearer ${authStore.token}`,
                },
            },
        );
        toast.success("Record added successfully");
        fetchMedicalTools();
    } catch (error) {
        submitErrorMessages.value = error.response.data.errors;
        console.log("Error Submitting");
    } finally {
        isAdding.value = false;
        isModalOpen.value = false;
    }
};

const deleteTool = async (medicine_id) => {
    try {
        await axios.delete(
            `${useRuntimeConfig().public.laravelURL}user/medical-inventories/${medicine_id}`,
            {
                headers: {
                    Authorization: `Bearer ${authStore.token}`,
                },
            },
        );
        toast.success("Record deleted successfully");
        fetchMedicalTools();
    } catch (error) {
        console.log("Error Deleting Medicine");
    }
};

const fetchRole = () => {
    role.value = authStore.role;
};

const sort = async (name) => {
    isSort.value = !isSort.value;

    if (isSort.value) {
        filteredRecords.value = medicalTools.value.sort((a, b) => {
            return a.tool_name.localeCompare(b.tool_name);
        });
    } else {
        filteredRecords.value = medicalTools.value.sort((a, b) => {
            return b.tool_name.localeCompare(a.tool_name);
        });
    }
};

const print = () => {
    const printContent = document.getElementById("myTable").outerHTML;
    const printWindow = window.open("", "", "height=600,width=800");
    printWindow.document.write(
        "<html><head><title>Print Table</title></head><body>",
    );
    printWindow.document.write(printContent);
    printWindow.document.write("</body></html>");
    printWindow.document.close();
    printWindow.print();
};

fetchRole();
onMounted(async () => {
    try {
        await fetchMedicalTools();
    } catch (error) {
        console.log("Error in medicine inventory page: ", error);
    }
});

const today = new Date();
const year = today.getFullYear();
const month = String(today.getMonth() + 1).padStart(2, "0");
const day = String(today.getDate()).padStart(2, "0");
currentDate.value = `${year}-${month}-${day}`;
</script>

<style>
::backdrop {
    background-color: rgba(0, 0, 0, 0.9);
}

@media print {
    * {
        display: none;
    }
    table {
        display: block;
    }
}
</style>

<template>
    <div class="mx-auto mt-16 max-w-7xl">
        <div class="flex flex-wrap">
            <NuxtLink
                class="rounded-md border border-black bg-[#a6a6a6] px-4 py-2 font-bold text-black hover:bg-[#d9d9d9]"
                :to="`/user/dental-health-record/${itemId}`"
                >Dental Health Record</NuxtLink
            >
            <NuxtLink
                class="rounded-md border border-black bg-[#a6a6a6] px-4 py-2 font-bold text-black hover:bg-[#d9d9d9]"
                to="#"
                >Health History</NuxtLink
            >
            <NuxtLink
                class="rounded-md border border-black bg-[#a6a6a6] px-4 py-2 font-bold text-black hover:bg-[#d9d9d9]"
                :to="`/user/dental-health-record/${itemId}-oral-health-condition`"
                >Oral Health Condition</NuxtLink
            >
            <NuxtLink
                class="rounded-md border border-black bg-[#a6a6a6] px-4 py-2 font-bold text-black hover:bg-[#d9d9d9]"
                :to="`/user/dental-health-record/${itemId}-consultation-record`"
                >Consultation Record</NuxtLink
            >
        </div>
        <div v-if="isLoading">
            <Spinner />
        </div>
        <div v-if="!isLoading">
            <div>
                <div
                    class="grid gap-4 rounded-md border border-black bg-white px-2 py-8 shadow-lg sm:px-10"
                >
                    <div class="flex flex-col items-center justify-center">
                        <img src="/tua-logo.png" alt="logo" />
                        <h1 class="text-2xl uppercase">
                            Trinity University of Asia
                        </h1>
                        <p>Medical and Dental Unit</p>
                    </div>
                    <h2 class="bg-black text-center font-bold text-white">
                        Health History
                    </h2>
                    <div class="flex flex-col overflow-x-auto">
                        <img src="/1.png" alt="" />
                        <table class="w-full border border-black">
                            <thead class="bg-[#e0dcdc]">
                                <tr>
                                    <td
                                        class="border border-black px-5 py-1"
                                    ></td>
                                    <td
                                        class="border border-black px-5 py-1"
                                    ></td>
                                    <td
                                        class="border border-black px-5 py-1"
                                    ></td>
                                    <td
                                        class="border border-black px-5 py-1"
                                    ></td>
                                    <td class="border border-black px-5 py-1">
                                        E
                                    </td>
                                    <td class="border border-black px-5 py-1">
                                        D
                                    </td>
                                    <td class="border border-black px-5 py-1">
                                        C
                                    </td>
                                    <td class="border border-black px-5 py-1">
                                        B
                                    </td>
                                    <td class="border border-black px-5 py-1">
                                        A
                                    </td>
                                    <td class="border border-black px-5 py-1">
                                        A
                                    </td>
                                    <td class="border border-black px-5 py-1">
                                        B
                                    </td>
                                    <td class="border border-black px-5 py-1">
                                        C
                                    </td>
                                    <td class="border border-black px-5 py-1">
                                        D
                                    </td>
                                    <td class="border border-black px-5 py-1">
                                        E
                                    </td>
                                    <td
                                        class="border border-black px-5 py-1"
                                    ></td>
                                    <td
                                        class="border border-black px-5 py-1"
                                    ></td>
                                    <td
                                        class="border border-black px-5 py-1"
                                    ></td>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td class="border border-black px-5 py-1">
                                        OPERATION
                                    </td>
                                    <td
                                        v-for="(operation, index) in [
                                            1, 2, 3, 4, 5, 6, 7, 8,
                                        ]"
                                        :key="index"
                                        class="border border-black px-5 py-1"
                                    >
                                        <input
                                            :disabled="!isEditMode"
                                            v-model="
                                                formData[
                                                    `ul_labial_operation_${index + 1}`
                                                ]
                                            "
                                            type="text"
                                            class="w-10 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        v-for="(operation, index) in [
                                            1, 2, 3, 4, 5, 6, 7, 8,
                                        ]"
                                        :key="index"
                                        class="border border-black px-5 py-1"
                                    >
                                        <input
                                            :disabled="!isEditMode"
                                            v-model="
                                                formData[
                                                    `ur_labial_operation_${index + 1}`
                                                ]
                                            "
                                            type="text"
                                            class="w-10 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                </tr>
                                <tr>
                                    <td class="border border-black px-5 py-1">
                                        CONDITION
                                    </td>
                                    <td
                                        v-for="(operation, index) in [
                                            1, 2, 3, 4, 5, 6, 7, 8,
                                        ]"
                                        :key="index"
                                        class="border border-black px-5 py-1"
                                    >
                                        <input
                                            :disabled="!isEditMode"
                                            v-model="
                                                formData[
                                                    `ul_labial_condition_${index + 1}`
                                                ]
                                            "
                                            type="text"
                                            class="w-10 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        v-for="(operation, index) in [
                                            1, 2, 3, 4, 5, 6, 7, 8,
                                        ]"
                                        :key="index"
                                        class="border border-black px-5 py-1"
                                    >
                                        <input
                                            :disabled="!isEditMode"
                                            v-model="
                                                formData[
                                                    `ur_labial_condition_${index + 1}`
                                                ]
                                            "
                                            type="text"
                                            class="w-10 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <img src="/2.png" alt="" />
                        <table class="w-full border border-black">
                            <thead class="bg-[#e0dcdc]">
                                <tr>
                                    <td
                                        class="border border-black px-5 py-1"
                                    ></td>
                                    <td
                                        class="border border-black px-5 py-1"
                                    ></td>
                                    <td
                                        class="border border-black px-5 py-1"
                                    ></td>
                                    <td
                                        class="border border-black px-5 py-1"
                                    ></td>
                                    <td class="border border-black px-5 py-1">
                                        E
                                    </td>
                                    <td class="border border-black px-5 py-1">
                                        D
                                    </td>
                                    <td class="border border-black px-5 py-1">
                                        C
                                    </td>
                                    <td class="border border-black px-5 py-1">
                                        B
                                    </td>
                                    <td class="border border-black px-5 py-1">
                                        A
                                    </td>
                                    <td class="border border-black px-5 py-1">
                                        A
                                    </td>
                                    <td class="border border-black px-5 py-1">
                                        B
                                    </td>
                                    <td class="border border-black px-5 py-1">
                                        C
                                    </td>
                                    <td class="border border-black px-5 py-1">
                                        D
                                    </td>
                                    <td class="border border-black px-5 py-1">
                                        E
                                    </td>
                                    <td
                                        class="border border-black px-5 py-1"
                                    ></td>
                                    <td
                                        class="border border-black px-5 py-1"
                                    ></td>
                                    <td
                                        class="border border-black px-5 py-1"
                                    ></td>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td class="border border-black px-5 py-1">
                                        OPERATION
                                    </td>
                                    <td
                                        v-for="(operation, index) in [
                                            1, 2, 3, 4, 5, 6, 7, 8,
                                        ]"
                                        :key="index"
                                        class="border border-black px-5 py-1"
                                    >
                                        <input
                                            :disabled="!isEditMode"
                                            v-model="
                                                formData[
                                                    `ll_lingual_operation_${index + 1}`
                                                ]
                                            "
                                            type="text"
                                            class="w-10 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        v-for="(operation, index) in [
                                            1, 2, 3, 4, 5, 6, 7, 8,
                                        ]"
                                        :key="index"
                                        class="border border-black px-5 py-1"
                                    >
                                        <input
                                            :disabled="!isEditMode"
                                            v-model="
                                                formData[
                                                    `lr_lingual_operation_${index + 1}`
                                                ]
                                            "
                                            type="text"
                                            class="w-10 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                </tr>
                                <tr>
                                    <td class="border border-black px-5 py-1">
                                        CONDITION
                                    </td>
                                    <td
                                        v-for="(operation, index) in [
                                            1, 2, 3, 4, 5, 6, 7, 8,
                                        ]"
                                        :key="index"
                                        class="border border-black px-5 py-1"
                                    >
                                        <input
                                            :disabled="!isEditMode"
                                            v-model="
                                                formData[
                                                    `ll_lingual_condition_${index + 1}`
                                                ]
                                            "
                                            type="text"
                                            class="w-10 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        v-for="(operation, index) in [
                                            1, 2, 3, 4, 5, 6, 7, 8,
                                        ]"
                                        :key="index"
                                        class="border border-black px-5 py-1"
                                    >
                                        <input
                                            :disabled="!isEditMode"
                                            v-model="
                                                formData[
                                                    `lr_lingual_condition_${index + 1}`
                                                ]
                                            "
                                            type="text"
                                            class="w-10 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="overflow-x-auto">
                        <table class="w-full border border-black bg-slate-200">
                            <tbody>
                                <tr
                                    class="border border-black odd:bg-[#d9d9d9]"
                                >
                                    <td
                                        colspan="4"
                                        class="border border-black pl-2 text-lg font-bold"
                                    >
                                        LEGEND
                                    </td>
                                </tr>
                                <tr
                                    class="border border-black text-center even:bg-white"
                                >
                                    <td
                                        colspan="4"
                                        class="border border-black italic"
                                    >
                                        Caries Free
                                    </td>
                                </tr>
                                <tr
                                    class="border border-black odd:bg-[#d9d9d9]"
                                >
                                    <td class="border border-black">
                                        C - Carious Tooth
                                    </td>
                                    <td class="border border-black">
                                        Un - Unerupted
                                    </td>
                                    <td class="border border-black">
                                        Gf - Gold Filling
                                    </td>
                                    <td class="border border-black">
                                        Ab - Abutment
                                    </td>
                                </tr>
                                <tr class="border border-black even:bg-white">
                                    <td class="border border-black">
                                        X - Indicated for Extraction
                                    </td>
                                    <td class="border border-black">
                                        Tf - Temporary Filling
                                    </td>
                                    <td class="border border-black">
                                        Jc - Jacket Crown
                                    </td>
                                    <td class="border border-black">
                                        Sc - Special Crown
                                    </td>
                                </tr>
                                <tr
                                    class="border border-black odd:bg-[#d9d9d9]"
                                >
                                    <td class="border border-black">
                                        Rf - Root Fragment
                                    </td>
                                    <td class="border border-black">
                                        Am - Amalgam Filling
                                    </td>
                                    <td class="border border-black">
                                        S - Sealant
                                    </td>
                                    <td class="border border-black">
                                        P - Pontic
                                    </td>
                                </tr>
                                <tr class="border border-black even:bg-white">
                                    <td class="border border-black">
                                        M - Missing / Extracted
                                    </td>
                                    <td class="border border-black">
                                        Co - Composite Filling
                                    </td>
                                    <td class="border border-black">
                                        Fb - Fixed Bridge
                                    </td>
                                    <td class="border border-black">
                                        CD - Complete Denture
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div v-if="role != 'Dental Doctor'" class="mt-8 flex flex-col items-center gap-2">
                    <template v-if="!isEditMode">
                        <button
                            class="w-full rounded-md bg-[#347956] px-14 py-1 font-medium text-white hover:bg-emerald-800 md:w-1/3"
                            type="button"
                            @click="toggleEditMode()"
                        >
                            EDIT
                        </button>
                    </template>

                    <template v-if="isEditMode">
                        <button
                            class="w-full rounded-md bg-red-500 px-14 py-1 font-medium text-white hover:bg-red-800 md:w-1/3"
                            type="button"
                            @click="refresh()"
                        >
                            CANCEL
                        </button>
                        <button
                            class="w-full rounded-md bg-[#347956] px-14 py-1 font-medium text-white hover:bg-emerald-800 md:w-1/3"
                            type="button"
                            @click="openModal()"
                        >
                            ADD
                        </button>
                    </template>
                </div>
            </div>
        </div>
        <Modal
            v-if="isModalOpen"
            @cancel="closeModal"
            @confirm="handleSubmit"
            message="You want to update this?"
        />
    </div>
</template>
<script setup>
import axios from "axios";
import { useAuthStore } from "~/stores/auth";
import { toast } from "vue3-toastify";
import "vue3-toastify/dist/index.css";

definePageMeta({
    layout: "user",
    middleware: ["dental-doctor"],
});

const isModalOpen = ref(false);
const route = useRoute();
const itemId = route.params.id;
const authStore = useAuthStore();
const isLoading = ref(true);
const role = ref("");
const history = ref(null);
const isEditMode = ref(false);
const records = ref([]);

const initialFormData = ref({
    ur_labial_operation_1: "",
    ur_labial_operation_2: "",
    ur_labial_operation_3: "",
    ur_labial_operation_4: "",
    ur_labial_operation_5: "",
    ur_labial_operation_6: "",
    ur_labial_operation_7: "",
    ur_labial_operation_8: "",

    ur_labial_condition_1: "",
    ur_labial_condition_2: "",
    ur_labial_condition_3: "",
    ur_labial_condition_4: "",
    ur_labial_condition_5: "",
    ur_labial_condition_6: "",
    ur_labial_condition_7: "",
    ur_labial_condition_8: "",

    ul_labial_operation_1: "",
    ul_labial_operation_2: "",
    ul_labial_operation_3: "",
    ul_labial_operation_4: "",
    ul_labial_operation_5: "",
    ul_labial_operation_6: "",
    ul_labial_operation_7: "",
    ul_labial_operation_8: "",

    ul_labial_condition_1: "",
    ul_labial_condition_2: "",
    ul_labial_condition_3: "",
    ul_labial_condition_4: "",
    ul_labial_condition_5: "",
    ul_labial_condition_6: "",
    ul_labial_condition_7: "",
    ul_labial_condition_8: "",

    lr_lingual_operation_1: "",
    lr_lingual_operation_2: "",
    lr_lingual_operation_3: "",
    lr_lingual_operation_4: "",
    lr_lingual_operation_5: "",
    lr_lingual_operation_6: "",
    lr_lingual_operation_7: "",
    lr_lingual_operation_8: "",

    lr_lingual_condition_1: "",
    lr_lingual_condition_2: "",
    lr_lingual_condition_3: "",
    lr_lingual_condition_4: "",
    lr_lingual_condition_5: "",
    lr_lingual_condition_6: "",
    lr_lingual_condition_7: "",
    lr_lingual_condition_8: "",

    ll_lingual_operation_1: "",
    ll_lingual_operation_2: "",
    ll_lingual_operation_3: "",
    ll_lingual_operation_4: "",
    ll_lingual_operation_5: "",
    ll_lingual_operation_6: "",
    ll_lingual_operation_7: "",
    ll_lingual_operation_8: "",

    ll_lingual_condition_1: "",
    ll_lingual_condition_2: "",
    ll_lingual_condition_3: "",
    ll_lingual_condition_4: "",
    ll_lingual_condition_5: "",
    ll_lingual_condition_6: "",
    ll_lingual_condition_7: "",
    ll_lingual_condition_8: "",
    patient_id_number: itemId,
});

const formData = ref({
    ur_labial_operation_1: "",
    ur_labial_operation_2: "",
    ur_labial_operation_3: "",
    ur_labial_operation_4: "",
    ur_labial_operation_5: "",
    ur_labial_operation_6: "",
    ur_labial_operation_7: "",
    ur_labial_operation_8: "",

    ur_labial_condition_1: "",
    ur_labial_condition_2: "",
    ur_labial_condition_3: "",
    ur_labial_condition_4: "",
    ur_labial_condition_5: "",
    ur_labial_condition_6: "",
    ur_labial_condition_7: "",
    ur_labial_condition_8: "",

    ul_labial_operation_1: "",
    ul_labial_operation_2: "",
    ul_labial_operation_3: "",
    ul_labial_operation_4: "",
    ul_labial_operation_5: "",
    ul_labial_operation_6: "",
    ul_labial_operation_7: "",
    ul_labial_operation_8: "",

    ul_labial_condition_1: "",
    ul_labial_condition_2: "",
    ul_labial_condition_3: "",
    ul_labial_condition_4: "",
    ul_labial_condition_5: "",
    ul_labial_condition_6: "",
    ul_labial_condition_7: "",
    ul_labial_condition_8: "",

    ul_lingual_operation_1: "",
    ul_lingual_operation_2: "",
    ul_lingual_operation_3: "",
    ul_lingual_operation_4: "",
    ul_lingual_operation_5: "",
    ul_lingual_operation_6: "",
    ul_lingual_operation_7: "",
    ul_lingual_operation_8: "",

    ur_lingual_operation_1: "",
    ur_lingual_operation_2: "",
    ur_lingual_operation_3: "",
    ur_lingual_operation_4: "",
    ur_lingual_operation_5: "",
    ur_lingual_operation_6: "",
    ur_lingual_operation_7: "",
    ur_lingual_operation_8: "",

    ll_lingual_condition_1: "",
    ll_lingual_condition_2: "",
    ll_lingual_condition_3: "",
    ll_lingual_condition_4: "",
    ll_lingual_condition_5: "",
    ll_lingual_condition_6: "",
    ll_lingual_condition_7: "",
    ll_lingual_condition_8: "",

    lr_lingual_condition_1: "",
    lr_lingual_condition_2: "",
    lr_lingual_condition_3: "",
    lr_lingual_condition_4: "",
    lr_lingual_condition_5: "",
    lr_lingual_condition_6: "",
    lr_lingual_condition_7: "",
    lr_lingual_condition_8: "",
    patient_id_number: itemId,
});

const openModal = () => {
    isModalOpen.value = true;
};

const closeModal = () => {
    isModalOpen.value = false;
};

const toggleEditMode = async () => {
    isEditMode.value = !isEditMode.value;
};

const refresh = async () => {
    window.location.reload();
};

// const formatTimestamp = (timestamp) => {
//     const dateObj = new Date(timestamp);

//     return dateObj.toLocaleString("en-US", {
//         year: "numeric",
//         month: "numeric",
//         day: "numeric",
//         hour: "2-digit",
//         minute: "2-digit",
//         hour12: true,
//     });
// };

const handleSubmit = async () => {
    isLoading.value = true;
    try {
        if (history && Object.keys(history.value).length === 0) {
            await axios.post(
                `${useRuntimeConfig().public.laravelURL}user/dental-health-statuses`,
                formData.value,
                {
                    headers: {
                        Authorization: `Bearer ${authStore.token}`,
                    },
                },
            );
        } else {
            let formValue = formData.value;
            if (formValue.patient_id_number) {
                const { patient_id_number, ...rest } = formData.value;
                formValue = rest;
            }
            await axios.put(
                `${useRuntimeConfig().public.laravelURL}user/dental-health-statuses/${history.value.id}`,
                formValue,
                {
                    headers: {
                        Authorization: `Bearer ${authStore.token}`,
                    },
                },
            );
        }
        formData.value = { ...initialFormData.value };
        toast.success("Record added successfully");
    } catch (error) {
        toast.error("Failed");
        console.log("Failed to fetch records", error);
    } finally {
        await fetchRecord();
        isLoading.value = false;
        isModalOpen.value = false;
    }
};

const fetchRecord = async () => {
    isLoading.value = true;
    try {
        const { data } = await axios.get(
            `${useRuntimeConfig().public.laravelURL}user/dental-health-statuses`,
            {
                params: {
                    patient_id_number: itemId,
                },
                headers: {
                    Authorization: `Bearer ${authStore.token}`,
                },
            },
        );
        history.value = data;

        isEditMode.value = false;
        formData.value = { ...data, patient_id_number: itemId };
    } catch (error) {
        console.log(error);
    } finally {
        isLoading.value = false;
    }
};

// const deleteRecord = async (id) => {
//     isLoading.value = true;
//     try {
//         const result = await axios.delete(
//             `${useRuntimeConfig().public.laravelURL}user/consultation-records/${id}`,
//             {
//                 headers: {
//                     Authorization: `Bearer ${authStore.token}`,
//                 },
//             },
//         );
//         await fetchRecord();
//         toast.success("Record deleted successfully");
//     } catch (error) {
//         toast.error("Failed");
//         console.log("Error Deleting");
//     } finally {
//         isLoading.value = false;
//     }
// };
const fetchRole = () => {
    role.value = authStore.role;
};

fetchRole();

onMounted(async () => {
    await fetchRecord();
});
</script>

<style scoped>
::backdrop {
    backdrop-filter: blur(5px);
    background-color: rgba(0, 0, 0, 0.4);
}
</style>

<template>
    <div class="grid gap-5 py-6">
        <h1 class="text-xl font-bold sm:text-5xl">Dental Health Record</h1>
        <!-- SEARCH -->
        <div class="relative mx-auto mt-7 flex w-fit items-center gap-2">
            <h2 class="font-semibold">Search:</h2>
            <input
                type="text"
                v-model="searchTerm"
                class="search-input rounded-md border border-gray-300 pl-4 pr-10 focus:outline-none focus:ring-2"
                placeholder="Search ID Number or Name..."
            />
            <svg
                class="absolute right-3 top-1/2 h-5 w-5 -translate-y-1/2 transform text-gray-400"
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                stroke-width="2"
                stroke="currentColor"
                aria-hidden="true"
            >
                <path
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    d="M21 21l-4.35-4.35M17 10a7 7 0 10-14 0 7 7 0 0014 0z"
                />
            </svg>
        </div>

        <!-- TABLE -->
        <div class="overflow-x-auto">
            <table class="w-full table-auto text-left">
                <thead class="text-white">
                    <tr class="bg-[#1e3d2c]">
                        <th class="whitespace-nowrap p-5">ID Number</th>
                        <th class="whitespace-nowrap p-5">Classification</th>
                        <th
                            class="flex cursor-pointer items-center gap-2 whitespace-nowrap p-5"
                            @click="sort('fullname')"
                        >
                            Full Name
                            <Icon
                                :class="isSort ? '' : 'rotate-180'"
                                class="transition-transform duration-200"
                                name="ep:arrow-down"
                                style="color: white"
                            />
                        </th>
                        <th class="whitespace-nowrap p-5">Action</th>
                    </tr>
                </thead>
                <tbody class="whitespace-nowrap">
                    <template v-if="isLoading">
                        <tr>
                            <td colspan="4" class="text-center"><Spinner /></td>
                        </tr>
                    </template>
                    <template v-else>
                        <tr
                            v-for="(item, index) in filteredRecords"
                            :key="index"
                        >
                            <td class="p-5 font-medium">
                                {{ item.id_number }}
                            </td>
                            <td class="p-5 font-medium">
                                {{ item.classification ?? "-" }}
                            </td>
                            <td class="p-5 font-medium">
                                {{ item.first_name }} {{ item.last_name }}
                            </td>
                            <td class="flex gap-2 p-5 font-medium">
                                <NuxtLink
                                    :to="`/user/dental-health-record/${item.id_number}`"
                                    class="rounded bg-emerald-500 px-4 py-2 font-bold text-white hover:bg-emerald-700"
                                >
                                    View
                                </NuxtLink>
                            </td>
                        </tr>
                    </template>
                </tbody>
            </table>
        </div>
    </div>
</template>

<script setup>
import axios from "axios";
import { useAuthStore } from "~/stores/auth";

definePageMeta({
    layout: "user",
    middleware: ["dental-doctor"],
});

const isSort = ref(false);
const searchTerm = ref("");
const authStore = useAuthStore();
const patients = ref([]);
const isLoading = ref(true);

const filteredRecords = computed(() => {
    if (!searchTerm.value) {
        return patients.value;
    }
    return patients.value.filter((item) => {
        const fullname = `${item.first_name} ${item.last_name}`;
        return (
            item.id_number.toString().includes(searchTerm.value.toLowerCase()) ||
            fullname.toLowerCase().includes(searchTerm.value.toLowerCase())            
        );
    });
});

const fetchUser = async () => {
    isLoading.value = true;
    try {
        const response = await axios.get(
            `${useRuntimeConfig().public.laravelURL}user/patients`,
            {
                headers: {
                    Authorization: `Bearer ${authStore.token}`,
                },
            },
        );
        patients.value = response.data;
    } catch (error) {
        console.log("error fetching Users");
    } finally {
        isLoading.value = false;
    }
};

const sort = async (name) => {
    isSort.value = !isSort.value;

    if (isSort.value) {
        filteredRecords.value = patients.value.sort((a, b) => {
            return a.first_name.localeCompare(b.first_name);
        });
    } else {
        filteredRecords.value = patients.value.sort((a, b) => {
            return b.first_name.localeCompare(a.first_name);
        });
    }
};

onMounted(async () => {
    await fetchUser();
});
</script>

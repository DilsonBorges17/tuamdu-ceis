<template>
    <div>
        <div class="mx-auto mt-16 max-w-7xl">
            <div class="flex flex-wrap">
                <NuxtLink
                    class="rounded-md border border-black bg-[#a6a6a6] px-4 py-2 font-bold text-black hover:bg-[#d9d9d9]"
                    :to="`/user/medical-health-record/${itemId}`"
                    >Medical Health Record</NuxtLink
                >
                <NuxtLink
                    class="rounded-md border border-black bg-[#a6a6a6] px-4 py-2 font-bold text-black hover:bg-[#d9d9d9]"
                    :to="`/user/medical-health-record/${itemId}-health-history`"
                    >Health History</NuxtLink
                >
                <NuxtLink
                    class="rounded-md border border-black bg-[#a6a6a6] px-4 py-2 font-bold text-black hover:bg-[#d9d9d9]"
                    to="#"
                    >Physical Examination</NuxtLink
                >
                <NuxtLink
                    class="rounded-md border border-black bg-[#a6a6a6] px-4 py-2 font-bold text-black hover:bg-[#d9d9d9]"
                    :to="`/user/medical-health-record/${itemId}-consultation-record`"
                    >Consultation Record</NuxtLink
                >
            </div>
            <div v-if="isLoading">
                <Spinner />
            </div>
            <div v-if="!isLoading">
                <div
                    class="grid gap-4 rounded-md border border-black bg-white px-2 py-8 shadow-lg sm:px-10"
                >
                    <div class="flex flex-col items-center justify-center">
                        <img src="/tua-logo.png" alt="logo" />
                        <h1 class="text-2xl uppercase">
                            Trinity University of Asia
                        </h1>
                        <p>Medical and Dental Unit</p>
                    </div>
                    <h2 class="bg-black text-center font-bold text-white">
                        PHYSICAL EXAMINATION
                    </h2>
                    <div class="overflow-x-auto">
                        <table class="w-full border border-black">
                            <thead class="bg-[#e0dcdc]">
                                <tr class="text-center font-bold">
                                    <td class="sr-only border border-black">
                                        Labels
                                    </td>
                                    <td class="border border-black px-5 py-1">
                                        1st Year
                                    </td>
                                    <td class="border border-black px-5 py-1">
                                        2nd Year
                                    </td>
                                    <td class="border border-black px-5 py-1">
                                        3rd Year
                                    </td>
                                    <td class="border border-black px-5 py-1">
                                        4th Year
                                    </td>
                                </tr>
                            </thead>
                            <tbody>
                                <tr
                                    v-for="(header, headerIndex) in tableLabels"
                                    :key="'row-' + headerIndex"
                                >
                                    <th
                                        class="border border-black px-5 py-1 text-left odd:bg-white even:bg-[#D9D9D9]"
                                    >
                                        {{ header.label }}
                                    </th>
                                    <td
                                        v-for="year in [
                                            '1st',
                                            '2nd',
                                            '3rd',
                                            '4th',
                                        ]"
                                        :key="
                                            'cell-' + headerIndex + '-' + year
                                        "
                                        class="border border-black px-5 py-1 odd:bg-white even:bg-[#D9D9D9]"
                                    >
                                        <template
                                            v-if="
                                                header.key === 'action' &&
                                                records.find(
                                                    (record) =>
                                                        record.year === year,
                                                )
                                            "
                                        >
                                            <button
                                                class="rounded bg-red-500 px-2 py-1 text-white hover:bg-red-700"
                                                @click="
                                                    deleteRecord(
                                                        records.find(
                                                            (record) =>
                                                                record.year ===
                                                                year,
                                                        )?.id,
                                                    )
                                                "
                                            >
                                                Delete
                                            </button>
                                        </template>
                                        <template v-else>
                                            {{
                                                records.find(
                                                    (record) =>
                                                        record.year === year &&
                                                        record[
                                                            header.key.toLowerCase()
                                                        ],
                                                )?.[header.key.toLowerCase()]
                                                    .last_name ||
                                                records.find(
                                                    (record) =>
                                                        record.year === year &&
                                                        record[
                                                            header.key.toLowerCase()
                                                        ],
                                                )?.[header.key.toLowerCase()] ||
                                                "N/A"
                                            }}
                                        </template>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div v-if="role != 'Medical Doctor'" class="mt-8 flex flex-col items-center gap-2">
                    <button
                        class="w-full rounded-md bg-[#347956] px-14 py-1 font-medium text-white hover:bg-emerald-800 md:w-1/3"
                        type="button"
                        @click="openModal()"
                    >
                        ADD
                    </button>
                </div>
            </div>
        </div>
        <dialog
            ref="dialogRef"
            class="w-full max-w-2xl rounded-lg bg-white p-6 shadow-lg"
        >
            <h2 class="mb-4 text-xl font-bold text-gray-800">
                Medical Examination Form
            </h2>
            <div v-if="isLoading">
                <Spinner />
            </div>
            <div v-if="!isLoading">
                <form @submit.prevent="handleSubmit" class="grid">
                    <!-- Height / Weight -->
                    <div class="mb-4">
                        <label
                            for="height-weight"
                            class="block text-sm font-medium text-gray-700"
                            >Height / Weight</label
                        >
                        <input
                            type="text"
                            id="height-weight"
                            class="mt-1 w-full rounded-md border border-black p-2"
                            placeholder="Enter Height / Weight"
                            v-model="formData.height_weight"
                            required
                        />
                    </div>

                    <!-- Temperature / BP -->
                    <div class="mb-4">
                        <label
                            for="temperature-bp"
                            class="block text-sm font-medium text-gray-700"
                            >Temperature / BP</label
                        >
                        <input
                            type="text"
                            id="temperature-bp"
                            class="mt-1 w-full rounded-md border border-black p-2"
                            placeholder="Enter Temperature / BP"
                            v-model="formData.temperature_bp"
                            required
                        />
                    </div>

                    <!-- HR / PR / RR -->
                    <div class="mb-4">
                        <label
                            for="hr-pr-rr"
                            class="block text-sm font-medium text-gray-700"
                            >HR / PR / RR</label
                        >
                        <input
                            type="text"
                            id="hr-pr-rr"
                            class="mt-1 w-full rounded-md border border-black p-2"
                            placeholder="Enter HR / PR / RR"
                            v-model="formData.hr_pr_rr"
                            required
                        />
                    </div>

                    <!-- Nutritional Status -->
                    <div class="mb-4">
                        <label
                            for="nutritional-status"
                            class="block text-sm font-medium text-gray-700"
                            >Nutritional Status</label
                        >
                        <input
                            type="text"
                            id="nutritional-status"
                            class="mt-1 w-full rounded-md border border-black p-2"
                            placeholder="Enter Nutritional Status"
                            v-model="formData.nutritional_status"
                            required
                        />
                    </div>

                    <!-- Visual activity -->
                    <div class="mb-4">
                        <label
                            for="visual-activity"
                            class="block text-sm font-medium text-gray-700"
                            >Visual activity</label
                        >
                        <input
                            type="text"
                            id="visual-activity"
                            class="mt-1 w-full rounded-md border border-black p-2"
                            placeholder="Enter Visual Activity"
                            v-model="formData.visual_activity"
                            required
                        />
                    </div>

                    <!-- Hearing -->
                    <div class="mb-4">
                        <label
                            for="hearing"
                            class="block text-sm font-medium text-gray-700"
                            >Hearing</label
                        >
                        <input
                            type="text"
                            id="hearing"
                            class="mt-1 w-full rounded-md border border-black p-2"
                            placeholder="Enter Hearing Assessment"
                            v-model="formData.hearing"
                            required
                        />
                    </div>

                    <!-- Skin / Scalp -->
                    <div class="mb-4">
                        <label
                            for="skin-scalp"
                            class="block text-sm font-medium text-gray-700"
                            >Skin / Scalp</label
                        >
                        <input
                            type="text"
                            id="skin-scalp"
                            class="mt-1 w-full rounded-md border border-black p-2"
                            placeholder="Enter Skin / Scalp Details"
                            v-model="formData.skin_scalp"
                            required
                        />
                    </div>

                    <!-- Eyes / Ears / Nose -->
                    <div class="mb-4">
                        <label
                            for="eyes-ears-nose"
                            class="block text-sm font-medium text-gray-700"
                            >Eyes / Ears / Nose</label
                        >
                        <input
                            type="text"
                            id="eyes-ears-nose"
                            class="mt-1 w-full rounded-md border border-black p-2"
                            placeholder="Enter Eyes / Ears / Nose Details"
                            v-model="formData.eyes_ears_nose"
                            required
                        />
                    </div>

                    <!-- Mouth / Throat / Neck -->
                    <div class="mb-4">
                        <label
                            for="mouth-throat-neck"
                            class="block text-sm font-medium text-gray-700"
                            >Mouth / Throat / Neck</label
                        >
                        <input
                            type="text"
                            id="mouth-throat-neck"
                            class="mt-1 w-full rounded-md border border-black p-2"
                            placeholder="Enter Mouth / Throat / Neck Details"
                            v-model="formData.mouth_throat_neck"
                            required
                        />
                    </div>

                    <!-- Lungs / Heart -->
                    <div class="mb-4">
                        <label
                            for="lungs-heart"
                            class="block text-sm font-medium text-gray-700"
                            >Lungs / Heart</label
                        >
                        <input
                            type="text"
                            id="lungs-heart"
                            class="mt-1 w-full rounded-md border border-black p-2"
                            placeholder="Enter Lungs / Heart Details"
                            v-model="formData.lungs_heart"
                            required
                        />
                    </div>

                    <!-- GIT / GUT -->
                    <div class="mb-4">
                        <label
                            for="git-gut"
                            class="block text-sm font-medium text-gray-700"
                            >GIT / GUT</label
                        >
                        <input
                            type="text"
                            id="git-gut"
                            class="mt-1 w-full rounded-md border border-black p-2"
                            placeholder="Enter GIT / GUT Details"
                            v-model="formData.git_gut"
                            required
                        />
                    </div>

                    <!-- Spine / Extremities -->
                    <div class="mb-4">
                        <label
                            for="spine-extremities"
                            class="block text-sm font-medium text-gray-700"
                            >Spine / Extremities</label
                        >
                        <input
                            type="text"
                            id="spine-extremities"
                            class="mt-1 w-full rounded-md border border-black p-2"
                            placeholder="Enter Spine / Extremities Details"
                            v-model="formData.spine_extremities"
                            required
                        />
                    </div>

                    <!-- Other Specify -->
                    <div class="mb-4">
                        <label
                            for="other-specify"
                            class="block text-sm font-medium text-gray-700"
                            >Other Specify</label
                        >
                        <textarea
                            id="other-specify"
                            class="mt-1 w-full rounded-md border border-black p-2"
                            rows="2"
                            placeholder="Specify Other Observations"
                            v-model="formData.others"
                        ></textarea>
                    </div>

                    <!-- Recommendations -->
                    <div class="mb-4">
                        <label
                            for="recommendations"
                            class="block text-sm font-medium text-gray-700"
                            >Recommendations</label
                        >
                        <textarea
                            id="recommendations"
                            class="mt-1 w-full rounded-md border border-black p-2"
                            rows="2"
                            placeholder="Enter Recommendations"
                            v-model="formData.recommendations"
                        ></textarea>
                    </div>

                    <!-- Examined By -->
                    <!-- <div class="mb-4">
            <label for="examined-by" class="block text-sm font-medium text-gray-700">Examined By</label>
            <input
                type="text"
                id="examined-by"
                class="mt-1 w-full rounded-md border border-black p-2"
                placeholder="Enter Examiner's Name"
                required
            />
        </div> -->

                    <!-- Year -->
                    <div class="mb-4">
                        <label
                            for="year"
                            class="block text-sm font-medium text-gray-700"
                            >Year</label
                        >
                        <select
                            name="year"
                            id="year"
                            class="mt-1 w-full rounded-md border border-black p-2"
                            v-model="formData.year"
                            required
                        >
                            <option
                                v-for="year in availableYear"
                                :value="year"
                                :key="year.id"
                            >
                                {{ year }}
                            </option>
                        </select>
                    </div>

                    <!-- Buttons -->
                    <div
                        class="flex flex-wrap justify-center gap-4 sm:justify-end"
                    >
                        <button
                            @click="closeDialog"
                            type="button"
                            class="rounded bg-gray-200 px-4 py-2 text-gray-800 hover:bg-gray-300"
                        >
                            Cancel
                        </button>
                        <button
                            type="submit"
                            class="rounded bg-[#347956] px-4 py-2 text-white hover:bg-emerald-800"
                        >
                            Submit
                        </button>
                    </div>
                </form>
            </div>
        </dialog>
    </div>
</template>
<script setup>
import axios from "axios";
import { useAuthStore } from "~/stores/auth";
import { toast } from "vue3-toastify";
import "vue3-toastify/dist/index.css";

definePageMeta({
    layout: "user",
    middleware: ["medical-doctor"],
});

const authStore = useAuthStore();
const dialogRef = ref(null);
const role = ref("");
const current_id = authStore.current_id;
const isLoading = ref(true);
const records = ref([]);
const route = useRoute();
const itemId = route.params.id;

const tableLabels = [
    { key: "date", label: "Date" },
    { key: "height_weight", label: "Height / Weight" },
    { key: "temperature_bp", label: "Temperature / BP" },
    { key: "hr_pr_rr", label: "HR / PR / RR" },
    { key: "nutritional_status", label: "Nutritional Status" },
    { key: "visual_activity", label: "Visual Acuity" },
    { key: "hearing", label: "Hearing" },
    { key: "skin_scalp", label: "Skin / Scalp" },
    { key: "eyes_ears_nose", label: "Eyes / Ears / Nose" },
    { key: "mouth_throat_neck", label: "Mouth / Throat / Neck" },
    { key: "lungs_heart", label: "Lungs / Heart" },
    { key: "git_gut", label: "GIT / GUT" },
    { key: "spine_extremities", label: "Spine / Extremities" },
    { key: "others", label: "Other Specify" },
    { key: "recommendations", label: "Recommendations" },
    { key: "doctor", label: "Examined By" },
    { key: "action", label: "Action" },
];

const initialFormData = ref({
    patient_id_number: itemId,
    doctor_id: current_id,
    height_weight: "",
    temperature_bp: "",
    hr_pr_rr: "",
    nutritional_status: "",
    visual_activity: "",
    hearing: "",
    skin_scalp: "",
    eyes_ears_nose: "",
    mouth_throat_neck: "",
    lungs_heart: "",
    git_gut: "",
    spine_extremities: "",
    others: "",
    recommendations: "",
    year: "",
});

const formData = ref({
    patient_id_number: itemId,
    doctor_id: current_id,
    height_weight: "",
    temperature_bp: "",
    hr_pr_rr: "",
    nutritional_status: "",
    visual_activity: "",
    hearing: "",
    skin_scalp: "",
    eyes_ears_nose: "",
    mouth_throat_neck: "",
    lungs_heart: "",
    git_gut: "",
    spine_extremities: "",
    others: "",
    recommendations: "",
    year: "",
});

const closeDialog = () => {
    dialogRef.value?.close();
};

const openModal = () => {
    dialogRef.value.showModal();
};

const fetchRecord = async () => {
    isLoading.value = true;
    try {
        const { data } = await axios.get(
            `${useRuntimeConfig().public.laravelURL}user/physical-exam-records`,
            {
                params: {
                    patient_id_number: itemId,
                },
                headers: {
                    Authorization: `Bearer ${authStore.token}`,
                },
            },
        );
        records.value = data;
    } catch (error) {
        console.log("error fetching Record");
    } finally {
        isLoading.value = false;
    }
};

const availableYear = computed(() => {
    const years = ["1st", "2nd", "3rd", "4th"];
    return years.filter(
        (year) => !records.value.some((record) => record.year === year),
    );
});

const deleteRecord = async (id) => {
    try {
        const result = await axios.delete(
            `${useRuntimeConfig().public.laravelURL}user/physical-exam-records/${id}`,
            {
                headers: {
                    Authorization: `Bearer ${authStore.token}`,
                },
            },
        );
        await fetchRecord();
        toast.success("Record deleted successfully");
    } catch (error) {
        console.log("Error Deleting");
    }
};

const handleSubmit = async () => {
    isLoading.value = true;
    try {
        await axios.post(
            `${useRuntimeConfig().public.laravelURL}user/physical-exam-records`,
            formData.value,
            {
                headers: {
                    Authorization: `Bearer ${authStore.token}`,
                },
            },
        );
        closeDialog();
        await fetchRecord();
        toast.success("Successfully Added");
        formData.value = { ...initialFormData.value };
    } catch (error) {
        closeDialog();
        toast.error("Failed");
        console.log("Failed to fetch records", error);
    } finally {
        isLoading.value = false;
    }
};

const fetchRole = () => {
    role.value = authStore.role;
};

fetchRole();
onMounted(async () => {
    await fetchRecord();
});
</script>

<style scoped>
::backdrop {
    backdrop-filter: blur(5px);
    background-color: rgba(0, 0, 0, 0.4);
}
</style>

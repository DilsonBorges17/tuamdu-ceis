<template>
    <div class="mx-auto mt-16 max-w-7xl">
        <div class="flex">
            <NuxtLink
                class="rounded-md border border-black bg-[#a6a6a6] px-4 py-2 font-bold text-black hover:bg-[#d9d9d9]"
                to="#"
                >Medical Health Record</NuxtLink
            >
            <NuxtLink
                class="rounded-md border border-black bg-[#a6a6a6] px-4 py-2 font-bold text-black hover:bg-[#d9d9d9]"
                :to="`/user/medical-health-record/${itemId}-health-history`"
                >Health History</NuxtLink
            >
            <NuxtLink
                class="rounded-md border border-black bg-[#a6a6a6] px-4 py-2 font-bold text-black hover:bg-[#d9d9d9]"
                :to="`/user/medical-health-record/${itemId}-physical-examination`"
                >Physical Examination</NuxtLink
            >
            <NuxtLink
                class="rounded-md border border-black bg-[#a6a6a6] px-4 py-2 font-bold text-black hover:bg-[#d9d9d9]"
                :to="`/user/medical-health-record/${itemId}-consultation-record`"
                >Consultation Record</NuxtLink
            >
        </div>
        <div v-if="isLoading">
            <Spinner />
        </div>
        <div v-if="!isLoading">
            <form @submit.prevent="handleSubmit()" class="mt-5 grid">
                <div
                    class="grid gap-4 border border-black bg-white px-4 py-8 shadow-md"
                >
                    <div class="flex flex-col items-center justify-center">
                        <img src="/tua-logo.png" alt="logo" />
                        <h1 class="text-2xl uppercase">
                            Trinity University of Asia
                        </h1>
                        <p>Medical and Dental Unit</p>
                    </div>
                    <h2 class="bg-black text-center font-bold text-white">
                        MEDICAL HEATH RECORD
                    </h2>
                    <form class="border border-black bg-[#d9d9d9] p-3">
                        <div class="-mx-3 flex flex-wrap">
                            <div class="mb-2 w-full px-3 md:mb-0 md:w-3/5">
                                <label
                                    class="block font-normal after:text-red-500 after:content-['*']"
                                    for="id"
                                    >ID Number:</label
                                >
                                <input
                                    required
                                    :disabled="isReadOnly"
                                    class="w-full rounded-md border border-black"
                                    type="number"
                                    id="id"
                                    v-model="formData.id_number"
                                />
                            </div>

                            <div v-if="formData.department" class="mb-2 w-full px-3 md:mb-0 md:w-1/5">
                                <label
                                    class="block font-normal after:text-red-500 after:content-['*']"
                                    for="course"
                                    >{{formData.relation ? 'Department:' : 'Course:'}}</label
                                >
                                <select
                                    required
                                    :disabled="isReadOnly"
                                    class="w-full rounded-md border border-black"
                                    id="course"
                                    v-model="formData.department_id"
                                >
                                    <option
                                        v-for="department in departments"
                                        :value="department.id"
                                        :key="department.id"
                                    >
                                        {{ department.name }}
                                    </option>
                                </select>
                            </div>

                            <div
                                v-if="formData.classification"
                                class="mb-2 w-full px-3 md:mb-0 md:w-1/5"
                            >
                                <label
                                    class="block font-normal after:text-red-500 after:content-['*']"
                                    for="classification"
                                    >Classification:</label
                                >
                                <select
                                    required
                                    :disabled="isReadOnly"
                                    class="w-full rounded-md border border-black"
                                    id="classification"
                                    v-model="formData.classification"
                                >
                                    <option value="Dean">Dean</option>
                                    <option value="Professor">Professor</option>
                                    <option value="Faculty">Faculty</option>
                                    <option value="Employee">Employee</option>
                                </select>
                            </div>

                            <div v-if="formData.year_level" class="mb-2 w-full px-3 md:mb-0 md:w-1/5">
                                <label
                                    class="block font-normal after:text-red-500 after:content-['*']"
                                    for="year_level"
                                    >Year Level:</label
                                >
                                <select
                                    required
                                    :disabled="isReadOnly"
                                    class="w-full rounded-md border border-black"
                                    id="year_level"
                                    v-model="formData.year_level"
                                >
                                    <option value="1st">1st</option>
                                    <option value="2nd">2nd</option>
                                    <option value="3rd">3rd</option>
                                    <option value="4th">4th</option>
                                </select>
                            </div>

                            <!-- EDIT THIS -->
                        </div>
                        <div class="-mx-3 flex flex-wrap">
                            <div class="mb-2 w-full px-3 md:mb-0 md:w-2/6">
                                <label
                                    class="block font-normal after:text-red-500 after:content-['*']"
                                    for="lastname"
                                    >Lastname:</label
                                >
                                <input
                                    required
                                    :disabled="isReadOnly"
                                    class="w-full rounded-md border border-black"
                                    type="text"
                                    id="lastname"
                                    v-model="formData.last_name"
                                />
                            </div>
                            <div class="mb-2 w-full px-3 md:mb-0 md:w-2/6">
                                <label
                                    class="block font-normal after:text-red-500 after:content-['*']"
                                    for="firstname"
                                    >First Name:</label
                                >
                                <input
                                    required
                                    :disabled="isReadOnly"
                                    class="w-full rounded-md border border-black"
                                    type="text"
                                    id="firstname"
                                    v-model="formData.first_name"
                                />
                            </div>
                            <div class="mb-2 w-full px-3 md:mb-0 md:w-1/6">
                                <label
                                    class="block font-normal"
                                    for="middleName"
                                    >Middle Name:</label
                                >
                                <input
                                    :disabled="isReadOnly"
                                    class="w-full rounded-md border border-black"
                                    type="text"
                                    id="middleName"
                                    v-model="formData.middle_name"
                                />
                            </div>
                            <div class="mb-2 w-full px-3 md:mb-0 md:w-1/6">
                                <label
                                    class="block font-normal"
                                    for="name_extension"
                                    >Name Extension:</label
                                >
                                <select
                                    :disabled="isReadOnly"
                                    class="w-full rounded-md border border-black"
                                    id="name_extension"
                                    v-model="formData.name_extension"
                                >
                                    <option value="Jr.">Sr.</option>
                                    <option value="Sr.">Jr.</option>
                                    <option value="I">I</option>
                                    <option value="II">II</option>
                                    <option value="III">III</option>
                                    <option value="IV">IV</option>
                                    <option value="V">V</option>
                                </select>
                            </div>
                        </div>
                        <div class="-mx-3 flex flex-wrap">
                            <div class="mb-2 w-full px-3 md:mb-0 md:w-2/6">
                                <label
                                    class="block font-normal after:text-red-500 after:content-['*']"
                                    for="place_of_birth"
                                    >Place of Birth:</label
                                >
                                <input
                                    required
                                    :disabled="isReadOnly"
                                    class="w-full rounded-md border border-black"
                                    type="text"
                                    id="place_of_birth"
                                    v-model="formData.place_of_birth"
                                />
                            </div>
                            <div class="mb-2 w-full px-3 md:mb-0 md:w-2/6">
                                <label
                                    class="block font-normal after:text-red-500 after:content-['*']"
                                    for="datebirth"
                                    >Date of Birth:</label
                                >
                                <input
                                    required
                                    :disabled="isReadOnly"
                                    class="w-full rounded-md border border-black"
                                    type="date"
                                    id="datebirth"
                                    v-model="formData.date_of_birth"
                                />
                            </div>
                            <div class="mb-2 w-full px-3 md:mb-0 md:w-1/6">
                                <label
                                    class="block font-normal after:text-red-500 after:content-['*']"
                                    for="age"
                                    >Age:</label
                                >
                                <input
                                    required
                                    :disabled="true"
                                    class="w-full rounded-md border border-black"
                                    type="number"
                                    id="age"
                                    v-model="formData.age"
                                />
                            </div>
                            <div class="mb-2 w-full px-3 md:mb-0 md:w-1/6">
                                <label
                                    class="block font-normal after:text-red-500 after:content-['*']"
                                    for="gender"
                                    >Gender:</label
                                >
                                <select
                                    required
                                    :disabled="isReadOnly"
                                    class="w-full rounded-md border border-black"
                                    id="gender"
                                    v-model="formData.gender"
                                >
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                </select>
                            </div>
                        </div>
                        <div class="-mx-3 flex flex-wrap">
                            <div class="mb-2 w-full px-3 md:mb-0 md:w-2/6">
                                <label
                                    class="block font-normal after:text-red-500 after:content-['*']"
                                    for="nationality"
                                    >Nationality:</label
                                >
                                <input
                                    required
                                    :disabled="isReadOnly"
                                    class="w-full rounded-md border border-black"
                                    type="text"
                                    id="nationality"
                                    v-model="formData.nationality"
                                />
                            </div>
                        </div>

                        <div class="-mx-3 flex flex-wrap">
                            <div class="mb-2 w-full px-3 md:mb-0 md:w-3/5">
                                <label
                                    class="block font-normal after:text-red-500 after:content-['*']"
                                    for="address"
                                    >Address:</label
                                >
                                <input
                                    required
                                    :disabled="isReadOnly"
                                    class="w-full rounded-md border border-black"
                                    type="text"
                                    id="address"
                                    v-model="formData.address"
                                />
                            </div>
                            <div class="mb-2 w-full px-3 md:mb-0 md:w-1/5">
                                <label
                                    class="block font-normal after:text-red-500 after:content-['*']"
                                    for="zip_code"
                                    >Zip Code:</label
                                >
                                <input
                                    required
                                    :disabled="isReadOnly"
                                    class="w-full rounded-md border border-black"
                                    type="number"
                                    id="zip_code"
                                    v-model="formData.zip_code"
                                />
                            </div>
                            <div class="mb-2 w-full px-3 md:mb-0 md:w-1/5">
                                <label
                                    class="block font-normal after:text-red-500 after:content-['*']"
                                    for="contact"
                                    >Contact Number:</label
                                >
                                <input
                                    required
                                    :disabled="isReadOnly"
                                    class="w-full rounded-md border border-black"
                                    type="number"
                                    id="contact"
                                    v-model="formData.contact_number"
                                />
                            </div>
                        </div>
                        <div class="-mx-3 flex flex-wrap">
                            <div class="mb-2 w-full px-3 md:mb-0 md:w-2/5">
                                <label
                                    class="block font-normal after:text-red-500 after:content-['*']"
                                    for="contactPerson"
                                    >{{formData.relation ? 'Contact Person:' : 'Name of Parent/Guardian:'}}</label
                                >
                                <input
                                    required
                                    :disabled="isReadOnly"
                                    class="w-full rounded-md border border-black"
                                    type="text"
                                    id="contactPerson"
                                    v-model="formData.contact_person"
                                />
                            </div>
                            <div class="mb-2 w-full px-3 md:mb-0 md:w-2/5">
                                <label
                                    class="block font-normal after:text-red-500 after:content-['*']"
                                    for="contactPersonNumber"
                                    >{{formData.relation ? 'Contact Number:' : 'Parent / Guardian Contact Number:'}}</label
                                >
                                <input
                                    required
                                    :disabled="isReadOnly"
                                    class="w-full rounded-md border border-black"
                                    type="number"
                                    id="contactPersonNumber"
                                    placeholder="Ex. 639232123111"
                                    v-model="formData.contact_person_number"
                                />
                            </div>
                            <div v-if="formData.relation" class="mb-2 w-full px-3 md:mb-0 md:w-1/5">
                                <label
                                    class="block font-normal after:text-red-500 after:content-['*']"
                                    for="relation"
                                    >Relation:</label
                                >
                                <input
                                    :disabled="isReadOnly"
                                    class="w-full rounded-md border border-black"
                                    type="text"
                                    id="relation"
                                    placeholder="Ex. Father"
                                    v-model="formData.relation"
                                />
                            </div>
                        </div>
                    </form>
                </div>
                <!-- <div class="mt-8 flex flex-col items-center gap-2">
                    <button
                        :class="{
                            'bg-[#347956] hover:bg-emerald-800': isReadOnly,
                            'bg-red-500 hover:bg-red-700': !isReadOnly,
                        }"
                        class="w-full rounded-md px-14 py-1 font-medium text-white md:w-1/3"
                        type="button"
                        @click="toggleEditMode"
                    >
                        {{ isReadOnly ? "EDIT" : "CANCEL" }}
                    </button>
                    <button
                        v-if="!isReadOnly"
                        @click="handleSubmit()"
                        class="w-full rounded-md bg-[#347956] px-14 py-1 font-medium text-white hover:bg-emerald-800 md:w-1/3"
                        type="submit"
                    >
                        SAVE INFORMATION
                    </button>
                </div> -->
            </form>
        </div>
    </div>
</template>
<script setup>
import axios from "axios";
import { useAuthStore } from "~/stores/auth";

definePageMeta({
    layout: "user",
    middleware: ["medical-doctor"],
});

const authStore = useAuthStore();
const route = useRoute();
const itemId = route.params.id;
const isReadOnly = ref(true);
const patientProfile = ref({});
const departments = ref([]);
const isLoading = ref(true);

const formData = ref({
    id: "",
    id_number: "",
    course: "",
    year_level: "",
    last_name: "",
    first_name: "",
    middle_name: "",
    name_extension: "",
    place_of_birth: "",
    date_of_birth: "",
    age: "",
    gender: "",
    nationality: "",
    address: "",
    zip_code: "",
    contact_number: "",
    contact_person: "",
    contact_person_number: "",
    email: "",
    confirm_email: "",
    password: "",
    confirm_password: "",
});

watch(
    () => ({
        department_id: formData.value.department_id,
        middle_initial: formData.value.middle_initial,
        date_of_birth: formData.value.date_of_birth,
    }),
    (newValues) => {
        formData.value.department_id = Number(newValues.department_id);
        // formData.value.middle_initial = newValues.middle_initial.toUpperCase();
        formData.value.age = calculateAge(newValues.date_of_birth);
    },
);

const calculateAge = (dateOfBirth) => {
    if (!dateOfBirth) return "";
    const today = new Date();
    const birthDate = new Date(dateOfBirth);
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDifference = today.getMonth() - birthDate.getMonth();
    if (
        monthDifference < 0 ||
        (monthDifference === 0 && today.getDate() < birthDate.getDate())
    ) {
        age--;
    }
    return age;
};

const toggleEditMode = () => {
    isReadOnly.value = !isReadOnly.value;
    if (isReadOnly.value) {
        location.reload();
    }
};

const handleSubmit = async () => {
    try {
        const { data } = await axios.put(
            `${useRuntimeConfig().public.laravelURL}user/patients/${itemId}`,
            formData.value,
            {
                headers: {
                    Authorization: `Bearer ${authStore.token}`,
                },
            },
        );
        await fetchPatient();
    } catch (error) {
        console.log("error Updating patient");
    }
};

const fetchPatient = async () => {
    isLoading.value = true;
    try {
        const { data } = await axios.get(
            `${useRuntimeConfig().public.laravelURL}user/patients/${itemId}`,
            {
                headers: {
                    Authorization: `Bearer ${authStore.token}`,
                },
            },
        );
        patientProfile.value = data;
        formData.value = {
            ...data,
        };
    } catch (error) {
        console.log("error fetching patient");
    } finally {
        isLoading.value = false;
    }
};

const UpdatePatient = async () => {
    try {
        const { data } = await axios.get(
            `${useRuntimeConfig().public.laravelURL}user/patients/${itemId}`,
            formData.value,
            {
                headers: {
                    Authorization: `Bearer ${authStore.token}`,
                },
            },
        );
        await fetchPatient();
    } catch (error) {
        console.log("error Updating patient");
    }
};

const fetchDepartments = async () => {
    try {
        const response = await axios.get(
            `${useRuntimeConfig().public.laravelURL}patient/departments`,
        );
        departments.value = response.data;
    } catch (error) {
        console.log(error);
    }
};

fetchDepartments();
onMounted(async () => {
    await fetchDepartments();
    await fetchPatient();
});
</script>

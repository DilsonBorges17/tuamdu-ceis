<template>
    <div>test</div>
</template>

<script>
definePageMeta({
    layout: "user",
    middleware: ["medical-doctor"],
});
</script>

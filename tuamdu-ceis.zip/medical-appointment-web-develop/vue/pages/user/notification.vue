<template>
    <div>
        <div class="mx-auto max-w-7xl">
            <h1 class="py-5 text-4xl font-bold">Notification</h1>
            <div class="flex gap-2 divide-x-2 divide-black">
                <div class="basis-1/3 p-1">
                    <template v-if="notifications.length > 0">
                        <button
                            v-for="notification of notifications"
                            :key="notification.id"
                            @click="setCurrentNotification(notification)"
                            class="mt-1 flex w-full items-center gap-2 rounded bg-[#D9D9D9] hover:bg-slate-300"
                        >
                            <div
                                class="flex items-center justify-center rounded-full bg-[#d9d9d9] p-1 font-bold text-black"
                            >
                                <img
                                    src="/email.png"
                                    alt="tuaLogo"
                                    class="h-auto max-w-6"
                                />
                            </div>
                            <p class="font-semibold">
                                From:
                                {{ notification.data.patient.first_name }}
                                {{ notification.data.patient.last_name }}
                            </p>
                        </button>
                    </template>
                    <template v-else>
                        <p class="mt-4 text-center italic text-gray-500">
                            No notifications.
                        </p>
                    </template>
                </div>
                <div class="basis-2/3 px-8 py-5">
                    <p
                        v-if="Object.keys(current_notifications).length === 0"
                        class="text-center italic"
                    >
                        Select from the notification list on the side to view
                        more details
                    </p>
                    <div v-if="Object.keys(current_notifications).length > 0">
                        <p>
                            Patient
                            {{
                                current_notifications.data.data.patient
                                    .first_name
                            }}
                            {{
                                current_notifications.data.data.patient
                                    .last_name
                            }}
                            has cancelled their
                            {{
                                current_notifications.data.data.appointment
                                    .schedule.service_type.name
                            }}
                            appointment with queuing no.
                            {{
                                current_notifications.data.data.appointment
                                    .queuing_number
                            }}
                            due to
                            {{ current_notifications.data.data.reason }}.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup>
import { useAuthStore } from "~/stores/auth";
import axios from "axios";
import { reactive } from "vue";

definePageMeta({
    layout: "user",
});

const authStore = useAuthStore();
const notifications = ref([]);
const role = ref("");
const current_notifications = reactive({});

const setCurrentNotification = (notification) => {
    current_notifications.data = notification;
};

const markAsRead = async (id) => {
    await axios.patch(
        `${useRuntimeConfig().public.laravelURL}patient/appointment-notifications/${id}`,
        {},
        {
            headers: {
                Authorization: `Bearer ${authStore.token}`,
            },
        },
    );
    window.location.reload();
};

const fetchNotifications = async () => {
    const endpoint =
        role.value === "Super Admin" || role.value === "Head Nurse"
            ? "user/notifications/all"
            : "user/notifications";

    const { data } = await axios.get(
        `${useRuntimeConfig().public.laravelURL}${endpoint}`,
        {
            headers: {
                Authorization: `Bearer ${authStore.token}`,
            },
        },
    );

    notifications.value = data;
};

const fetchRole = () => {
    role.value = authStore.role;
};

fetchRole();
onMounted(async () => {
    try{
        await fetchNotifications();
    }
    catch (error) {
        console.log("Error in notification page: ", error);
    }
});
</script>

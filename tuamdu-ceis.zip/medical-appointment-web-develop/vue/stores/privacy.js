export const usePrivacyStore = defineStore("counter", {
    state: () => ({ isPrivacyAgreed: false }),

    actions: {
        togglePrivacy() {
            this.isPrivacyAgreed = true;
        },
    },
});

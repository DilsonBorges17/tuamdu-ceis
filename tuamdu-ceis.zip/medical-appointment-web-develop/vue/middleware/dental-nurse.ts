export default defineNuxtRouteMiddleware((to, from) => {
    const authStore = useAuthStore();
    const role = authStore.role;

    if (role !== "Dental Nurse" || role !== "Super Admin" || role !== "Head Nurse") {
        if (role === "Medical Doctor") {
            return navigateTo("/user/medical-health-record");
        }
        if (role === "Medical Nurse") {
            return navigateTo("/user/medical-appointment");
        }
        if (role === "Dental Doctor") {
            return navigateTo("/user/dental-appointment");
        }
    }
});

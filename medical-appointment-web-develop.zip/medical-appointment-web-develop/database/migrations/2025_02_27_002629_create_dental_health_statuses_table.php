<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
	/**
	 * Run the migrations.
	 */
	public function up(): void
	{
		Schema::create('dental_health_statuses', function (Blueprint $table) {
			$table->id();
			$table->foreignId('patient_id')->unique()->constrained();

			// Upper Right Teeth
			$table->string('ur_labial_operation_1')->nullable();
			$table->string('ur_labial_operation_2')->nullable();
			$table->string('ur_labial_operation_3')->nullable();
			$table->string('ur_labial_operation_4')->nullable();
			$table->string('ur_labial_operation_5')->nullable();
			$table->string('ur_labial_operation_6')->nullable();
			$table->string('ur_labial_operation_7')->nullable();
			$table->string('ur_labial_operation_8')->nullable();

			$table->string('ur_labial_condition_1')->nullable();
			$table->string('ur_labial_condition_2')->nullable();
			$table->string('ur_labial_condition_3')->nullable();
			$table->string('ur_labial_condition_4')->nullable();
			$table->string('ur_labial_condition_5')->nullable();
			$table->string('ur_labial_condition_6')->nullable();
			$table->string('ur_labial_condition_7')->nullable();
			$table->string('ur_labial_condition_8')->nullable();

			$table->string('ul_labial_operation_1')->nullable();
			$table->string('ul_labial_operation_2')->nullable();
			$table->string('ul_labial_operation_3')->nullable();
			$table->string('ul_labial_operation_4')->nullable();
			$table->string('ul_labial_operation_5')->nullable();
			$table->string('ul_labial_operation_6')->nullable();
			$table->string('ul_labial_operation_7')->nullable();
			$table->string('ul_labial_operation_8')->nullable();

			$table->string('ul_labial_condition_1')->nullable();
			$table->string('ul_labial_condition_2')->nullable();
			$table->string('ul_labial_condition_3')->nullable();
			$table->string('ul_labial_condition_4')->nullable();
			$table->string('ul_labial_condition_5')->nullable();
			$table->string('ul_labial_condition_6')->nullable();
			$table->string('ul_labial_condition_7')->nullable();
			$table->string('ul_labial_condition_8')->nullable();

			$table->string('ll_lingual_operation_1')->nullable();
			$table->string('ll_lingual_operation_2')->nullable();
			$table->string('ll_lingual_operation_3')->nullable();
			$table->string('ll_lingual_operation_4')->nullable();
			$table->string('ll_lingual_operation_5')->nullable();
			$table->string('ll_lingual_operation_6')->nullable();
			$table->string('ll_lingual_operation_7')->nullable();
			$table->string('ll_lingual_operation_8')->nullable();

			$table->string('ll_lingual_condition_1')->nullable();
			$table->string('ll_lingual_condition_2')->nullable();
			$table->string('ll_lingual_condition_3')->nullable();
			$table->string('ll_lingual_condition_4')->nullable();
			$table->string('ll_lingual_condition_5')->nullable();
			$table->string('ll_lingual_condition_6')->nullable();
			$table->string('ll_lingual_condition_7')->nullable();
			$table->string('ll_lingual_condition_8')->nullable();

			$table->string('lr_lingual_operation_1')->nullable();
			$table->string('lr_lingual_operation_2')->nullable();
			$table->string('lr_lingual_operation_3')->nullable();
			$table->string('lr_lingual_operation_4')->nullable();
			$table->string('lr_lingual_operation_5')->nullable();
			$table->string('lr_lingual_operation_6')->nullable();
			$table->string('lr_lingual_operation_7')->nullable();
			$table->string('lr_lingual_operation_8')->nullable();

			$table->string('lr_lingual_condition_1')->nullable();
			$table->string('lr_lingual_condition_2')->nullable();
			$table->string('lr_lingual_condition_3')->nullable();
			$table->string('lr_lingual_condition_4')->nullable();
			$table->string('lr_lingual_condition_5')->nullable();
			$table->string('lr_lingual_condition_6')->nullable();
			$table->string('lr_lingual_condition_7')->nullable();
			$table->string('lr_lingual_condition_8')->nullable();


			$table->timestamps();
		});
	}

	/**
	 * Reverse the migrations.
	 */
	public function down(): void
	{
		Schema::dropIfExists('dental_health_statuses');
	}
};

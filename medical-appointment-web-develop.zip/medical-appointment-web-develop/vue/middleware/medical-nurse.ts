export default defineNuxtRouteMiddleware((to, from) => {
    const authStore = useAuthStore();
    const role = authStore.role;

    if (role !== "Medical Nurse" || role !== "Super Admin" || role !== "Head Nurse") {
        if (role === "Dental Nurse") {
            return navigateTo("/user/dental-appointment");
        }
    }
});

<template>
    <div class="mx-auto mt-16 max-w-7xl">
        <div class="flex flex-wrap">
            <NuxtLink
                class="rounded-md border border-black bg-[#a6a6a6] px-4 py-2 font-bold text-black hover:bg-[#d9d9d9]"
                :to="`/user/dental-health-record/${itemId}`"
                >Dental Health Record</NuxtLink
            >
            <NuxtLink
                class="rounded-md border border-black bg-[#a6a6a6] px-4 py-2 font-bold text-black hover:bg-[#d9d9d9]"
                :to="`/user/dental-health-record/${itemId}-health-history`"
                >Health History</NuxtLink
            >
            <NuxtLink
                class="rounded-md border border-black bg-[#a6a6a6] px-4 py-2 font-bold text-black hover:bg-[#d9d9d9]"
                to="#"
                >Oral Health Condition</NuxtLink
            >
            <NuxtLink
                class="rounded-md border border-black bg-[#a6a6a6] px-4 py-2 font-bold text-black hover:bg-[#d9d9d9]"
                :to="`/user/dental-health-record/${itemId}-consultation-record`"
                >Consultation Record</NuxtLink
            >
        </div>
        <div v-if="isLoading">
            <Spinner />
        </div>
        <div v-if="!isLoading">
            <div>
                <div
                    class="grid gap-4 rounded-md border border-black bg-white px-2 py-8 shadow-lg sm:px-10"
                >
                    <div class="flex flex-col items-center justify-center">
                        <img src="/tua-logo.png" alt="logo" />
                        <h1 class="text-2xl uppercase">
                            Trinity University of Asia
                        </h1>
                        <p>Medical and Dental Unit</p>
                    </div>
                    <h2 class="bg-black text-center font-bold text-white">
                        Oral Health Condition
                    </h2>
                    <div class="overflow-x-auto">
                        <table class="w-full border border-black text-sm">
                            <!-- Table Head -->
                            <thead>
                                <tr class="border border-black">
                                    <th
                                        class="border border-black px-4 py-2"
                                    ></th>
                                    <th
                                        colspan="2"
                                        class="border border-black px-4 py-2"
                                    >
                                        1st Year
                                    </th>
                                    <th
                                        colspan="2"
                                        class="border border-black px-4 py-2"
                                    >
                                        2nd Year
                                    </th>
                                    <th
                                        colspan="2"
                                        class="border border-black px-4 py-2"
                                    >
                                        3rd Year
                                    </th>
                                    <th
                                        colspan="2"
                                        class="border border-black px-4 py-2"
                                    >
                                        4th Year
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Date Row -->
                                <tr class="border border-black">
                                    <td class="border border-black px-4 py-2">
                                        Date
                                    </td>
                                    <td
                                        colspan="2"
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="firstYearData?.date"
                                            :disabled="!isEditMode"
                                            type="date"
                                            class="rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        colspan="2"
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="secondYearData?.date"
                                            :disabled="!isEditMode"
                                            type="date"
                                            class="rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        colspan="2"
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="thirdYearData?.date"
                                            :disabled="!isEditMode"
                                            type="date"
                                            class="rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        colspan="2"
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="fourthYearData?.date"
                                            :disabled="!isEditMode"
                                            type="date"
                                            class="rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                </tr>
                                <!-- Presence of Debris / Tooth Stain -->
                                <tr class="border border-black">
                                    <td class="border border-black px-4 py-2">
                                        Presence of Debris / Tooth Stain
                                    </td>
                                    <td
                                        colspan="2"
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            v-model="
                                                firstYearData.debris_tooth_stain
                                            "
                                            :disabled="!isEditMode"
                                            type="radio"
                                            name="debris_1st_year"
                                            :value="true"
                                            class="ml-2 mr-1"
                                        />Y
                                        <input
                                            v-model="
                                                firstYearData.debris_tooth_stain
                                            "
                                            :disabled="!isEditMode"
                                            type="radio"
                                            name="debris_1st_year"
                                            :value="false"
                                            class="ml-2 mr-1"
                                        />N
                                    </td>
                                    <td
                                        colspan="2"
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            v-model="
                                                secondYearData.debris_tooth_stain
                                            "
                                            :disabled="!isEditMode"
                                            type="radio"
                                            name="debris_2nd_year"
                                            :value="true"
                                            class="ml-2 mr-1"
                                        />Y
                                        <input
                                            v-model="
                                                secondYearData.debris_tooth_stain
                                            "
                                            :disabled="!isEditMode"
                                            type="radio"
                                            name="debris_2nd_year"
                                            :value="false"
                                            class="ml-2 mr-1"
                                        />N
                                    </td>
                                    <td
                                        colspan="2"
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            v-model="
                                                thirdYearData.debris_tooth_stain
                                            "
                                            :disabled="!isEditMode"
                                            type="radio"
                                            name="debris_3rd_year"
                                            :value="true"
                                            class="ml-2 mr-1"
                                        />Y
                                        <input
                                            v-model="
                                                thirdYearData.debris_tooth_stain
                                            "
                                            :disabled="!isEditMode"
                                            type="radio"
                                            name="debris_3rd_year"
                                            :value="false"
                                            class="ml-2 mr-1"
                                        />N
                                    </td>
                                    <td
                                        colspan="2"
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            v-model="
                                                fourthYearData.debris_tooth_stain
                                            "
                                            :disabled="!isEditMode"
                                            type="radio"
                                            name="debris_4th_year"
                                            :value="true"
                                            class="ml-2 mr-1"
                                        />Y
                                        <input
                                            v-model="
                                                fourthYearData.debris_tooth_stain
                                            "
                                            :disabled="!isEditMode"
                                            type="radio"
                                            name="debris_4th_year"
                                            :value="false"
                                            class="ml-2 mr-1"
                                        />N
                                    </td>
                                </tr>
                                <tr class="border border-black">
                                    <td class="border border-black px-4 py-2">
                                        Presence of Calculus Deposit
                                    </td>
                                    <td
                                        colspan="2"
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            v-model="
                                                firstYearData.calculus_deposit
                                            "
                                            :disabled="!isEditMode"
                                            type="radio"
                                            name="deposit_1st_year"
                                            :value="true"
                                            class="ml-2 mr-1"
                                        />Y
                                        <input
                                            v-model="
                                                firstYearData.calculus_deposit
                                            "
                                            :disabled="!isEditMode"
                                            type="radio"
                                            name="deposit_1st_year"
                                            :value="false"
                                            class="ml-2 mr-1"
                                        />N
                                    </td>
                                    <td
                                        colspan="2"
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            v-model="
                                                secondYearData.calculus_deposit
                                            "
                                            :disabled="!isEditMode"
                                            type="radio"
                                            name="deposit_2nd_year"
                                            :value="true"
                                            class="ml-2 mr-1"
                                        />Y
                                        <input
                                            v-model="
                                                secondYearData.calculus_deposit
                                            "
                                            :disabled="!isEditMode"
                                            type="radio"
                                            name="deposit_2nd_year"
                                            :value="false"
                                            class="ml-2 mr-1"
                                        />N
                                    </td>
                                    <td
                                        colspan="2"
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            v-model="
                                                thirdYearData.calculus_deposit
                                            "
                                            :disabled="!isEditMode"
                                            type="radio"
                                            name="deposit_3rd_year"
                                            :value="true"
                                            class="ml-2 mr-1"
                                        />Y
                                        <input
                                            v-model="
                                                thirdYearData.calculus_deposit
                                            "
                                            :disabled="!isEditMode"
                                            type="radio"
                                            name="deposit_3rd_year"
                                            :value="false"
                                            class="ml-2 mr-1"
                                        />N
                                    </td>
                                    <td
                                        colspan="2"
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            v-model="
                                                fourthYearData.calculus_deposit
                                            "
                                            :disabled="!isEditMode"
                                            type="radio"
                                            name="deposit_4th_year"
                                            :value="true"
                                            class="ml-2 mr-1"
                                        />Y
                                        <input
                                            v-model="
                                                fourthYearData.calculus_deposit
                                            "
                                            :disabled="!isEditMode"
                                            type="radio"
                                            name="deposit_4th_year"
                                            :value="false"
                                            class="ml-2 mr-1"
                                        />N
                                    </td>
                                </tr>
                                <tr class="border border-black">
                                    <td class="border border-black px-4 py-2">
                                        Presence of Gingivitis
                                    </td>
                                    <td
                                        colspan="2"
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            v-model="firstYearData.gingivitis"
                                            :disabled="!isEditMode"
                                            type="radio"
                                            name="gingivitis_1st_year"
                                            :value="true"
                                            class="ml-2 mr-1"
                                        />Y
                                        <input
                                            v-model="firstYearData.gingivitis"
                                            :disabled="!isEditMode"
                                            type="radio"
                                            name="gingivitis_1st_year"
                                            :value="false"
                                            class="ml-2 mr-1"
                                        />N
                                    </td>
                                    <td
                                        colspan="2"
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            v-model="secondYearData.gingivitis"
                                            :disabled="!isEditMode"
                                            type="radio"
                                            name="gingivitis_2nd_year"
                                            :value="true"
                                            class="ml-2 mr-1"
                                        />Y
                                        <input
                                            v-model="secondYearData.gingivitis"
                                            :disabled="!isEditMode"
                                            type="radio"
                                            name="gingivitis_2nd_year"
                                            :value="false"
                                            class="ml-2 mr-1"
                                        />N
                                    </td>
                                    <td
                                        colspan="2"
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            v-model="thirdYearData.gingivitis"
                                            :disabled="!isEditMode"
                                            type="radio"
                                            name="gingivitis_3rd_year"
                                            :value="true"
                                            class="ml-2 mr-1"
                                        />Y
                                        <input
                                            v-model="thirdYearData.gingivitis"
                                            :disabled="!isEditMode"
                                            type="radio"
                                            name="gingivitis_3rd_year"
                                            :value="false"
                                            class="ml-2 mr-1"
                                        />N
                                    </td>
                                    <td
                                        colspan="2"
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            v-model="fourthYearData.gingivitis"
                                            :disabled="!isEditMode"
                                            type="radio"
                                            name="gingivitis_4th_year"
                                            :value="true"
                                            class="ml-2 mr-1"
                                        />Y
                                        <input
                                            v-model="fourthYearData.gingivitis"
                                            :disabled="!isEditMode"
                                            type="radio"
                                            name="gingivitis_4th_year"
                                            :value="false"
                                            class="ml-2 mr-1"
                                        />N
                                    </td>
                                </tr>
                                <tr class="border border-black">
                                    <td class="border border-black px-4 py-2">
                                        Presence of Presence of Periodontal
                                        Pocket
                                    </td>
                                    <td
                                        colspan="2"
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            v-model="
                                                firstYearData.periodontal_pocket
                                            "
                                            :disabled="!isEditMode"
                                            type="radio"
                                            name="pocket_1st_year"
                                            :value="true"
                                            class="ml-2 mr-1"
                                        />Y
                                        <input
                                            v-model="
                                                firstYearData.periodontal_pocket
                                            "
                                            :disabled="!isEditMode"
                                            type="radio"
                                            name="pocket_1st_year"
                                            :value="false"
                                            class="ml-2 mr-1"
                                        />N
                                    </td>
                                    <td
                                        colspan="2"
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            v-model="
                                                secondYearData.periodontal_pocket
                                            "
                                            :disabled="!isEditMode"
                                            type="radio"
                                            name="pocket_2nd_year"
                                            :value="true"
                                            class="ml-2 mr-1"
                                        />Y
                                        <input
                                            v-model="
                                                secondYearData.periodontal_pocket
                                            "
                                            :disabled="!isEditMode"
                                            type="radio"
                                            name="pocket_2nd_year"
                                            :value="false"
                                            class="ml-2 mr-1"
                                        />N
                                    </td>
                                    <td
                                        colspan="2"
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            v-model="
                                                thirdYearData.periodontal_pocket
                                            "
                                            :disabled="!isEditMode"
                                            type="radio"
                                            name="pocket_3rd_year"
                                            :value="true"
                                            class="ml-2 mr-1"
                                        />Y
                                        <input
                                            v-model="
                                                thirdYearData.periodontal_pocket
                                            "
                                            :disabled="!isEditMode"
                                            type="radio"
                                            name="pocket_3rd_year"
                                            :value="false"
                                            class="ml-2 mr-1"
                                        />N
                                    </td>
                                    <td
                                        colspan="2"
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            v-model="
                                                fourthYearData.periodontal_pocket
                                            "
                                            :disabled="!isEditMode"
                                            type="radio"
                                            name="pocket_4th_year"
                                            :value="true"
                                            class="ml-2 mr-1"
                                        />Y
                                        <input
                                            v-model="
                                                fourthYearData.periodontal_pocket
                                            "
                                            :disabled="!isEditMode"
                                            type="radio"
                                            name="pocket_4th_year"
                                            :value="false"
                                            class="ml-2 mr-1"
                                        />N
                                    </td>
                                </tr>
                                <tr class="border border-black">
                                    <td class="border border-black px-4 py-2">
                                        Under Orthodontic Treatment
                                    </td>
                                    <td
                                        colspan="2"
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            v-model="
                                                firstYearData.orthodontic_treatment
                                            "
                                            :disabled="!isEditMode"
                                            type="radio"
                                            name="treatment_1st_year"
                                            :value="true"
                                            class="ml-2 mr-1"
                                        />Y
                                        <input
                                            v-model="
                                                firstYearData.orthodontic_treatment
                                            "
                                            :disabled="!isEditMode"
                                            type="radio"
                                            name="treatment_1st_year"
                                            :value="false"
                                            class="ml-2 mr-1"
                                        />N
                                    </td>
                                    <td
                                        colspan="2"
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            v-model="
                                                secondYearData.orthodontic_treatment
                                            "
                                            :disabled="!isEditMode"
                                            type="radio"
                                            name="treatment_2nd_year"
                                            :value="true"
                                            class="ml-2 mr-1"
                                        />Y
                                        <input
                                            v-model="
                                                secondYearData.orthodontic_treatment
                                            "
                                            :disabled="!isEditMode"
                                            type="radio"
                                            name="treatment_2nd_year"
                                            :value="false"
                                            class="ml-2 mr-1"
                                        />N
                                    </td>
                                    <td
                                        colspan="2"
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            v-model="
                                                thirdYearData.orthodontic_treatment
                                            "
                                            :disabled="!isEditMode"
                                            type="radio"
                                            name="treatment_3rd_year"
                                            :value="true"
                                            class="ml-2 mr-1"
                                        />Y
                                        <input
                                            v-model="
                                                thirdYearData.orthodontic_treatment
                                            "
                                            :disabled="!isEditMode"
                                            type="radio"
                                            name="treatment_3rd_year"
                                            :value="false"
                                            class="ml-2 mr-1"
                                        />N
                                    </td>
                                    <td
                                        colspan="2"
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            v-model="
                                                fourthYearData.orthodontic_treatment
                                            "
                                            :disabled="!isEditMode"
                                            type="radio"
                                            name="treatment_4th_year"
                                            :value="true"
                                            class="ml-2 mr-1"
                                        />Y
                                        <input
                                            v-model="
                                                fourthYearData.orthodontic_treatment
                                            "
                                            :disabled="!isEditMode"
                                            type="radio"
                                            name="treatment_4th_year"
                                            :value="false"
                                            class="ml-2 mr-1"
                                        />N
                                    </td>
                                </tr>

                                <!-- Dentofacial Abnormalities -->
                                <tr class="border border-black">
                                    <td class="border border-black px-4 py-2">
                                        Dentofacial Abnormalities and other Oral
                                        Pathologic Diseases, Specify:
                                    </td>
                                    <td
                                        colspan="2"
                                        class="border border-black px-4 py-2"
                                    >
                                        <textarea
                                            :value="
                                                firstYearData?.other_diseases
                                            "
                                            :disabled="!isEditMode"
                                            class="rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                            name=""
                                            id=""
                                            rows="5"
                                        ></textarea>
                                    </td>
                                    <td
                                        colspan="2"
                                        class="border border-black px-4 py-2"
                                    >
                                        <textarea
                                            :value="
                                                secondYearData?.other_diseases
                                            "
                                            :disabled="!isEditMode"
                                            class="rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                            name=""
                                            id=""
                                            rows="5"
                                        ></textarea>
                                    </td>
                                    <td
                                        colspan="2"
                                        class="border border-black px-4 py-2"
                                    >
                                        <textarea
                                            :value="
                                                thirdYearData?.other_diseases
                                            "
                                            :disabled="!isEditMode"
                                            class="rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                            name=""
                                            id=""
                                            rows="5"
                                        ></textarea>
                                    </td>
                                    <td
                                        colspan="2"
                                        class="border border-black px-4 py-2"
                                    >
                                        <textarea
                                            :value="
                                                fourthYearData?.other_diseases
                                            "
                                            :disabled="!isEditMode"
                                            class="rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                            name=""
                                            id=""
                                            rows="5"
                                        ></textarea>
                                    </td>
                                </tr>
                                <tr class="border border-black bg-gray-300">
                                    <td
                                        class="border border-black px-4 py-2 text-left font-bold"
                                    >
                                        TOOTH COUNT
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        T
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        P
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        T
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        P
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        T
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        P
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        T
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        P
                                    </td>
                                </tr>
                                <!-- Number of Teeth Present -->
                                <tr class="border border-black">
                                    <td class="border border-black px-4 py-2">
                                        Number of Teeth Present
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                firstYearData?.teeth_present_total
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                firstYearData?.teeth_present_permanent
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                secondYearData?.teeth_present_total
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                secondYearData?.teeth_present_permanent
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                thirdYearData?.teeth_present_total
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                thirdYearData?.teeth_present_permanent
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                fourthYearData?.teeth_present_total
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                fourthYearData?.teeth_present_permanent
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                </tr>
                                <!-- Number of Caries Free Teeth -->
                                <tr class="border border-black">
                                    <td class="border border-black px-4 py-2">
                                        Number of Caries Free Teeth
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                firstYearData?.caries_free_teeth_total
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                firstYearData?.caries_free_teeth_permanent
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                secondYearData?.caries_free_teeth_total
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                secondYearData?.caries_free_teeth_permanent
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                thirdYearData?.caries_free_teeth_total
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                thirdYearData?.caries_free_teeth_permanent
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                fourthYearData?.caries_free_teeth_total
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                fourthYearData?.caries_free_teeth_permanent
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                </tr>
                                <tr class="border border-black">
                                    <td class="border border-black px-4 py-2">
                                        Number of Teeth for Extraction
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                firstYearData?.teeth_extraction_total
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                firstYearData?.teeth_extraction_permanent
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                secondYearData?.teeth_extraction_total
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                secondYearData?.teeth_extraction_permanent
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                thirdYearData?.teeth_extraction_total
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                thirdYearData?.teeth_extraction_permanent
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                fourthYearData?.teeth_extraction_total
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                fourthYearData?.teeth_extraction_permanent
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                </tr>
                                <tr class="border border-black">
                                    <td class="border border-black px-4 py-2">
                                        Number of Teeth for Restoration
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                firstYearData?.teeth_restoration_total
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                firstYearData?.teeth_restoration_permanent
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                secondYearData?.teeth_restoration_total
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                secondYearData?.teeth_restoration_permanent
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                thirdYearData?.teeth_restoration_total
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                thirdYearData?.teeth_restoration_permanent
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                fourthYearData?.teeth_restoration_total
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                fourthYearData?.teeth_restoration_permanent
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                </tr>
                                <tr class="border border-black">
                                    <td class="border border-black px-4 py-2">
                                        Number of Missing Teeth
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                firstYearData?.missing_teeth_total
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                firstYearData?.missing_teeth_permanent
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                secondYearData?.missing_teeth_total
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                secondYearData?.missing_teeth_permanent
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                thirdYearData?.missing_teeth_total
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                thirdYearData?.missing_teeth_permanent
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                fourthYearData?.missing_teeth_total
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                fourthYearData?.missing_teeth_permanent
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                </tr>
                                <tr class="border border-black">
                                    <td class="border border-black px-4 py-2">
                                        Number of Filled Teeth
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                firstYearData?.filled_teeth_total
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                firstYearData?.filled_teeth_permanent
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                secondYearData?.filled_teeth_total
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                secondYearData?.filled_teeth_permanent
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                thirdYearData?.filled_teeth_total
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                thirdYearData?.filled_teeth_permanent
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                fourthYearData?.filled_teeth_total
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                fourthYearData?.filled_teeth_permanent
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                </tr>
                                <tr class="border border-black">
                                    <td class="border border-black px-4 py-2">
                                        Total of DF and DMF Teeth
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                firstYearData?.df_dmf_teeth_total
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                firstYearData?.df_dmf_teeth_permanent
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                secondYearData?.df_dmf_teeth_total
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                secondYearData?.df_dmf_teeth_permanent
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                thirdYearData?.df_dmf_teeth_total
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                thirdYearData?.df_dmf_teeth_permanent
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                fourthYearData?.df_dmf_teeth_total
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="
                                                fourthYearData?.df_dmf_teeth_permanent
                                            "
                                            :disabled="!isEditMode"
                                            type="number"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                </tr>
                                <!-- Examiner -->
                                <tr class="border border-black">
                                    <td class="border border-black px-4 py-2">
                                        Examiner
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="firstYearData?.examiner"
                                            :disabled="!isEditMode"
                                            type="text"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="firstYearData?.examiner"
                                            :disabled="!isEditMode"
                                            type="text"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="secondYearData?.examiner"
                                            :disabled="!isEditMode"
                                            type="text"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="secondYearData?.examiner"
                                            :disabled="!isEditMode"
                                            type="text"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="thirdYearData?.examiner"
                                            :disabled="!isEditMode"
                                            type="text"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="thirdYearData?.examiner"
                                            :disabled="!isEditMode"
                                            type="text"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="fourthYearData?.examiner"
                                            :disabled="!isEditMode"
                                            type="text"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                    <td
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <input
                                            :value="fourthYearData?.examiner"
                                            :disabled="!isEditMode"
                                            type="text"
                                            class="w-20 rounded border px-2 py-1 text-center disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                        />
                                    </td>
                                </tr>
                                <tr class="border border-black">
                                    <td class="border border-black px-4 py-2">
                                        Action
                                    </td>
                                    <td
                                        colspan="2"
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <button
                                            v-if="firstYearData.id"
                                            @click="
                                                deleteRecord(firstYearData.id)
                                            "
                                            class="rounded bg-red-500 px-4 py-2 font-bold text-white hover:bg-red-700"
                                        >
                                            Delete
                                        </button>
                                    </td>
                                    <td
                                        colspan="2"
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <button
                                            v-if="secondYearData.id"
                                            @click="
                                                deleteRecord(secondYearData.id)
                                            "
                                            class="rounded bg-red-500 px-4 py-2 font-bold text-white hover:bg-red-700"
                                        >
                                            Delete
                                        </button>
                                    </td>
                                    <td
                                        colspan="2"
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <button
                                            v-if="thirdYearData.id"
                                            @click="
                                                deleteRecord(thirdYearData.id)
                                            "
                                            class="rounded bg-red-500 px-4 py-2 font-bold text-white hover:bg-red-700"
                                        >
                                            Delete
                                        </button>
                                    </td>
                                    <td
                                        colspan="2"
                                        class="border border-black px-4 py-2 text-center"
                                    >
                                        <button
                                            v-if="fourthYearData.id"
                                            @click="
                                                deleteRecord(fourthYearData.id)
                                            "
                                            class="rounded bg-red-500 px-4 py-2 font-bold text-white hover:bg-red-700"
                                        >
                                            Delete
                                        </button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <div class="p-4">
                            <h1 class="mb-4 text-center text-xl font-bold">
                                PAST MEDICAL AND DENTAL HISTORY (-) Absence, (+)
                                Presence; please specify:
                            </h1>

                            <div
                                class="grid gap-4 md:grid-cols-2 lg:grid-cols-3"
                            >
                                <label class="flex items-center">
                                    Allergy:
                                    <input
                                        :value="history?.allergy"
                                        :disabled="!isEditMode"
                                        type="text"
                                        class="ml-2 rounded-md border border-black px-2 py-1 disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                    />
                                </label>

                                <label class="flex items-center">
                                    Diabetes:
                                    <input
                                        :value="history?.diabetes"
                                        :disabled="!isEditMode"
                                        type="text"
                                        class="ml-2 rounded-md border border-black px-2 py-1 disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                    />
                                </label>

                                <label class="flex items-center">
                                    Blood Dyscrasia:
                                    <input
                                        :value="history?.blood_dyscrasia"
                                        :disabled="!isEditMode"
                                        type="text"
                                        class="ml-2 rounded-md border border-black px-2 py-1 disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                    />
                                </label>
                            </div>

                            <div
                                class="mt-2 grid gap-4 md:grid-cols-2 lg:grid-cols-3"
                            >
                                <label class="flex items-center">
                                    CNS Disorder:
                                    <input
                                        :value="history?.cns_disorder"
                                        :disabled="!isEditMode"
                                        type="text"
                                        class="ml-2 rounded-md border border-black px-2 py-1 disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                    />
                                </label>

                                <label class="flex items-center">
                                    Cardiovascular Disease:
                                    <input
                                        :value="history?.cardiovascular_disease"
                                        :disabled="!isEditMode"
                                        type="text"
                                        class="ml-2 rounded-md border border-black px-2 py-1 disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                    />
                                </label>

                                <label class="flex items-center">
                                    Others:
                                    <input
                                        :value="history?.other_histories"
                                        :disabled="!isEditMode"
                                        type="text"
                                        class="ml-2 rounded-md border border-black px-2 py-1 disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                    />
                                </label>
                            </div>

                            <div class="mt-4">
                                <label class="flex items-center">
                                    Dental Surgical Procedure/s Done:
                                    <input
                                        :value="
                                            history?.dental_surgical_procedures
                                        "
                                        :disabled="!isEditMode"
                                        type="text"
                                        class="ml-2 w-full rounded-md border border-black px-2 py-1 disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
                                    />
                                </label>
                            </div>
                            <button
                                v-if="history.id"
                                @click="deleteHealthStatus(history.id)"
                                class="rounded bg-red-500 px-4 py-2 font-bold text-white hover:bg-red-700"
                            >
                                Delete
                            </button>
                        </div>
                    </div>
                </div>
                <div class="mt-8 flex flex-col items-center gap-2">
                    <template v-if="!isEditMode">
                        <button
                            class="w-full rounded-md bg-[#347956] px-14 py-1 font-medium text-white hover:bg-emerald-800 md:w-1/3"
                            type="button"
                            @click="openModal()"
                        >
                            EDIT
                        </button>
                    </template>

                    <template v-if="isEditMode">
                        <button
                            class="w-full rounded-md bg-red-500 px-14 py-1 font-medium text-white hover:bg-red-800 md:w-1/3"
                            type="button"
                            @click="refresh()"
                        >
                            CANCEL
                        </button>
                        <button
                            class="w-full rounded-md bg-[#347956] px-14 py-1 font-medium text-white hover:bg-emerald-800 md:w-1/3"
                            type="button"
                            @click="handleSubmit()"
                        >
                            ADD
                        </button>
                    </template>
                </div>
            </div>
        </div>
        <dialog
            ref="dialogRef"
            class="max-h-[calc(100vh-4rem)] w-full max-w-lg overflow-y-auto rounded-lg bg-white p-6 shadow-lg"
        >
            <h2 class="mb-4 text-xl font-bold text-gray-800">
                Consultation Form
            </h2>
            <div v-if="isLoading">
                <Spinner />
            </div>
            <div v-if="!isLoading">
                <form @submit.prevent="handleSubmit">
                    <div class="mb-4">
                        <label
                            for="date"
                            class="block text-sm font-medium text-gray-700"
                            >Date</label
                        >
                        <input
                            type="date"
                            v-model="formData.date"
                            id="date"
                            class="mt-1 w-full rounded-md border border-black p-2"
                            rows="3"
                            placeholder="Enter date here"
                            required
                        />
                    </div>
                    <div class="mb-4">
                        <label
                            for="year"
                            class="block text-sm font-medium text-gray-700"
                            >Year</label
                        >
                        <select
                            v-model="formData.year"
                            name="year"
                            id="year"
                            required
                            class="mt-1 w-full rounded-md border border-black p-2"
                        >
                            <option
                                v-for="(year, index) in availableYear"
                                :value="year"
                                :key="index"
                            >
                                {{ year }}
                            </option>
                        </select>
                    </div>
                    <div class="mb-4">
                        <label class="block text-sm font-medium text-gray-700"
                            >Debris Tooth Stain</label
                        >
                        <div
                            class="mt-1 w-full rounded-md border border-black p-2"
                        >
                            <input
                                v-model="formData.debris_tooth_stain"
                                type="radio"
                                required
                                name="debris_tooth_stain"
                                class="ml-2 mr-1"
                                :value="true"
                            />Y
                            <input
                                v-model="formData.debris_tooth_stain"
                                type="radio"
                                required
                                name="debris_tooth_stain"
                                class="ml-2 mr-1"
                                :value="false"
                            />N
                        </div>
                    </div>
                    <div class="mb-4">
                        <label class="block text-sm font-medium text-gray-700"
                            >Calculus Deposit</label
                        >
                        <div
                            class="mt-1 w-full rounded-md border border-black p-2"
                        >
                            <input
                                v-model="formData.calculus_deposit"
                                type="radio"
                                required
                                name="calculus_deposit"
                                class="ml-2 mr-1"
                                :value="true"
                            />Y
                            <input
                                v-model="formData.calculus_deposit"
                                type="radio"
                                required
                                name="calculus_deposit"
                                class="ml-2 mr-1"
                                :value="false"
                            />N
                        </div>
                    </div>
                    <div class="mb-4">
                        <label class="block text-sm font-medium text-gray-700"
                            >Gingivitis</label
                        >
                        <div
                            class="mt-1 w-full rounded-md border border-black p-2"
                        >
                            <input
                                v-model="formData.gingivitis"
                                type="radio"
                                required
                                name="gingivitis"
                                class="ml-2 mr-1"
                                :value="true"
                            />Y
                            <input
                                v-model="formData.gingivitis"
                                type="radio"
                                required
                                name="gingivitis"
                                class="ml-2 mr-1"
                                :value="false"
                            />N
                        </div>
                    </div>
                    <div class="mb-4">
                        <label class="block text-sm font-medium text-gray-700"
                            >Periodontal Pocket</label
                        >
                        <div
                            class="mt-1 w-full rounded-md border border-black p-2"
                        >
                            <input
                                v-model="formData.periodontal_pocket"
                                type="radio"
                                required
                                name="periodontal_pocket"
                                class="ml-2 mr-1"
                                :value="true"
                            />Y
                            <input
                                v-model="formData.periodontal_pocket"
                                type="radio"
                                required
                                name="periodontal_pocket"
                                class="ml-2 mr-1"
                                :value="false"
                            />N
                        </div>
                    </div>
                    <div class="mb-4">
                        <label class="block text-sm font-medium text-gray-700"
                            >Orthodontic Treatment</label
                        >
                        <div
                            class="mt-1 w-full rounded-md border border-black p-2"
                        >
                            <input
                                v-model="formData.orthodontic_treatment"
                                type="radio"
                                required
                                name="orthodontic_treatment"
                                class="ml-2 mr-1"
                                :value="true"
                            />Y
                            <input
                                v-model="formData.orthodontic_treatment"
                                type="radio"
                                required
                                name="orthodontic_treatment"
                                class="ml-2 mr-1"
                                :value="false"
                            />N
                        </div>
                    </div>
                    <div class="mb-4">
                        <label
                            for="other_diseases"
                            class="block text-sm font-medium text-gray-700"
                            >Other Disease</label
                        >
                        <input
                            v-model="formData.other_diseases"
                            type="text"
                            id="other_diseases"
                            class="mt-1 w-full rounded-md border border-black p-2"
                            rows="3"
                        />
                    </div>
                    <div class="mb-4">
                        <label
                            for="teeth_present_total"
                            class="block text-sm font-medium text-gray-700"
                            >Teeth Present Total</label
                        >
                        <input
                            v-model="formData.teeth_present_total"
                            type="number"
                            id="teeth_present_total"
                            class="mt-1 w-full rounded-md border border-black p-2"
                            rows="3"
                        />
                    </div>

                    <div class="mb-4">
                        <label
                            for="teeth_present_permanent"
                            class="block text-sm font-medium text-gray-700"
                            >Teeth Present Permanent</label
                        >
                        <input
                            v-model="formData.teeth_present_permanent"
                            type="number"
                            id="teeth_present_permanent"
                            class="mt-1 w-full rounded-md border border-black p-2"
                            rows="3"
                        />
                    </div>

                    <div class="mb-4">
                        <label
                            for="caries_free_teeth_total"
                            class="block text-sm font-medium text-gray-700"
                            >Caries Free Teeth Total</label
                        >
                        <input
                            v-model="formData.caries_free_teeth_total"
                            type="number"
                            id="caries_free_teeth_total"
                            class="mt-1 w-full rounded-md border border-black p-2"
                            rows="3"
                        />
                    </div>

                    <div class="mb-4">
                        <label
                            for="caries_free_teeth_permanent"
                            class="block text-sm font-medium text-gray-700"
                            >Caries Free Teeth Permanent</label
                        >
                        <input
                            v-model="formData.caries_free_teeth_permanent"
                            type="number"
                            id="caries_free_teeth_permanent"
                            class="mt-1 w-full rounded-md border border-black p-2"
                            rows="3"
                        />
                    </div>

                    <div class="mb-4">
                        <label
                            for="teeth_extraction_total"
                            class="block text-sm font-medium text-gray-700"
                            >Teeth Extraction Total</label
                        >
                        <input
                            v-model="formData.teeth_extraction_total"
                            type="number"
                            id="teeth_extraction_total"
                            class="mt-1 w-full rounded-md border border-black p-2"
                            rows="3"
                        />
                    </div>

                    <div class="mb-4">
                        <label
                            for="teeth_extraction_permanent"
                            class="block text-sm font-medium text-gray-700"
                            >Teeth Extraction Permanent</label
                        >
                        <input
                            v-model="formData.teeth_extraction_permanent"
                            type="number"
                            id="teeth_extraction_permanent"
                            class="mt-1 w-full rounded-md border border-black p-2"
                            rows="3"
                        />
                    </div>

                    <div class="mb-4">
                        <label
                            for="teeth_restoration_total"
                            class="block text-sm font-medium text-gray-700"
                            >Teeth Restoration Total</label
                        >
                        <input
                            v-model="formData.teeth_restoration_total"
                            type="number"
                            id="teeth_restoration_total"
                            class="mt-1 w-full rounded-md border border-black p-2"
                            rows="3"
                        />
                    </div>

                    <div class="mb-4">
                        <label
                            for="teeth_restoration_permanent"
                            class="block text-sm font-medium text-gray-700"
                            >Teeth Restoration Permanent</label
                        >
                        <input
                            v-model="formData.teeth_restoration_permanent"
                            type="number"
                            id="teeth_restoration_permanent"
                            class="mt-1 w-full rounded-md border border-black p-2"
                            rows="3"
                        />
                    </div>

                    <div class="mb-4">
                        <label
                            for="missing_teeth_total"
                            class="block text-sm font-medium text-gray-700"
                            >Missing Teeth Total</label
                        >
                        <input
                            v-model="formData.missing_teeth_total"
                            type="number"
                            id="missing_teeth_total"
                            class="mt-1 w-full rounded-md border border-black p-2"
                            rows="3"
                        />
                    </div>

                    <div class="mb-4">
                        <label
                            for="missing_teeth_permanent"
                            class="block text-sm font-medium text-gray-700"
                            >Missing Teeth Permanent</label
                        >
                        <input
                            v-model="formData.missing_teeth_permanent"
                            type="number"
                            id="missing_teeth_permanent"
                            class="mt-1 w-full rounded-md border border-black p-2"
                            rows="3"
                        />
                    </div>

                    <div class="mb-4">
                        <label
                            for="filled_teeth_total"
                            class="block text-sm font-medium text-gray-700"
                            >Filled Teeth Total</label
                        >
                        <input
                            v-model="formData.filled_teeth_total"
                            type="number"
                            id="filled_teeth_total"
                            class="mt-1 w-full rounded-md border border-black p-2"
                            rows="3"
                        />
                    </div>

                    <div class="mb-4">
                        <label
                            for="filled_teeth_permanent"
                            class="block text-sm font-medium text-gray-700"
                            >Filled Teeth Permanent</label
                        >
                        <input
                            v-model="formData.filled_teeth_permanent"
                            type="number"
                            id="filled_teeth_permanent"
                            class="mt-1 w-full rounded-md border border-black p-2"
                            rows="3"
                        />
                    </div>

                    <div class="mb-4">
                        <label
                            for="df_dmf_teeth_total"
                            class="block text-sm font-medium text-gray-700"
                            >DF DMF Teeth Total</label
                        >
                        <input
                            v-model="formData.df_dmf_teeth_total"
                            type="number"
                            id="df_dmf_teeth_total"
                            class="mt-1 w-full rounded-md border border-black p-2"
                            rows="3"
                        />
                    </div>

                    <div class="mb-4">
                        <label
                            for="df_dmf_teeth_permanent"
                            class="block text-sm font-medium text-gray-700"
                            >DF DMF Teeth Permanent</label
                        >
                        <input
                            v-model="formData.df_dmf_teeth_permanent"
                            type="number"
                            id="df_dmf_teeth_permanent"
                            class="mt-1 w-full rounded-md border border-black p-2"
                            rows="3"
                        />
                    </div>

                    <div v-if="Object.keys(history).length === 0">
                        <label
                            class="inline-flex cursor-pointer items-center peer-checked:bg-blue-600"
                        >
                            <input
                                type="checkbox"
                                class="peer sr-only"
                                v-model="selectedValue"
                            />
                            <div
                                class="peer relative h-6 w-11 rounded-full bg-gray-200 after:absolute after:start-[2px] after:top-[2px] after:h-5 after:w-5 after:rounded-full after:border after:border-gray-300 after:bg-white after:transition-all after:content-[''] peer-checked:bg-blue-600 peer-checked:after:translate-x-full peer-checked:after:border-white peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rtl:peer-checked:after:-translate-x-full dark:border-gray-600 dark:bg-gray-700 dark:peer-checked:bg-blue-600 dark:peer-focus:ring-blue-800"
                            ></div>
                            <span
                                class="ms-3 text-sm font-medium text-gray-900 dark:text-gray-300"
                                >History</span
                            >
                        </label>
                        <div v-if="selectedValue === true">
                            <div class="mb-4">
                                <label
                                    for="examiner"
                                    class="block text-sm font-medium text-gray-700"
                                    >Examiner</label
                                >
                                <input
                                    v-model="formData.history.examiner"
                                    type="text"
                                    id="examiner"
                                    class="mt-1 w-full rounded-md border border-black p-2"
                                    rows="3"
                                />
                            </div>
                            <div class="mb-4">
                                <label
                                    for="allergy"
                                    class="block text-sm font-medium text-gray-700"
                                    >Allergy</label
                                >
                                <input
                                    v-model="formData.history.allergy"
                                    type="text"
                                    id="allergy"
                                    class="mt-1 w-full rounded-md border border-black p-2"
                                    rows="3"
                                />
                            </div>
                            <div class="mb-4">
                                <label
                                    for="diabetes"
                                    class="block text-sm font-medium text-gray-700"
                                    >Diabetes</label
                                >
                                <input
                                    v-model="formData.history.diabetes"
                                    type="text"
                                    id="diabetes"
                                    class="mt-1 w-full rounded-md border border-black p-2"
                                    rows="3"
                                />
                            </div>
                            <div class="mb-4">
                                <label
                                    for="blood_dyscrasia"
                                    class="block text-sm font-medium text-gray-700"
                                    >Blood Dyscrasia</label
                                >
                                <input
                                    v-model="formData.history.blood_dyscrasia"
                                    type="text"
                                    id="blood_dyscrasia"
                                    class="mt-1 w-full rounded-md border border-black p-2"
                                    rows="3"
                                />
                            </div>
                            <div class="mb-4">
                                <label
                                    for="cns_disorder"
                                    class="block text-sm font-medium text-gray-700"
                                    >CNS Disorder</label
                                >
                                <input
                                    v-model="formData.history.cns_disorder"
                                    type="text"
                                    id="cns_disorder"
                                    class="mt-1 w-full rounded-md border border-black p-2"
                                    rows="3"
                                />
                            </div>
                            <div class="mb-4">
                                <label
                                    for="cardiovascular_disease"
                                    class="block text-sm font-medium text-gray-700"
                                    >Cardiovascular Disease</label
                                >
                                <input
                                    v-model="
                                        formData.history.cardiovascular_disease
                                    "
                                    type="text"
                                    id="cardiovascular_disease"
                                    class="mt-1 w-full rounded-md border border-black p-2"
                                    rows="3"
                                />
                            </div>
                            <div class="mb-4">
                                <label
                                    for="other_histories"
                                    class="block text-sm font-medium text-gray-700"
                                    >Other Histories</label
                                >
                                <input
                                    v-model="formData.history.other_histories"
                                    type="text"
                                    id="other_histories"
                                    class="mt-1 w-full rounded-md border border-black p-2"
                                    rows="3"
                                />
                            </div>
                            <div class="mb-4">
                                <label
                                    for="dental_surgical_procedures"
                                    class="block text-sm font-medium text-gray-700"
                                    >Dental Surgical Procedures</label
                                >
                                <input
                                    v-model="
                                        formData.history
                                            .dental_surgical_procedures
                                    "
                                    type="text"
                                    id="dental_surgical_procedures"
                                    class="mt-1 w-full rounded-md border border-black p-2"
                                    rows="3"
                                />
                            </div>
                        </div>
                    </div>
                    <div
                        class="flex flex-wrap justify-center gap-4 sm:justify-end"
                    >
                        <button
                            @click="closeDialog"
                            type="button"
                            class="rounded bg-gray-200 px-4 py-2 text-gray-800 hover:bg-gray-300"
                        >
                            Cancel
                        </button>
                        <button
                            type="submit"
                            class="rounded bg-[#347956] px-4 py-2 text-white hover:bg-emerald-800"
                        >
                            Submit
                        </button>
                    </div>
                </form>
            </div>
        </dialog>
    </div>
</template>
<script setup>
import axios from "axios";
import { useAuthStore } from "~/stores/auth";
import { toast } from "vue3-toastify";
import "vue3-toastify/dist/index.css";

definePageMeta({
    layout: "user",
    middleware: ["dental-doctor"],
});

const dialogRef = ref(null);
const selectedValue = ref(false);
const route = useRoute();
const itemId = route.params.id;
const authStore = useAuthStore();
const isLoading = ref(true);
const isEditMode = ref(false);
const firstYearData = ref({});
const secondYearData = ref({});
const thirdYearData = ref({});
const fourthYearData = ref({});
const records = ref([]);
const history = ref({});

const initialFormData = ref({
    date: "",
    year: "",
    debris_tooth_stain: "",
    calculus_deposit: "",
    gingivitis: "",
    periodontal_pocket: "",
    orthodontic_treatment: "",
    other_diseases: "",
    teeth_present_total: "",
    teeth_present_permanent: "",
    caries_free_teeth_total: "",
    caries_free_teeth_permanent: "",
    teeth_extraction_total: "",
    teeth_extraction_permanent: "",
    teeth_restoration_total: "",
    teeth_restoration_permanent: "",
    missing_teeth_total: "",
    missing_teeth_permanent: "",
    filled_teeth_total: "",
    filled_teeth_permanent: "",
    df_dmf_teeth_total: "",
    df_dmf_teeth_permanent: "",
    history: {
        examiner: "",
        allergy: "",
        diabetes: "",
        blood_dyscrasia: "",
        cns_disorder: "",
        cardiovascular_disease: "",
        other_histories: "",
        dental_surgical_procedures: "",
    },
    patient_id_number: itemId,
});

const formData = ref({
    date: "",
    year: "",
    debris_tooth_stain: "",
    calculus_deposit: "",
    gingivitis: "",
    periodontal_pocket: "",
    orthodontic_treatment: "",
    other_diseases: "",
    teeth_present_total: "",
    teeth_present_permanent: "",
    caries_free_teeth_total: "",
    caries_free_teeth_permanent: "",
    teeth_extraction_total: "",
    teeth_extraction_permanent: "",
    teeth_restoration_total: "",
    teeth_restoration_permanent: "",
    missing_teeth_total: "",
    missing_teeth_permanent: "",
    filled_teeth_total: "",
    filled_teeth_permanent: "",
    df_dmf_teeth_total: "",
    df_dmf_teeth_permanent: "",
    history: {
        examiner: "",
        allergy: "",
        diabetes: "",
        blood_dyscrasia: "",
        cns_disorder: "",
        cardiovascular_disease: "",
        other_histories: "",
        dental_surgical_procedures: "",
    },
    patient_id_number: itemId,
});

watch(selectedValue, (newValue) => {
});

const availableYear = computed(() => {
    const years = ["1st", "2nd", "3rd", "4th"];
    return years.filter(
        (year) => !records.value.some((record) => record.year === year),
    );
});

const closeDialog = () => {
    dialogRef.value?.close();
};

const openModal = () => {
    dialogRef.value.showModal();
};

const toggleEditMode = async () => {
    isEditMode.value = !isEditMode.value;
};

const refresh = async () => {
    window.location.reload();
};

const formatTimestamp = (timestamp) => {
    const dateObj = new Date(timestamp);

    return dateObj.toLocaleString("en-US", {
        year: "numeric",
        month: "numeric",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        hour12: true,
    });
};

const handleSubmit = async () => {
    isLoading.value = true;
    let formValue = formData.value;
    if (Object.keys(history.value).length !== 0 || selectedValue.value === false) {
        const { history, ...formDataWithoutHistory } = formData.value;
        formValue = formDataWithoutHistory;
    }

    try {
        await axios.post(
            `${useRuntimeConfig().public.laravelURL}user/oral-health-conditions`,
            formValue,
            {
                headers: {
                    Authorization: `Bearer ${authStore.token}`,
                },
            },
        );
        closeDialog();
        await fetchRecord();
        formData.value = { ...initialFormData.value };
        toast.success("Record added successfully");
    } catch (error) {
        closeDialog();
        toast.error("Failed");
    } finally {
        isLoading.value = false;
    }
};

const fetchRecord = async () => {
    isLoading.value = true;
    try {
        const { data } = await axios.get(
            `${useRuntimeConfig().public.laravelURL}user/oral-health-conditions`,
            {
                params: {
                    patient_id_number: itemId,
                },
                headers: {
                    Authorization: `Bearer ${authStore.token}`,
                },
            },
        );

        firstYearData.value = {};
        secondYearData.value = {};
        thirdYearData.value = {};
        fourthYearData.value = {};
        history.value = {};

        data.oral_health_conditions.forEach((record) => {
            switch (record.year) {
                case "1st":
                    firstYearData.value = record;
                    break;
                case "2nd":
                    secondYearData.value = record;
                    break;
                case "3rd":
                    thirdYearData.value = record;
                    break;
                case "4th":
                    fourthYearData.value = record;
                    break;
                default:
                    break;
            }
        });

        if (data.history.length > 0) {
            history.value = data.history[0];
        }

        records.value = data.oral_health_conditions;
    } catch (error) {
        console.log(error);
    } finally {
        isLoading.value = false;
    }
};

const deleteRecord = async (id) => {
    isLoading.value = true;
    try {
        await axios.delete(
            `${useRuntimeConfig().public.laravelURL}user/oral-health-conditions/${id}`,
            {
                headers: {
                    Authorization: `Bearer ${authStore.token}`,
                },
            },
        );
        toast.success("Record deleted successfully");
    } catch (error) {
        toast.error("Failed");
        console.log("Error Deleting");
    } finally {
        await fetchRecord();
        isLoading.value = false;
    }
};
const deleteHealthStatus = async (id) => {
    isLoading.value = true;
    try {
        await axios.delete(
            `${useRuntimeConfig().public.laravelURL}user/oral-health-histories/${id}`,
            {
                headers: {
                    Authorization: `Bearer ${authStore.token}`,
                },
            },
        );
        toast.success("Record deleted successfully");
    } catch (error) {
        toast.error("Failed");
        console.log("Error Deleting");
    } finally {
        await fetchRecord();
        isLoading.value = false;
    }
};

onMounted(async () => {
    await fetchRecord();
});
</script>

<style scoped>
::backdrop {
    backdrop-filter: blur(5px);
    background-color: rgba(0, 0, 0, 0.4);
}
</style>

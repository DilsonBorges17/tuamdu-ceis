<template>
    <div class="mx-auto mt-16 max-w-7xl">
        <div class="flex flex-wrap">
            <NuxtLink
                class="rounded-md border border-black bg-[#a6a6a6] px-4 py-2 font-bold text-black hover:bg-[#d9d9d9]"
                :to="`/user/medical-health-record/${itemId}`"
                >Medical Health Record</NuxtLink
            >
            <NuxtLink
                class="rounded-md border border-black bg-[#a6a6a6] px-4 py-2 font-bold text-black hover:bg-[#d9d9d9]"
                :to="`/user/medical-health-record/${itemId}-health-history`"
                >Health History</NuxtLink
            >
            <NuxtLink
                class="rounded-md border border-black bg-[#a6a6a6] px-4 py-2 font-bold text-black hover:bg-[#d9d9d9]"
                :to="`/user/medical-health-record/${itemId}-physical-examination`"
                >Physical Examination</NuxtLink
            >
            <NuxtLink
                class="rounded-md border border-black bg-[#a6a6a6] px-4 py-2 font-bold text-black hover:bg-[#d9d9d9]"
                to="#"
                >Consultation Record</NuxtLink
            >
        </div>
        <div v-if="isLoading">
            <Spinner />
        </div>
        <div v-if="!isLoading">
            <div>
                <div
                    class="grid gap-4 rounded-md border border-black bg-white px-2 py-8 shadow-lg sm:px-10"
                >
                    <div class="flex flex-col items-center justify-center">
                        <img src="/tua-logo.png" alt="logo" />
                        <h1 class="text-2xl uppercase">
                            Trinity University of Asia
                        </h1>
                        <p>Medical and Dental Unit</p>
                    </div>
                    <h2 class="bg-black text-center font-bold text-white">
                        Consultation Record
                    </h2>
                    <div class="overflow-x-auto">
                        <table class="w-full border border-black">
                            <thead class="bg-[#e0dcdc]">
                                <tr class="text-center font-bold">
                                    <td class="border border-black">
                                        Date / Time
                                    </td>
                                    <td class="border border-black px-5 py-1">
                                        Complaints
                                    </td>
                                    <td class="border border-black px-5 py-1">
                                        Treatment
                                    </td>
                                    <td class="border border-black px-5 py-1">
                                        Services Rendered Recommendation
                                    </td>
                                    <td class="border border-black px-5 py-1">
                                        Remarks
                                    </td>
                                    <td class="border border-black px-5 py-1">
                                        Action
                                    </td>
                                </tr>
                            </thead>
                            <tbody>
                                <template v-if="records.length > 0">
                                    <tr
                                        v-for="record in records"
                                        :key="record.id"
                                        class="text-center font-bold odd:bg-white even:bg-[#D9D9D9]"
                                    >
                                        <td
                                            class="border border-black px-5 py-1"
                                        >
                                            {{
                                                formatTimestamp(
                                                    record.created_at,
                                                )
                                            }}
                                        </td>
                                        <td
                                            class="border border-black px-5 py-1"
                                        >
                                            {{ record.complaints }}
                                        </td>
                                        <td
                                            class="border border-black px-5 py-1"
                                        >
                                            {{ record.treatment }}
                                        </td>
                                        <td
                                            class="border border-black px-5 py-1"
                                        >
                                            {{ record.recommendation }}
                                        </td>
                                        <td
                                            class="border border-black px-5 py-1"
                                        >
                                            {{ record.remarks }}
                                        </td>
                                        <td
                                            class="border border-black px-5 py-1"
                                        >
                                            <button
                                                @click="deleteRecord(record.id)"
                                            >
                                                <Icon
                                                    class="text-red-500 hover:text-red-900"
                                                    name="ep:delete"
                                                    style="font-size: 1rem"
                                                />
                                            </button>
                                        </td>
                                    </tr>
                                </template>
                                <template v-else>
                                    <tr>
                                        <td
                                            colspan="6"
                                            class="p-5 text-center text-gray-500"
                                        >
                                            No Records Found
                                        </td>
                                    </tr>
                                </template>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="mt-8 flex flex-col items-center gap-2">
                    <button
                        :class="{
                            'bg-[#347956] hover:bg-emerald-800': isReadOnly,
                            'bg-red-500 hover:bg-red-700': !isReadOnly,
                        }"
                        class="w-full rounded-md px-14 py-1 font-medium text-white md:w-1/3"
                        type="button"
                        @click="openModal()"
                    >
                        ADD
                    </button>
                </div>
            </div>
        </div>
        <dialog
            ref="dialogRef"
            class="w-full max-w-lg rounded-lg bg-white p-6 shadow-lg"
        >
            <h2 class="mb-4 text-xl font-bold text-gray-800">
                Consultation Form
            </h2>
            <div v-if="isLoading">
                <Spinner />
            </div>
            <div v-if="!isLoading">
                <form @submit.prevent="handleSubmit">
                    <div class="mb-4">
                        <label
                            for="complaints"
                            class="block text-sm font-medium text-gray-700"
                            >Complaints</label
                        >
                        <textarea
                            v-model="formData.complaints"
                            id="complaints"
                            class="mt-1 w-full rounded-md border border-black p-2"
                            rows="3"
                            placeholder="Enter complaints here"
                            required
                        ></textarea>
                    </div>
                    <div class="mb-4">
                        <label
                            for="treatments"
                            class="block text-sm font-medium text-gray-700"
                            >Treatments</label
                        >
                        <textarea
                            v-model="formData.treatment"
                            id="treatments"
                            class="mt-1 w-full rounded-md border border-black p-2"
                            rows="3"
                            placeholder="Enter treatments here"
                            required
                        ></textarea>
                    </div>
                    <div class="mb-4">
                        <label
                            for="service-rendered"
                            class="block text-sm font-medium text-gray-700"
                            >Service Rendered Recommendation</label
                        >
                        <textarea
                            v-model="formData.recommendation"
                            id="service-rendered"
                            class="mt-1 w-full rounded-md border border-black p-2"
                            rows="3"
                            placeholder="Enter service rendered recommendation here"
                            required
                        ></textarea>
                    </div>
                    <div class="mb-4">
                        <label
                            for="remarks"
                            class="block text-sm font-medium text-gray-700"
                            >Remarks</label
                        >
                        <textarea
                            v-model="formData.remarks"
                            id="remarks"
                            class="mt-1 w-full rounded-md border border-black p-2"
                            rows="2"
                            placeholder="Enter remarks here"
                            required
                        ></textarea>
                    </div>
                    <div
                        class="flex flex-wrap justify-center gap-4 sm:justify-end"
                    >
                        <button
                            @click="closeDialog"
                            type="button"
                            class="rounded bg-gray-200 px-4 py-2 text-gray-800 hover:bg-gray-300"
                        >
                            Cancel
                        </button>
                        <button
                            type="submit"
                            class="rounded bg-[#347956] px-4 py-2 text-white hover:bg-emerald-800"
                        >
                            Submit
                        </button>
                    </div>
                </form>
            </div>
        </dialog>
    </div>
</template>
<script setup>
import axios from "axios";
import { useAuthStore } from "~/stores/auth";
import { toast } from "vue3-toastify";
import 'vue3-toastify/dist/index.css';

definePageMeta({
    layout: "user",
    middleware: ["medical-doctor"],
});

const dialogRef = ref(null);
const route = useRoute();
const itemId = route.params.id;
const authStore = useAuthStore();
const isReadOnly = ref(true);
const isLoading = ref(true);
const records = ref([]);

const initialFormData = ref({
    complaints: "",
    treatment: "",
    recommendation: "",
    remarks: "",
    service_category_id: "1",
    patient_id_number: itemId,
});

const formData = ref({
    complaints: "",
    treatment: "",
    recommendation: "",
    remarks: "",
    service_category_id: "1",
    patient_id_number: itemId,
});

const closeDialog = () => {
    dialogRef.value?.close();
};

const openModal = () => {
    dialogRef.value.showModal();
};

const formatTimestamp = (timestamp) => {
    const dateObj = new Date(timestamp);

    return dateObj.toLocaleString("en-US", {
        year: "numeric",
        month: "numeric",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        hour12: true,
    });
};

const handleSubmit = async () => {
    isLoading.value = true;
    try {
        await axios.post(
            `${useRuntimeConfig().public.laravelURL}user/consultation-records`,
            formData.value,
            {
                headers: {
                    Authorization: `Bearer ${authStore.token}`,
                },
            },
        );
        await fetchRecord();
        closeDialog();
        formData.value = { ...initialFormData.value };
        toast.success("Record added successfully");
    } catch (error) {
        closeDialog();
        toast.error("Failed");
        console.log(error);
    } finally {
        isLoading.value = false;
    }
};

const fetchRecord = async () => {
    isLoading.value = true;
    try {
        const { data } = await axios.get(
            `${useRuntimeConfig().public.laravelURL}user/consultation-records`,
            {
                params: {
                    patient_id_number: itemId,
                },
                headers: {
                    Authorization: `Bearer ${authStore.token}`,
                },
            },
        );

        records.value = data;
    } catch (error) {
        console.log(error);
    } finally {
        isLoading.value = false;
    }
};

const deleteRecord = async (id) => {
    try {
        const result = await axios.delete(
            `${useRuntimeConfig().public.laravelURL}user/consultation-records/${id}`,
            {
                headers: {
                    Authorization: `Bearer ${authStore.token}`,
                },
            },
        );
        await fetchRecord();
        toast.success("Record deleted successfully");
    } catch (error) {
        console.log("Error Deleting");
    }
};

onMounted(async () => {
    await fetchRecord();
});
</script>

<style scoped>
::backdrop {
    backdrop-filter: blur(5px);
    background-color: rgba(0, 0, 0, 0.4);
}
</style>

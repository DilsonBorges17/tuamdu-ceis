<template>
    <div class="mx-auto mt-16 max-w-7xl">
        <div class="flex flex-wrap">
            <NuxtLink
                class="rounded-md border border-black bg-[#a6a6a6] px-4 py-2 font-bold text-black hover:bg-[#d9d9d9]"
                :to="`/user/medical-health-record/${itemId}`"
                >Medical Health Record</NuxtLink
            >
            <NuxtLink
                class="rounded-md border border-black bg-[#a6a6a6] px-4 py-2 font-bold text-black hover:bg-[#d9d9d9]"
                to="#"
                >Health History</NuxtLink
            >
            <NuxtLink
                class="rounded-md border border-black bg-[#a6a6a6] px-4 py-2 font-bold text-black hover:bg-[#d9d9d9]"
                :to="`/user/medical-health-record/${itemId}-physical-examination`"
                >Physical Examination</NuxtLink
            >
            <NuxtLink
                class="rounded-md border border-black bg-[#a6a6a6] px-4 py-2 font-bold text-black hover:bg-[#d9d9d9]"
                :to="`/user/medical-health-record/${itemId}-consultation-record`"
                >Consultation Record</NuxtLink
            >
        </div>
        <div v-if="isLoading">
            <Spinner />
        </div>
        <div v-if="!isLoading">
            <div>
                <div
                    class="grid gap-4 border border-black bg-white px-4 py-8 shadow-lg"
                >
                    <div class="flex flex-col items-center justify-center">
                        <img src="/tua-logo.png" alt="logo" />
                        <h1 class="text-2xl uppercase">
                            Trinity University of Asia
                        </h1>
                        <p>Medical and Dental Unit</p>
                    </div>
                    <h2 class="bg-black text-center font-bold text-white">
                        HEALTH HISTORY
                    </h2>

                    <form
                        @submit.prevent="handleSubmit()"
                        class="grid rounded-md border border-[#928F8F] bg-[#D9D9D9] p-3"
                    >
                        <h3 class="text-center font-bold">Immunization</h3>
                        <div class="mt-5 grid gap-5 sm:grid-cols-2">
                            <div class="grid">
                                <div
                                    class="flex flex-wrap justify-between gap-5"
                                >
                                    <label class="font-bold" for="dpt/opv">
                                        <input
                                            :disabled="!isEditMode"
                                            type="checkbox"
                                            id="dpt/opv"
                                            value="DPT/OPV"
                                            v-model="dpt_opv_computed"
                                        />
                                        DPT/OPV
                                    </label>

                                    <div class="flex gap-3">
                                        <label class="font-bold">
                                            <input
                                                :disabled="!isEditMode"
                                                name="dptClassified"
                                                type="radio"
                                                value="0"
                                                v-model="
                                                    formData.dpt_opv_classification
                                                "
                                            />
                                            0
                                        </label>
                                        <label class="font-bold">
                                            <input
                                                :disabled="!isEditMode"
                                                name="dptClassified"
                                                type="radio"
                                                value="1"
                                                v-model="
                                                    formData.dpt_opv_classification
                                                "
                                            />
                                            1
                                        </label>
                                        <label class="font-bold">
                                            <input
                                                :disabled="!isEditMode"
                                                name="dptClassified"
                                                type="radio"
                                                value="2"
                                                v-model="
                                                    formData.dpt_opv_classification
                                                "
                                            />
                                            2
                                        </label>
                                        <label class="font-bold">
                                            <input
                                                :disabled="!isEditMode"
                                                name="dptClassified"
                                                type="radio"
                                                value="3"
                                                v-model="
                                                    formData.dpt_opv_classification
                                                "
                                            />
                                            3
                                        </label>
                                        <label class="font-bold">
                                            <input
                                                :disabled="!isEditMode"
                                                name="dptClassified"
                                                type="radio"
                                                value="B"
                                                v-model="
                                                    formData.dpt_opv_classification
                                                "
                                            />
                                            B
                                        </label>
                                    </div>
                                </div>
                                <div
                                    class="flex flex-wrap justify-between gap-5"
                                >
                                    <label class="font-bold" for="hib">
                                        <input
                                            :disabled="!isEditMode"
                                            type="checkbox"
                                            id="hib"
                                            value="HiB"
                                            v-model="hib_computed"
                                        />
                                        HiB
                                    </label>

                                    <div class="flex gap-3">
                                        <label class="font-bold">
                                            <input
                                                :disabled="!isEditMode"
                                                name="hibClassified"
                                                type="radio"
                                                value="0"
                                                v-model="
                                                    formData.hib_classification
                                                "
                                            />
                                            0
                                        </label>
                                        <label class="font-bold">
                                            <input
                                                :disabled="!isEditMode"
                                                name="hibClassified"
                                                type="radio"
                                                value="1"
                                                v-model="
                                                    formData.hib_classification
                                                "
                                            />
                                            1
                                        </label>
                                        <label class="font-bold">
                                            <input
                                                :disabled="!isEditMode"
                                                name="hibClassified"
                                                type="radio"
                                                value="2"
                                                v-model="
                                                    formData.hib_classification
                                                "
                                            />
                                            2
                                        </label>
                                        <label class="font-bold">
                                            <input
                                                :disabled="!isEditMode"
                                                name="hibClassified"
                                                type="radio"
                                                value="3"
                                                v-model="
                                                    formData.hib_classification
                                                "
                                            />
                                            3
                                        </label>
                                    </div>
                                </div>

                                <label class="font-bold">
                                    <input
                                        :disabled="!isEditMode"
                                        type="checkbox"
                                        v-model="measles_vaccine_computed"
                                    />
                                    Measles Vaccine
                                </label>
                                <label class="font-bold">
                                    <input
                                        :disabled="!isEditMode"
                                        type="checkbox"
                                        v-model="mmr_computed"
                                    />
                                    MMR
                                </label>
                            </div>
                            <div class="grid">
                                <div
                                    class="flex flex-wrap justify-between gap-5"
                                >
                                    <label class="font-bold" for="hepaA">
                                        <input
                                            :disabled="!isEditMode"
                                            type="checkbox"
                                            id="hepaA"
                                            value="Hepa A"
                                            v-model="hepa_a_computed"
                                        />
                                        Hepa A
                                    </label>

                                    <div class="flex gap-3">
                                        <label class="font-bold">
                                            <input
                                                :disabled="!isEditMode"
                                                name="hepaAClassified"
                                                type="radio"
                                                value="0"
                                                v-model="
                                                    formData.hepa_a_classification
                                                "
                                            />
                                            0
                                        </label>
                                        <label class="font-bold">
                                            <input
                                                :disabled="!isEditMode"
                                                name="hepaAClassified"
                                                type="radio"
                                                value="1"
                                                v-model="
                                                    formData.hepa_a_classification
                                                "
                                            />
                                            1
                                        </label>
                                        <label class="font-bold">
                                            <input
                                                :disabled="!isEditMode"
                                                name="hepaAClassified"
                                                type="radio"
                                                value="2"
                                                v-model="
                                                    formData.hepa_a_classification
                                                "
                                            />
                                            2
                                        </label>
                                        <label class="font-bold">
                                            <input
                                                :disabled="!isEditMode"
                                                name="hepaAClassified"
                                                type="radio"
                                                value="3"
                                                v-model="
                                                    formData.hepa_a_classification
                                                "
                                            />
                                            3
                                        </label>
                                    </div>
                                </div>
                                <div
                                    class="flex flex-wrap justify-between gap-5"
                                >
                                    <label class="font-bold" for="hepaB">
                                        <input
                                            :disabled="!isEditMode"
                                            type="checkbox"
                                            id="hepaB"
                                            value="Hepa B"
                                            v-model="hepa_b_computed"
                                        />
                                        Hepa B
                                    </label>

                                    <div class="flex gap-3">
                                        <label class="font-bold">
                                            <input
                                                :disabled="!isEditMode"
                                                name="hepaBClassified"
                                                type="radio"
                                                value="0"
                                                v-model="
                                                    formData.hepa_b_classification
                                                "
                                            />
                                            0
                                        </label>
                                        <label class="font-bold">
                                            <input
                                                :disabled="!isEditMode"
                                                name="hepaBClassified"
                                                type="radio"
                                                value="1"
                                                v-model="
                                                    formData.hepa_b_classification
                                                "
                                            />
                                            1
                                        </label>
                                        <label class="font-bold">
                                            <input
                                                :disabled="!isEditMode"
                                                name="hepaBClassified"
                                                type="radio"
                                                value="2"
                                                v-model="
                                                    formData.hepa_b_classification
                                                "
                                            />
                                            2
                                        </label>
                                        <label class="font-bold">
                                            <input
                                                :disabled="!isEditMode"
                                                name="hepaBClassified"
                                                type="radio"
                                                value="3"
                                                v-model="
                                                    formData.hepa_b_classification
                                                "
                                            />
                                            3
                                        </label>
                                    </div>
                                </div>

                                <label class="font-bold">
                                    <input
                                        :disabled="!isEditMode"
                                        type="checkbox"
                                        value="Typhoid Vaccine"
                                        v-model="typhoid_vaccine_computed"
                                    />
                                    Typhoid Vaccine
                                </label>
                                <label class="font-bold">
                                    <input
                                        :disabled="!isEditMode"
                                        type="checkbox"
                                        value="Influenza"
                                        v-model="influenza_computed"
                                    />
                                    Influenza
                                </label>
                            </div>
                        </div>
                        <div>
                            <label class="block font-bold" for="other"
                                >Other specify:</label
                            >
                            <input
                                :disabled="!isEditMode"
                                class="w-full rounded border border-black"
                                type="text"
                                id="other"
                                v-model="formData.other_immunizations"
                            />
                        </div>
                        <div class="mt-5 grid gap-5 sm:grid-cols-2">
                            <div>
                                <p class="text-center font-bold">
                                    Family Health History
                                </p>
                                <div>
                                    <label class="block font-bold" for="father"
                                        >Father:</label
                                    >
                                    <input
                                        :disabled="!isEditMode"
                                        class="w-full rounded border border-black"
                                        type="text"
                                        id="father"
                                        v-model="formData.father_health_history"
                                    />
                                </div>
                                <div>
                                    <label class="block font-bold" for="mother"
                                        >Mother:</label
                                    >
                                    <input
                                        :disabled="!isEditMode"
                                        class="w-full rounded border border-black"
                                        type="text"
                                        id="mother"
                                        v-model="formData.mother_health_history"
                                    />
                                </div>
                                <div>
                                    <label
                                        class="block font-bold"
                                        for="siblings"
                                        >Siblings:</label
                                    >
                                    <input
                                        :disabled="!isEditMode"
                                        class="w-full rounded border border-black"
                                        type="text"
                                        id="siblings"
                                        v-model="
                                            formData.siblings_health_history
                                        "
                                    />
                                </div>
                            </div>
                            <div>
                                <p class="text-center font-bold">
                                    Previous Illness
                                </p>
                                <div>
                                    <label
                                        class="block font-bold"
                                        for="childhood"
                                        >Childhood:</label
                                    >
                                    <input
                                        :disabled="!isEditMode"
                                        class="w-full rounded border border-black"
                                        type="text"
                                        id="childhood"
                                        v-model="formData.childhood_illnesses"
                                    />
                                </div>
                                <div>
                                    <label
                                        class="block font-bold"
                                        for="adulthood"
                                        >Adulthood:</label
                                    >
                                    <input
                                        :disabled="!isEditMode"
                                        class="w-full rounded border border-black"
                                        type="text"
                                        id="adulthood"
                                        v-model="formData.adult_illnesses"
                                    />
                                </div>
                            </div>
                        </div>
                        <div>
                            <label class="block font-bold" for="allergies"
                                >Allergies:</label
                            >
                            <input
                                :disabled="!isEditMode"
                                class="w-full rounded border border-black"
                                type="text"
                                id="allergies"
                                v-model="formData.allergies"
                            />
                        </div>
                        <div>
                            <label
                                class="block font-bold"
                                for="prefferedHospital"
                                >Preffered Hospital in case of emergency:</label
                            >
                            <input
                                :disabled="!isEditMode"
                                class="w-full rounded border border-black"
                                type="text"
                                id="prefferedHospital"
                                v-model="formData.preferred_hospital"
                            />
                        </div>
                        <template v-if="!isEditMode">
                            <button
                                class="my-2 w-full rounded-md bg-[#347956] px-14 py-1 font-medium text-white hover:bg-emerald-800"
                                type="button"
                                @click="toggleEditMode()"
                            >
                                EDIT
                            </button>
                        </template>

                        <template v-if="isEditMode">
                            <button
                                class="my-2 w-full rounded-md bg-red-500 px-14 py-1 font-medium text-white hover:bg-red-800"
                                type="button"
                                @click="refresh()"
                            >
                                CANCEL
                            </button>
                            <button
                                class="w-full rounded-md bg-[#347956] px-14 py-1 font-medium text-white hover:bg-emerald-800"
                                type="button"
                                @click="openModal()"
                            >
                                UPDATE
                            </button>
                        </template>
                    </form>
                </div>
            </div>
        </div>
        <Modal
            v-if="isModalOpen"
            @cancel="closeModal"
            @confirm="handleSubmit"
            message="You want to update this?"
        />
    </div>
</template>
<script setup>
import axios from "axios";
import { useAuthStore } from "~/stores/auth";
import { toast } from "vue3-toastify";
import "vue3-toastify/dist/index.css";

definePageMeta({
    layout: "user",
    middleware: ["medical-doctor"],
});

const isModalOpen = ref(false);
const authStore = useAuthStore();
const route = useRoute();
const isLoading = ref(true);
const isEditMode = ref(false);
const isUpdateId = ref("");
const itemId = route.params.id;

const formData = ref({
    dpt_opv: false,
    dpt_opv_classification: "",
    hib: false,
    hib_classification: "",
    measles_vaccine: false,
    mmr: false,
    hepa_a: false,
    hepa_a_classification: "",
    hepa_b: false,
    hepa_b_classification: "",
    typhoid_vaccine: false,
    influenza: false,
    other_immunizations: "",
    father_health_history: "",
    mother_health_history: "",
    siblings_health_history: "",
    childhood_illnesses: "",
    adult_illnesses: "",
    allergies: "",
    preferred_hospital: "",
});

const dpt_opv_computed = computed({
    get: () => formData.value.dpt_opv === 1,
    set: (value) => (formData.value.dpt_opv = value ? 1 : 0),
});
const hib_computed = computed({
    get: () => formData.value.hib === 1,
    set: (value) => (formData.value.hib = value ? 1 : 0),
});
const measles_vaccine_computed = computed({
    get: () => formData.value.measles_vaccine === 1,
    set: (value) => (formData.value.measles_vaccine = value ? 1 : 0),
});
const mmr_computed = computed({
    get: () => formData.value.mmr === 1,
    set: (value) => (formData.value.mmr = value ? 1 : 0),
});
const hepa_a_computed = computed({
    get: () => formData.value.hepa_a === 1,
    set: (value) => (formData.value.hepa_a = value ? 1 : 0),
});
const hepa_b_computed = computed({
    get: () => formData.value.hepa_b === 1,
    set: (value) => (formData.value.hepa_b = value ? 1 : 0),
});
const typhoid_vaccine_computed = computed({
    get: () => formData.value.typhoid_vaccine === 1,
    set: (value) => (formData.value.typhoid_vaccine = value ? 1 : 0),
});
const influenza_computed = computed({
    get: () => formData.value.influenza === 1,
    set: (value) => (formData.value.influenza = value ? 1 : 0),
});

const openModal = () => {
    isModalOpen.value = true;
};

const closeModal = () => {
    isModalOpen.value = false;
};

const handleSubmit = async () => {
    isLoading.value = true;
    try {
        if (isUpdateId.value) {
            await axios.put(
                `${useRuntimeConfig().public.laravelURL}user/health-histories/${isUpdateId.value}`,
                formData.value,
                {
                    headers: {
                        Authorization: `Bearer ${authStore.token}`,
                    },
                },
            );
            isEditMode.value = false;
            toast.success("Record updated successfully");
        } else {
            await axios.post(
                `${useRuntimeConfig().public.laravelURL}user/health-histories`,
                formData.value,
                {
                    params: {
                        patient_id_number: itemId,
                    },
                    headers: {
                        Authorization: `Bearer ${authStore.token}`,
                    },
                },
            );
            isEditMode.value = false;
            toast.success("Record added successfully");
        }
    } catch (error) {
        console.log("Error Submitting history", error);
    } finally {
        isModalOpen.value = false;
        isLoading.value = false;
    }
};

const fetchRecord = async () => {
    isLoading.value = true;
    try {
        const { data } = await axios.get(
            `${useRuntimeConfig().public.laravelURL}user/health-histories`,
            {
                params: {
                    patient_id_number: itemId,
                },
                headers: {
                    Authorization: `Bearer ${authStore.token}`,
                },
            },
        );

        if (data) {
            formData.value = data;
            if (formData.value.id) {
                isUpdateId.value = formData.value.id;
            }
        }
    } catch (error) {
        console.log("Error fetching history", error);
    } finally {
        isLoading.value = false;
    }
};

const toggleEditMode = async () => {
    isEditMode.value = !isEditMode.value;
};

const refresh = async () => {
    window.location.reload();
};

onMounted(async () => {
    await fetchRecord();
});
</script>

<template>
    <div
        class="grid min-h-screen place-content-center bg-gradient-to-br from-green-700 to-slate-50 px-4 py-12"
    >
        <div class="max-w-5xl rounded bg-white px-2 py-9">
            <div class="flex items-center justify-center gap-2">
                <img
                    src="/tua-logo.png"
                    alt="tuaLogo"
                    class="h-auto max-w-16"
                />
                <img
                    src="/mdu-logo.png"
                    alt="mduLogo"
                    class="h-auto max-w-16"
                />
            </div>
            <div class="space-y-5 text-center">
                <h1 class="text-2xl">DATA PRIVACY NOTICE</h1>
                <div>
                    <span class="text-lg"> Medical and Dental Unit </span>
                    <h2 class="text-2xl">Trinity University of Asia</h2>
                </div>
            </div>
            <div class="mt-5 space-y-5">
                <p>
                    PolicyTrinity University of Asia is committed to
                    safeguarding the privacy of personal information in
                    compliance with the Data Privacy Act of 2012 (RA 10173) and
                    relevant regulations. This notice outlines how we collect,
                    use, and protect your personal data in our Medical and
                    Dental Unit. The University may update this notice as
                    necessary, with changes posted on our official website.
                </p>

                <h3>Why We Collect Personal Information</h3>
                <h3>For Students:</h3>
                <p>
                    Medical and dental consultations, treatments, and follow-ups
                    Health monitoring and emergency response Ensuring student
                    safety within university premises Compliance with academic,
                    internship, and practicum requirements Verification of
                    medical records when needed
                </p>
                <h3>For Employees:</h3>
                <p>
                    Pre-employment and employment medical records Health
                    monitoring and benefits administration Compliance with
                    workplace health and safety regulations
                </p>
            </div>

            <div class="space-y-5">
                <div>
                    <h3>Data Storage, Security, and Disposal</h3>
                    <p>
                        Personal information is securely stored in both digital
                        and paper-based records. Access is restricted to
                        authorized personnel only. Data is retained for the
                        necessary duration and securely disposed of afterward
                        through shredding (physical) or permanent deletion
                        (digital).
                    </p>
                </div>
                <div>
                    <h3>Use and Disclosure of Personal Information</h3>
                    <p>
                        Personal data is used strictly for its intended purpose.
                        It will not be shared without consent unless required by
                        law or in cases of medical emergencies.
                    </p>
                </div>
                <div>
                    <h3>Data Transfer and Sharing</h3>
                    <p>
                        When necessary for medical referrals, health monitoring,
                        or compliance with institutional policies, personal data
                        may be shared with relevant third parties under strict
                        confidentiality and security measures.
                    </p>
                </div>
            </div>

            <h3>Access and Correction</h3>
            <p>
                You have the right to access, review, and correct inaccuracies
                in your personal data, as well as request copies of your
                records.
            </p>
            <div class="flex items-center gap-2">
                <input v-model="isAgree" type="checkbox" id="agree" />
                <label for="agree"
                    >I agree to the collection and processing of my medical and
                    dental data.</label
                >
            </div>
            <div class="my-5 flex justify-center">
                <button
                    class="rounded bg-[#000000] disabled:bg-slate-200 disabled:cursor-not-allowed px-5 py-2 font-bold text-white hover:bg-emerald-800"
                    @click="acceptPrivacy"
                    :disabled="!isAgree"
                >
                    PROCEED
                </button>
            </div>
        </div>
    </div>
</template>

<style scoped>
h3 {
    @apply font-bold;
}
</style>

<script setup>
import axios from "axios";
import { usePrivacyStore } from "~/stores/privacy";

const isAgree = ref(false);
const privacyStore = usePrivacyStore();

const acceptPrivacy = () => {
    privacyStore.togglePrivacy();
    navigateTo("/");
};
</script>

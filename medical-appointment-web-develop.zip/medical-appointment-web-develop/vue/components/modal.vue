<template>
    <div class="absolute inset-0 w-full grid place-content-center h-full z-50" open>
        <div class="absolute inset-0 bg-black opacity-50"></div>
        <div class="bg-white p-6 shadow-lg relative z-10">
            <h2 class="mb-4 text-xl font-bold text-gray-800">
                Are you sure? {{ message }}
            </h2>
            <div class="flex flex-wrap justify-center gap-4">
                <button
                    @click="confirm"
                    class="rounded border border-black bg-[#347956] px-8 py-2 text-white hover:bg-emerald-900"
                >
                    YES
                </button>
                <button
                    @click="cancel"
                    class="rounded border border-black bg-[#ff0000] px-8 py-2 text-white hover:bg-red-600"
                >
                    NO
                </button>
            </div>
        </div>
    </div>
</template>


<script setup>
const props = defineProps(["message"]);
const emit = defineEmits(["cancel", "confirm"]);


const confirm = () => {
    emit("confirm");
};

const cancel = () => {
    emit("cancel");
};
</script>

<style scoped>

::backdrop{
    backdrop-filter: blur(5px);
    background-color: rgba(0, 0, 0, 0.4);
}

</style>

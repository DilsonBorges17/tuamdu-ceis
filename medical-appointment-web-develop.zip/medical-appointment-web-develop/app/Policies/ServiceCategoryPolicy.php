<?php

namespace App\Policies;

use App\Models\User;

class ServiceCategoryPolicy
{
	public function viewAny(User $user): bool
	{
		return $user->hasRole('Head Nurse');
	}

	public function view(User $user): bool
	{
		return $user->hasRole('Head Nurse');
	}

	public function upsert(User $user): bool
	{
		return $user->hasRole('Head Nurse');
	}

	public function delete(User $user): bool
	{
		return $user->hasRole('Head Nurse');
	}
}

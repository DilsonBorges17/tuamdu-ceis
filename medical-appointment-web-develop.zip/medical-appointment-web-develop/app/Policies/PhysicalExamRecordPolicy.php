<?php

namespace App\Policies;

use App\Models\PhysicalExamRecord;
use App\Models\User;
use Illuminate\Auth\Access\Response;

class PhysicalExamRecordPolicy
{
	public function viewAny(User $user): bool
	{
		return $user->hasRole('Medical Doctor');
	}

	public function view(User $user): bool
	{
		return $user->hasRole('Medical Doctor');
	}

	public function upsert(User $user): bool
	{
		return $user->hasRole('Medical Doctor');
	}

	public function delete(User $user): bool
	{
		return $user->hasRole('Medical Doctor');
	}
}

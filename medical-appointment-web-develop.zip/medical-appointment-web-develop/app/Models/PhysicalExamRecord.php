<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class PhysicalExamRecord extends Model
{
	use HasFactory, SoftDeletes;

	protected $fillable = [
		"patient_id",
		"doctor_id",
		'date',
		'height_weight',
		'temperature_bp',
		'hr_pr_rr',
		'nutritional_status',
		'visual_activity',
		'hearing',
		'skin_scalp',
		'eyes_ears_nose',
		'mouth_throat_neck',
		'lungs_heart',
		'git_gut',
		'spine_extremities',
		'others',
		'recommendations',
		'year'
	];

	public function patient(): BelongsTo
	{
		return $this->belongsTo(Patient::class);
	}

	public function doctor(): BelongsTo
	{
		return $this->belongsTo(User::class, 'doctor_id');
	}
}

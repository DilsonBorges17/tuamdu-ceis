<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class DentalHealthStatus extends Model
{
	use HasFactory;
	protected $fillable = [
		"patient_id",

		'ur_labial_operation_1',
		'ur_labial_operation_2',
		'ur_labial_operation_3',
		'ur_labial_operation_4',
		'ur_labial_operation_5',
		'ur_labial_operation_6',
		'ur_labial_operation_7',
		'ur_labial_operation_8',

		'ur_labial_condition_1',
		'ur_labial_condition_2',
		'ur_labial_condition_3',
		'ur_labial_condition_4',
		'ur_labial_condition_5',
		'ur_labial_condition_6',
		'ur_labial_condition_7',
		'ur_labial_condition_8',

		'ul_labial_operation_1',
		'ul_labial_operation_2',
		'ul_labial_operation_3',
		'ul_labial_operation_4',
		'ul_labial_operation_5',
		'ul_labial_operation_6',
		'ul_labial_operation_7',
		'ul_labial_operation_8',

		'ul_labial_condition_1',
		'ul_labial_condition_2',
		'ul_labial_condition_3',
		'ul_labial_condition_4',
		'ul_labial_condition_5',
		'ul_labial_condition_6',
		'ul_labial_condition_7',
		'ul_labial_condition_8',

		'lr_lingual_operation_1',
		'lr_lingual_operation_2',
		'lr_lingual_operation_3',
		'lr_lingual_operation_4',
		'lr_lingual_operation_5',
		'lr_lingual_operation_6',
		'lr_lingual_operation_7',
		'lr_lingual_operation_8',

		'lr_lingual_condition_1',
		'lr_lingual_condition_2',
		'lr_lingual_condition_3',
		'lr_lingual_condition_4',
		'lr_lingual_condition_5',
		'lr_lingual_condition_6',
		'lr_lingual_condition_7',
		'lr_lingual_condition_8',

		'll_lingual_operation_1',
		'll_lingual_operation_2',
		'll_lingual_operation_3',
		'll_lingual_operation_4',
		'll_lingual_operation_5',
		'll_lingual_operation_6',
		'll_lingual_operation_7',
		'll_lingual_operation_8',

		'll_lingual_condition_1',
		'll_lingual_condition_2',
		'll_lingual_condition_3',
		'll_lingual_condition_4',
		'll_lingual_condition_5',
		'll_lingual_condition_6',
		'll_lingual_condition_7',
		'll_lingual_condition_8',
	];


	public function patient(): BelongsTo
	{
		return $this->belongsTo(Patient::class);
	}
}

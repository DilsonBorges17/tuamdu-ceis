<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;
use Laravel\Sanctum\HasApiTokens;
use Spatie\Permission\Traits\HasRoles;

class Patient extends Authenticatable
{
	use HasFactory, HasApiTokens, HasFactory, HasRoles, SoftDeletes;

	protected $guard_name = 'api';
	protected $fillable = [
		'id_number',
		'first_name',
		'middle_initial',
		'last_name',
		'email',
		'password',
		'place_of_birth',
		'date_of_birth',
		'gender',
		'address',
		'contact_number',
		'contact_person',
		'contact_person_number',
		'zip_code',
		'name_extension',
		'nationality',
		'department_id',
		'year_level',
		'relation',
		'classification',
		'profession',
	];


	protected $hidden = [
		'password',
	];

	/**
	 * Get the attributes that should be cast.
	 *
	 * @return array<string, string>
	 */
	protected function casts(): array
	{
		return [
			'password' => 'hashed',
		];
	}

	public function department(): BelongsTo
	{
		return $this->belongsTo(Department::class);
	}

	public function appointments(): HasMany
	{
		return $this->hasMany(Appointment::class);
	}

	public function log_sheets()
	{
		return $this->hasMany(MedicineLogSheet::class);
	}

	public function consultation_records(): HasMany
	{
		return $this->hasMany(ConsultationRecord::class);
	}

	public function emergency_cases(): HasMany
	{
		return $this->hasMany(EmergencyCase::class);
	}

	public function physical_exams(): HasMany
	{
		return $this->hasMany(PhysicalExam::class);
	}

	public function health_history(): HasOne
	{
		return $this->hasOne(HealthHistory::class);
	}

	public function oral_health_condition(): HasMany
	{
		return $this->hasMany(OralHealthCondition::class);
	}

	public function oral_health_condition_history(): HasOne
	{
		return $this->hasOne(OralHealthConditionHistory::class);
	}

	public function dental_health_status(): HasOne
	{
		return $this->hasOne(DentalHealthStatus::class);
	}
}

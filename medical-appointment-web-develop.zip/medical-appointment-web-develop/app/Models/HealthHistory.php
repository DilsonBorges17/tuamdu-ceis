<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class HealthHistory extends Model
{
	use HasFactory, SoftDeletes;

	protected $fillable = [
		"patient_id",
		"dpt_opv",
		"dpt_opv_classification",
		"hib",
		"hib_classification",
		"measles_vaccine",
		"mmr",
		"other_immunizations",
		"hepa_a",
		"hepa_b",
		"hepa_a_classification",
		"hepa_b_classification",
		"typhoid_vaccine",
		"influenza",
		"father_health_history",
		"mother_health_history",
		"siblings_health_history",
		"childhood_illnesses",
		"adult_illnesses",
		"allergies",
		"preferred_hospital",
	];

	public function patient(): BelongsTo
	{
		return $this->belongsTo(Patient::class);
	}
}

<?php

namespace App\Http\Controllers\User;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\DentalHealthStatus;
use App\Models\Patient;

class DentalHealthStatusController extends Controller
{
	/**
	 * Display a listing of the resource.
	 */
	public function index(Request $request)
	{
		$patient = Patient::where('id_number', $request->query('patient_id_number'))->firstOrFail();
		return response()->json(DentalHealthStatus::with('patient')->where('patient_id', $patient->id)->first());
	}


	/**
	 * Store a newly created resource in storage.
	 */
	public function store(Request $request)
	{
		$request->validate([
			"patient_id_number" => "required|exists:patients,id_number",
		]);

		$patient = Patient::where('id_number', $request['patient_id_number'])->firstOrFail();
		return response()
			->json(
				DentalHealthStatus::create(
					$request->all() +
					['patient_id' => $patient->id,]
				)
			);
	}

	/**
	 * Display the specified resource.
	 */
	public function show(string $id)
	{
		return response()->json(DentalHealthStatus::findOrFail($id));
	}

	/**
	 * Update the specified resource in storage.
	 */
	public function update(Request $request, string $id)
	{
		$request->validate([
			'patient_id_number' => 'prohibited',
		]);

		$row = DentalHealthStatus::findOrFail($id);
		$row->update($request->all());

		return response()->json($row);
	}

	/**
	 * Remove the specified resource from storage.
	 */
	public function destroy(string $id)
	{
		$row = DentalHealthStatus::findOrFail($id);
		return response()->json($row->delete());
	}
}

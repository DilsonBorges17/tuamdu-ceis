<?php

namespace App\Http\Controllers\User;

use Illuminate\Support\Facades\Gate;
use App\Models\ConsultationRecord;
use App\Http\Controllers\Controller;
use App\Http\Requests\User\UpsertConsultationRecordRequest;
use App\Models\Patient;
use Illuminate\Http\Request;

class ConsultationRecordController extends Controller
{
	/**
	 * Display a listing of the resource.
	 */
	public function index(Request $request)
	{
		Gate::authorize('view', ConsultationRecord::class);
		$patient = Patient::where('id_number', $request->query('patient_id_number'))->firstOrFail();
		return response()->json(ConsultationRecord::with('doctor')->where('doctor_id', auth()->user()->id)->where('patient_id', $patient->id)->get());
	}

	/**
	 * Store a newly created resource in storage.
	 */
	public function store(UpsertConsultationRecordRequest $request)
	{
		Gate::authorize('upsert', ConsultationRecord::class);
		$patient = Patient::where('id_number', $request['patient_id_number'])->firstOrFail();
		return response()
			->json(
				ConsultationRecord::create(
					$request->all() +
					['doctor_id' => auth()->user()->id, 'patient_id' => $patient->id,]
				)
			);
	}

	/**
	 * Display the specified resource.
	 */
	public function show(int $id)
	{
		Gate::authorize('viewAny');
		return response()->json(ConsultationRecord::findOrFail($id));
	}

	/**
	 * Update the specified resource in storage.
	 */
	public function update(UpsertConsultationRecordRequest $request, int $id)
	{
		Gate::authorize('upsert', ConsultationRecord::class);

		$row = ConsultationRecord::findOrFail($id);
		$row->update($request->all());

		return response()->json($row);
	}

	/**
	 * Remove the specified resource from storage.
	 */
	public function destroy(int $id)
	{
		Gate::authorize('delete', ConsultationRecord::class);
		$row = ConsultationRecord::findOrFail($id);
		return response()->json($row->delete());
	}
}

<?php

namespace App\Http\Requests\User;

use App\Models\OralHealthConditionHistory;
use App\Models\Patient;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpsertOralHealthConditionRequest extends FormRequest
{
	/**
	 * Determine if the user is authorized to make this request.
	 */
	public function authorize(): bool
	{
		return true;
	}

	/**
	 * Get the validation rules that apply to the request.
	 *
	 * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
	 */
	public function rules(): array
	{
		$rules = [
			"date" => "required|date",
			"patient_id_number" => "required|exists:patients,id_number",
			"year" => "required|in:1st,2nd,3rd,4th",
			"debris_tooth_stain" => "required|boolean",
			"calculus_deposit" => "required|boolean",
			"gingivitis" => "required|boolean",
			"periodontal_pocket" => "required|boolean",
			"orthodontic_treatment" => "required|boolean",
			"other_diseases" => "nullable|string",
			"teeth_present_total" => "nullable|integer",
			"teeth_present_permanent" => "nullable|integer",
			"caries_free_teeth_total" => "nullable|integer",
			"caries_free_teeth_permanent" => "nullable|integer",
			"teeth_extraction_total" => "nullable|integer",
			"teeth_extraction_permanent" => "nullable|integer",
			"teeth_restoration_total" => "nullable|integer",
			"teeth_restoration_permanent" => "nullable|integer",
			"missing_teeth_total" => "nullable|integer",
			"missing_teeth_permanent" => "nullable|integer",
			"filled_teeth_total" => "nullable|integer",
			"filled_teeth_permanent" => "nullable|integer",
			"df_dmf_teeth_total" => "nullable|integer",
			"df_dmf_teeth_permanent" => "nullable|integer",
			"examiner" => "nullable|string",
			"history" => [
				'nullable',
				'array',
				Rule::prohibitedIf(function () {
					if ($this->method() === 'POST') {
						$patient = Patient::where('id_number', $this->patient_id_number)->first();

						$oralHealthConditionHistory = OralHealthConditionHistory::where('patient_id', $patient->id)->first();
						if ($oralHealthConditionHistory !== null) {
							return true;
						}
					}

					return false;
				}),
			],
			"history.*" => 'nullable|string',
		];

		if ($this->method() === 'PUT' || $this->method() === 'PATCH') {
			$rules['history.patient_id'] = 'prohibited';
			$rules['patient_id_number'] = 'prohibited';
		}

		return $rules;
	}
}

<?php

namespace App\Http\Requests\User;

use App\Models\HealthHistory;
use App\Models\Patient;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use Closure;

class UpsertHealthHistoryRequest extends FormRequest
{
	/**
	 * Determine if the user is authorized to make this request.
	 */
	public function authorize(): bool
	{
		return true;
	}

	/**
	 * Get the validation rules that apply to the request.
	 *
	 * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
	 */
	public function rules(): array
	{
		$rules = [
			"patient_id_number" => "required|exists:patients,id_number",
			"dpt_opv" => "required|boolean",
			"dpt_opv_classification" => [
				Rule::requiredIf(function () {
					return $this->dpt_opv;
				}),
				"string"
			],
			"hib" => "required|boolean",
			"hib_classification" => [
				Rule::requiredIf(function () {
					return $this->hib;
				}),
				"string"
			],
			"measles_vaccine" => "required|boolean",
			"mmr" => "required|boolean",
			"other_immunizations" => "nullable|string",
			"hepa_a" => "required|boolean",
			"hepa_a_classification" => [
				Rule::requiredIf(function () {
					return $this->hepa_a;
				}),
				"string"
			],
			"hepa_b" => "required|boolean",
			"hepa_b_classification" => [
				Rule::requiredIf(function () {
					return $this->hepa_b;
				}),
				"string"
			],
			"typhoid_vaccine" => "required|boolean",
			"influenza" => "required|boolean",
			"father_health_history" => "nullable|string",
			"mother_health_history" => "nullable|string",
			"siblings_health_history" => "nullable|string",
			"childhood_illnesses" => "nullable|string",
			"adult_illnesses" => "nullable|string",
			"allergies" => "nullable|string",
			"preferred_hospital" => "nullable|string",
		];

		if ($this->method() === 'PUT' || $this->method() === 'PATCH') {
			$rules['patient_id_number'] = 'prohibited';
		} else if ($this->method() === 'POST') {
			$rules['patient_id_number'] = [
				function (string $attribute, mixed $value, Closure $fail) {
					$patient = Patient::where('id_number', $this->patient_id_number)->firstOrFail();
					$healthHistory = HealthHistory::where('patient_id', $patient->id)->first();
					if ($healthHistory) {
						$fail("The {$attribute} already has existing record.");
					}
				},
			];
		}

		return $rules;
	}
}

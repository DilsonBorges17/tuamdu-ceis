<?php

namespace App\Http\Requests\User;

use Illuminate\Foundation\Http\FormRequest;

class UpsertPhysicalExamRecordRequest extends FormRequest
{
	/**
	 * Determine if the user is authorized to make this request.
	 */
	public function authorize(): bool
	{
		return true;
	}

	/**
	 * Get the validation rules that apply to the request.
	 *
	 * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
	 */
	public function rules(): array
	{
		return [
			"patient_id_number" => "required|exists:patients,id_number",
			"height_weight" => "required|string",
			"temperature_bp" => "required|string",
			"hr_pr_rr" => "required|string",
			"nutritional_status" => "required|string",
			"visual_activity" => "required|string",
			"hearing" => "required|string",
			"skin_scalp" => "required|string",
			"eyes_ears_nose" => "required|string",
			"mouth_throat_neck" => "required|string",
			"lungs_heart" => "required|string",
			"git_gut" => "required|string",
			"spine_extremities" => "required|string",
			"year" => "required|in:1st,2nd,3rd,4th",
			"others" => "nullable|string",
			"recommendations" => "nullable|string",
		];
	}
}

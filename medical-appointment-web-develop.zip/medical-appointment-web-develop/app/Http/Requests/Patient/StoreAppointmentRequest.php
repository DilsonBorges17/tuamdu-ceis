<?php

namespace App\Http\Requests\Patient;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Validator;
use App\Models\AppointmentSchedule;
use App\Models\Appointment;
use Carbon\Carbon;

class StoreAppointmentRequest extends FormRequest
{


	/**
	 * Determine if the user is authorized to make this request.
	 */
	public function authorize(): bool
	{
		return true;
	}

	/**
	 * Get the validation rules that apply to the request.
	 *
	 * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
	 */
	public function rules(): array
	{
		$now = Carbon::now()->timezone('Asia/Manila');

		return [
			"service_type_id" => "required|exists:service_types,id",
			"date" => "required|date|after:$now",
			"time" => "required|date_format:H:i",
		];
	}

	public function after(): array
	{
		return [
			function (Validator $validator) {
				if (!$this->appointmentSchedule()) {
					$validator->errors()->add(
						'schedule',
						'No appointment schedule found!'
					);
					return;
				}

				if ($this->existingAppointment())
					$validator->errors()->add(
						'appointment_exist',
						'Your already booked an existing appointment!'
					);
			},
		];
	}

	protected function passedValidation(): void
	{
		$appointmentCount = Appointment
			::where('scheduled_date', $this->date)
			->where('appointment_schedule_id', $this->appointmentSchedule()->id)
			->count();

		$validated = $this->validated();
		$validated['appointment_schedule_id'] = $this->appointmentSchedule()->id;
		$validated['queuing_number'] = $appointmentCount + 1;

		$this->replace($validated);
	}

	private function appointmentSchedule()
	{
		$dayOfWeek = Carbon::parse($this->date)->format('l');

		$appointmentSchedule = AppointmentSchedule
			::where('day_of_week', $dayOfWeek)
			->where('service_type_id', $this->service_type_id)
			->where('start_time', $this->time)
			->first();

		return $appointmentSchedule;
	}

	private function existingAppointment()
	{
		return Appointment
			::where('scheduled_date', $this->date)
			->where('appointment_schedule_id', $this->appointmentSchedule()->id)
			->where('patient_id', auth()->user()->id)
			->first();
	}
}
